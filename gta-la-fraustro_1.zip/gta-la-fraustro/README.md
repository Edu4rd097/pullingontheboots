# Grand Theft Auto La Fraustro

Videojuego retro de 8 bits (tres niveles) empaquetado como aplicación **Angular 18** con **PWA**
(se instala en el celular y funciona sin internet).

## Requisitos
- Node.js 18.19 o superior (probado con Node 22)

## Correr en modo desarrollo
```bash
npm install
npm start
```
Abre http://localhost:4200

## Compilar para publicar
```bash
npm install
npm run build
```
El resultado queda en `dist/gta-la-fraustro/browser/`. Sube **el contenido** de esa carpeta a cualquier
hosting con HTTPS (Netlify, GitHub Pages, Firebase Hosting, IIS, Apache, Nginx...). Se compila con
`--base-href ./`, así que funciona en la raíz o dentro de una subcarpeta.


> Una app Angular no se puede abrir con doble clic (file://); necesita un servidor web.
> Para probar la compilación local: `npx http-server dist/gta-la-fraustro/browser -p 8080` y abre http://localhost:8080

## Estructura
- `src/game/*.js` – motor del juego (canvas, física, niveles, jefes, audio). Se cargan como scripts
  globales desde `angular.json` (sección `scripts`, en orden) y exponen `window.G`.
- `src/app/app.component.ts` – dibuja el lienzo y la barra de botones y arranca el juego con `G.boot()`
  fuera de la zona de Angular (para no correr detección de cambios en cada cuadro).
- `src/styles.css` – estilos del juego (pantalla completa, controles táctiles, aviso de girar el celular).
- `public/assets/` – menú, camión objetivo y música (`assets/audio/*.mp3`).
- `public/manifest.webmanifest`, `public/icons/`, `ngsw-config.json` – PWA (todo se guarda para jugar sin internet).
- `src/game/config.js` – parámetros ajustables (velocidad, gravedad, salto, dificultad, vida del jefe...).
- `src/game/levels.js` – zonas, elenco, frases, obstáculos y jefe de cada nivel.
- `src/game/config.js` – también trae el enlace de comentarios, Instagram y la CLABE de aportaciones del final.

## Parámetros de prueba (en la URL)
- `?level=2` empieza en el nivel 2
- `?auto=1` piloto automático, `?ts=4` acelera el tiempo, `?start=0.8` salta a ese punto del recorrido
