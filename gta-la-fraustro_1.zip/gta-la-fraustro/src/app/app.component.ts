import { AfterViewInit, Component, NgZone, inject } from '@angular/core';

/** El motor del juego (src/game/*.js) se carga como script global desde angular.json
 *  y expone window.G. Aquí solo se pinta el HTML que necesita y se arranca. */
declare global { interface Window { G: any } }

@Component({
  selector: 'app-root',
  standalone: true,
  template: `
    <div id="rotate"><div class="ico">📱</div><div><b>Gira tu celular</b><br>El juego se ve mejor en horizontal.</div><button id="btnPlayPortrait">Jugar así</button></div>
      <div id="wrap">
        <div id="toolbar">
          <button id="btnMusic" title="Música (M)">♪ MÚSICA</button>
          <button id="btnSfx" title="Efectos (N)">SFX</button>
          <button id="btnPause" title="Pausa (P)">❚❚ PAUSA</button>
          <button id="btnFull" title="Pantalla completa">⛶</button>
        </div>
        <canvas id="game" width="320" height="180"></canvas>
      </div>
  `,
})
export class AppComponent implements AfterViewInit {
  private zone = inject(NgZone);

  ngAfterViewInit(): void {
    // el ciclo de juego (requestAnimationFrame) corre fuera de Angular para no disparar detección de cambios en cada cuadro
    this.zone.runOutsideAngular(() => window.G?.boot());
  }
}
