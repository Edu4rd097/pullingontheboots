/* =========================================================
   JEFES: LIC. SALADO (nivel 1) y CHAVACARAT (nivel 2); la configuración vive en levels.js
   Lanza sellos (saltar), expedientes voladores (agacharse), cajas de
   archivo que caen y envía achichincles: pisarlos le quita una firma (vida).
   ========================================================= */
(function () {
  const G = window.G, CFG = G.CFG, S = G.SPR;
  const GROUND = CFG.GROUND;

  G.Boss = class {
    constructor() {
      this.cfg = G.LEVEL.boss;
      this.max = this.hp = this.cfg.hp;
      this.x = CFG.W + 60; this.targetX = CFG.W - 72; this.y = GROUND + 4;
      this.state = 'enter'; this.t = 0; this.flash = 0; this.attackT = 0; this.hurtT = 0;
      this.queue = []; this.nextCycle = 0; this.cycle = 0; this.vy = 0; this.shown = 0;
    }
    get phase() { return this.hp > 4 ? 1 : this.hp > 2 ? 2 : 3; }
    head() { return { x: this.x, y: this.y - 80 }; }
    say(text) { G.Dialog.say(() => this.state === 'gone' ? null : this.head(), this.cfg.name, text, { color: G.LEVEL.n === 2 ? '#1f7d36' : G.PAL.redD }); }
    update(dt) {
      const g = G.game;
      this.t += dt;
      if (this.flash > 0) this.flash -= dt;
      if (this.attackT > 0) this.attackT -= dt;
      if (this.hurtT > 0) this.hurtT -= dt;
      this.shown = Math.min(1, this.shown + dt * 1.5);
      switch (this.state) {
        case 'enter':
          this.x = G.lerp(this.x, this.targetX, Math.min(1, dt * 1.6));
          if (Math.random() < 0.6) G.FX.add({ x: g.camX + this.x + G.rand(-28, 28), y: GROUND - G.rand(0, 20), vx: G.rand(-30, 30), vy: -G.rand(10, 50), g: 60, life: 1, max: 1, color: G.pick(['#ffffff', '#e4e0d4']), size: 2 });
          if (Math.abs(this.x - this.targetX) < 2) {
            this.state = 'intro'; this.t = 0; g.shake(0.6, 4); G.Audio.sfx('bossroar');
            this.say(this.cfg.intro[0]);
          }
          break;
        case 'intro':
          if (this.t > 3.2 && this.t - dt <= 3.2) this.say(this.cfg.intro[1]);
          if (this.t > 6.2) {
            this.state = 'fight'; this.t = 0; this.nextCycle = 0.6;
            G.Dialog.narrate(this.cfg.hint, 3.6);
          }
          break;
        case 'fight':
          this.nextCycle -= dt;
          if (this.nextCycle <= 0 && this.queue.length === 0) this.planCycle();
          for (let i = this.queue.length - 1; i >= 0; i--) {
            if (g.time >= this.queue[i].throwAt) { this.throw(this.queue[i]); this.queue.splice(i, 1); }
          }
          break;
        case 'dying':
          if (Math.random() < 0.7) G.FX.burst(g.camX + this.x + G.rand(-28, 28), this.y - G.rand(10, 70), 3, ['#ffffff', G.PAL.orange, G.PAL.yellow, G.PAL.red, '#e4e0d4'], 90);
          if (this.t > 1.6) { this.vy += 500 * dt; this.y += this.vy * dt; this.x += 30 * dt; }
          if (this.t > 1.6 && this.t - dt <= 1.6) { G.Audio.sfx('explode'); g.shake(0.8, 5); G.FX.burst(g.camX + this.x, this.y - 40, 60, ['#ffffff', '#e4e0d4', G.PAL.red, G.PAL.yellow], 160, { size: 2 }); }
          if (this.y > CFG.H + 100) { this.state = 'gone'; g.onBossDefeated(); }
          break;
      }
    }
    planCycle() {
      const g = G.game, now = g.time, air = g.player.airTime, ph = this.phase;
      const pat = G.pick(this.cfg.patterns[ph]).concat([this.cfg.minion]);
      const extra = [0.55, 0.35, 0.18][ph - 1];
      const dist = this.x - 30 - CFG.PLAYER_X;
      let arrive = now + 0.5 + dist / (g.speed + 70);
      let prev = null;
      for (const id of pat) {
        const def = G.OB[id];
        const rel = g.speed - def.vx;
        if (prev) {
          const sameKind = !!prev.air === !!def.air;
          arrive += prev.w / (g.speed - prev.vx) + (sameKind ? air + 0.3 : air + 0.42) + extra + (G.OB[id].minion ? 0.5 : 0);
        }
        let throwAt = arrive - (def.fall ? (this.x - 20 - CFG.PLAYER_X) / g.speed : dist / rel);
        if (throwAt < now) { arrive += now - throwAt; throwAt = now; }
        this.queue.push({ def, throwAt, arrive });
        prev = def;
      }
      this.cycle++;
      if (this.cycle > 1 && Math.random() < 0.8) this.say(G.pick(this.cfg.fight));
      this.nextCycle = (arrive - now) + 1.0;
    }
    throw(item) {
      const g = G.game, def = item.def;
      this.attackT = 0.35;
      G.Audio.sfx(def.minion ? 'npc' : 'throw');
      if (def.minion && this.cfg.minionSay && !G.Dialog.busy()) this.say(this.cfg.minionSay);
      const sx = def.fall ? this.x - 20 : this.x - 34;
      const o = new G.Obstacle(def, g.camX + sx, def.minion ? { who: this.cfg.minion } : {});
      g.obstacles.push(o);
      if (def.minion) G.policeShout(o);
    }
    damage() {
      if (this.state !== 'fight') return;
      this.hp--; this.flash = 0.25; this.hurtT = 0.7;
      G.Audio.sfx('bosshit'); G.game.shake(0.35, 3);
      G.game.stats.bossHits++; G.game.addScore(CFG.score.bossHit, this.x, this.y - 70);
      G.FX.burst(G.game.camX + this.x, this.y - 50, 18, ['#ffffff', '#e4e0d4', G.PAL.red], 110);
      if (this.hp <= 0) {
        this.state = 'dying'; this.t = 0; this.queue = [];
        for (const o of G.game.obstacles) if (!o.dead) o.knock();
        this.say(this.cfg.defeat);
        G.Audio.play(null);
      } else this.say(G.pick(this.cfg.hurt));
    }
    draw(ctx) {
      if (this.state === 'gone') return;
      const bob = Math.round(Math.sin(this.t * 3) * 2);
      const SP = this.cfg.spr();
      let spr = SP.idle;
      if (this.state === 'dying') spr = SP.dead;
      else if (this.hurtT > 0) spr = SP.hurt;
      else if (this.attackT > 0) spr = SP.attack;
      if (this.flash > 0 && Math.floor(this.flash * 30) % 2 === 0) spr = this.cfg.white();
      const x = Math.round(this.x - 32), y = Math.round(this.y - 80 + bob);
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(x + 6, GROUND - 1, 52, 3);
      if (this.state === 'dying' && this.t < 1.6) ctx.drawImage(spr, x + G.randi(-2, 2), y + G.randi(-1, 1));
      else ctx.drawImage(spr, x, y);
    }
  };
})();
