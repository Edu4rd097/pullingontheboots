/* =========================================================
   Entidades: entrada, jugador, partículas, obstáculos (y su generador),
   personajes de fondo, tráfico y globos de diálogo.
   ========================================================= */
(function () {
  const G = window.G, CFG = G.CFG, S = G.SPR, P = G.PAL;
  const GROUND = CFG.GROUND;

  /* -------------------- ENTRADA -------------------- */
  const I = G.Input = { jumpHeld: false, duckHeld: false, _jump: false, _confirm: false, _pause: false, _restart: false, touch: false };
  I.jumpPressed = () => { const v = I._jump; I._jump = false; return v; };
  I.confirm = () => { const v = I._confirm; I._confirm = false; return v; };
  I.pause = () => { const v = I._pause; I._pause = false; return v; };
  I.restart = () => { const v = I._restart; I._restart = false; return v; };
  I.clearEdges = () => { I._jump = I._confirm = I._pause = I._restart = false; };
  I.pressJump = () => { if (!I.jumpHeld) I._jump = true; I.jumpHeld = true; I._confirm = true; };
  I.releaseJump = () => { I.jumpHeld = false; };

  /* -------------------- PARTÍCULAS -------------------- */
  const FX = G.FX = { list: [] };
  FX.add = function (o) { if (FX.list.length < 500) FX.list.push(Object.assign({ vx: 0, vy: 0, g: 0, life: 1, max: 1, size: 1, color: '#fff', screen: false }, o)); };
  FX.burst = function (x, y, n, colors, spd = 80, opts = {}) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, s = spd * (0.3 + Math.random());
      const life = opts.life || G.rand(0.4, 0.9);
      FX.add(Object.assign({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - (opts.up || 0), g: opts.g ?? 300, life, max: life, color: G.pick(colors), size: opts.size || (Math.random() > 0.7 ? 2 : 1) }, opts.extra || {}));
    }
  };
  FX.confetti = function (n) {
    const cols = [P.red, P.yellow, P.green, P.blue, P.orange, P.pink, P.white];
    for (let i = 0; i < n; i++) FX.add({ x: Math.random() * CFG.W, y: -5 - Math.random() * 40, vx: G.rand(-20, 20), vy: G.rand(20, 60), g: 20, life: 4, max: 4, color: G.pick(cols), size: 2, screen: true, wobble: Math.random() * 6 });
  };
  FX.update = function (dt) {
    for (const p of FX.list) {
      p.vy += p.g * dt; p.x += p.vx * dt + (p.wobble ? Math.sin(p.life * 8 + p.wobble) * 0.3 : 0); p.y += p.vy * dt; p.life -= dt;
    }
    FX.list = FX.list.filter(p => p.life > 0);
  };
  FX.draw = function (ctx, camX) {
    for (const p of FX.list) {
      ctx.globalAlpha = Math.min(1, p.life / p.max * 2);
      ctx.fillStyle = p.color;
      ctx.fillRect(Math.round(p.screen ? p.x : p.x - camX), Math.round(p.y), p.size, p.size);
    }
    ctx.globalAlpha = 1;
  };

  /* -------------------- JUGADOR -------------------- */
  G.Player = class {
    constructor() { this.reset(); }
    reset() {
      this.sx = CFG.PLAYER_X; this.y = GROUND; this.vy = 0; this.onGround = true; this.ducking = false;
      this.coyote = 0; this.buffer = 0; this.invuln = 0; this.dist = 0; this.mode = 'normal'; this.modeT = 0;
      this.visible = true; this.stepAcc = 0;
    }
    get airTime() { return 2 * CFG.jumpVel / CFG.gravity; }
    jump() { this.vy = -CFG.jumpVel; this.onGround = false; this.coyote = 0; this.buffer = 0; G.Audio.sfx('jump'); FX.burst(this.wx() - 2, GROUND, 4, ['#d8d0c0', '#a8a090'], 30, { g: 100, life: 0.3 }); }
    wx() { return G.game.camX + this.sx; }
    update(dt, speed, controllable) {
      this.modeT += dt;
      if (this.invuln > 0) this.invuln -= dt;
      if (this.mode === 'dead') { this.vy += CFG.gravity * dt; this.y = Math.min(GROUND, this.y + this.vy * dt); return; }
      if (controllable) {
        if (I.jumpPressed()) this.buffer = CFG.jumpBuffer;
        this.ducking = I.duckHeld && this.onGround;
        if (I.duckHeld && !this.onGround) this.vy += CFG.fastFall * dt;
      } else { I.jumpPressed(); this.ducking = false; }
      if (this.buffer > 0) this.buffer -= dt;
      if (this.onGround) this.coyote = CFG.coyoteTime; else this.coyote -= dt;
      if (this.buffer > 0 && this.coyote > 0 && !this.ducking) this.jump();
      if (!this.onGround) {
        if (!I.jumpHeld && this.vy < -80 && controllable) this.vy *= Math.pow(CFG.jumpCut, dt * 30);
        this.vy += CFG.gravity * dt;
        this.y += this.vy * dt;
        if (this.y >= GROUND) {
          this.y = GROUND; this.vy = 0; this.onGround = true; G.Audio.sfx('land');
          FX.burst(this.wx(), GROUND, 5, ['#d8d0c0', '#a8a090', '#8a8478'], 40, { g: 120, life: 0.35 });
        }
      }
      if (this.onGround && speed > 0) {
        this.dist += speed * dt; this.stepAcc += speed * dt;
        if (this.stepAcc > 36) { this.stepAcc = 0; G.Audio.sfx('step'); }
      }
      if (this.mode === 'hit' && this.modeT > 0.45) this.mode = 'normal';
    }
    get isBus() { return G.LEVEL && G.LEVEL.player === 'bus'; }
    get isRobot() { return G.LEVEL && G.LEVEL.player === 'robot'; }
    get flying() { const z = CFG.zones[Math.max(0, G.game.zone)]; return (this.isRobot || this.isBus) && !!(z && z.fly); }
    hitbox() {
      if (this.isRobot) return this.ducking ? { x: this.sx - 12, y: this.y - 36, w: 24, h: 34 } : { x: this.sx - 12, y: this.y - 58, w: 24, h: 56 };
      if (this.isBus) return this.ducking ? { x: this.sx - 52, y: this.y - 26, w: 108, h: 24 } : { x: this.sx - 52, y: this.y - 44, w: 108, h: 42 };
      if (this.ducking) return { x: this.sx - 5, y: this.y - 12, w: 13, h: 11 };
      return { x: this.sx - 3, y: this.y - 22, w: 8, h: 21 };
    }
    sprite() {
      const s = S.player;
      if (this.mode === 'dead') return s.dead;
      if (this.mode === 'win') return s.win[Math.floor(this.modeT * 4) % 2];
      if (this.mode === 'hit') return s.hit;
      if (this.mode === 'stand') return s.stand;
      if (!this.onGround) return this.vy < 0 ? s.jump : s.fall;
      if (this.ducking) return s.duck[Math.floor(this.dist / 8) % 2];
      return s.walk[Math.floor(this.dist / 9) % 4];
    }
    draw(ctx) {
      if (!this.visible) return;
      if (this.invuln > 0 && Math.floor(this.invuln * 14) % 2 === 0 && this.mode !== 'dead') return;
      if (this.isBus) return this.drawBus(ctx);
      if (this.isRobot) return this.drawRobot(ctx);
      const spr = this.sprite();
      // sombra
      const sh = Math.max(2, 8 - (GROUND - this.y) / 8);
      ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(Math.round(this.sx - sh / 2), GROUND - 1, Math.round(sh), 2);
      ctx.drawImage(spr, Math.round(this.sx - S.player.ax), Math.round(this.y - S.player.ay));
    }
    /* Nivel 3: el robot (camión fusionado) */
    drawRobot(ctx) {
      const R = S.robot, x = Math.round(this.sx - R.ax), air = GROUND - this.y;
      ctx.fillStyle = 'rgba(0,0,0,0.22)'; const sh = Math.max(8, 26 - air / 4); ctx.fillRect(Math.round(this.sx - sh / 2), GROUND - 1, Math.round(sh), 2);
      if (this.mode === 'dead') {
        ctx.save(); ctx.translate(this.sx, Math.round(this.y) - 20); ctx.rotate(1.2); ctx.drawImage(R.dead, -24, -44); ctx.restore();
        if (Math.random() < 0.4) G.FX.add({ x: G.game.camX + this.sx + G.rand(-10, 10), y: this.y - 30, vx: G.rand(-10, 10), vy: -30, g: -10, life: 1.2, max: 1.2, color: G.pick(['#555', '#777', '#999']), size: 3 });
        return;
      }
      const fly = this.flying;
      if (fly) ctx.drawImage(R.wings[Math.floor(G.game.t * 8) % 2], Math.round(this.sx - 56), Math.round(this.y - 58));
      if (this.ducking && this.onGround) { ctx.drawImage(R.duck, x, Math.round(this.y - 39)); }
      else if (fly || !this.onGround) ctx.drawImage(fly ? R.fly : R.stand, x, Math.round(this.y - R.ay));
      else ctx.drawImage(this.mode === 'stand' ? R.stand : R.walk[Math.floor(this.dist / 10) % 4], x, Math.round(this.y - R.ay));
      if (fly && Math.random() < 0.8) for (const fx of [-6, 6]) G.FX.add({ x: G.game.camX + this.sx + fx, y: this.y + 1, vx: G.rand(-8, 8) - 30, vy: G.rand(10, 30), g: 0, life: 0.3, max: 0.3, color: G.pick([P.orange, P.yellow, '#8ad0ff']), size: 2 });
      else if (this.onGround && Math.random() < 0.15) G.FX.add({ x: G.game.camX + this.sx - 10, y: this.y - 2, vx: -30, vy: -8, g: -6, life: 0.5, max: 0.5, color: '#b8a888', size: 2 });
    }
    /* Nivel 2: el camión con la cabeza de nuestro punk en la ventana */
    drawBus(ctx) {
      const x = Math.round(this.sx - 70);
      const air = GROUND - this.y;
      ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x + 8 + Math.min(20, air / 4), GROUND - 1, Math.max(40, 124 - air), 3);
      if (this.mode === 'dead') {
        ctx.save(); ctx.translate(x + 70, Math.round(this.y) - 20); ctx.rotate(-0.18); ctx.drawImage(S.busFull, -70, -28); ctx.restore();
        if (Math.random() < 0.4) G.FX.add({ x: G.game.camX + this.sx + G.rand(-30, 40), y: this.y - 40, vx: G.rand(-10, 10), vy: -30, g: -10, life: 1.2, max: 1.2, color: G.pick(['#555', '#777', '#999']), size: 3 });
        return;
      }
      const fly = this.flying;
      if (fly) {
        const wsp = S.busWings[Math.floor(G.game.t * 6) % 2], low = this.ducking && this.onGround ? 18 : 0;
        ctx.drawImage(wsp, x + 70 + 14 - 96, Math.round(this.y - 96 + low));
        if (Math.random() < 0.8) for (const fx of [-40, 40]) G.FX.add({ x: G.game.camX + this.sx + fx, y: this.y + 1, vx: G.rand(-8, 8) - 30, vy: G.rand(10, 30), g: 0, life: 0.3, max: 0.3, color: G.pick([P.orange, P.yellow, '#8ad0ff']), size: 2 });
      }
      if (this.ducking && this.onGround) { ctx.drawImage(S.busDuck, x, Math.round(this.y - 29)); return; }
      const bump = this.onGround && this.mode !== 'stand' && Math.floor(this.dist / 14) % 2 ? 1 : 0;
      const tilt = this.onGround ? 0 : G.clamp(this.vy / 2000, -0.12, 0.12);
      if (tilt) { ctx.save(); ctx.translate(x + 70, Math.round(this.y) - 24); ctx.rotate(tilt); ctx.drawImage(S.busFull, -70, -24); ctx.restore(); }
      else ctx.drawImage(S.busFull, x, Math.round(this.y - 48 - bump));
      if (!fly && this.onGround && Math.random() < 0.25) G.FX.add({ x: G.game.camX + this.sx - 70, y: this.y - 8, vx: -40, vy: -8, g: -6, life: 0.6, max: 0.6, color: '#9a9a9a', size: 2 });
    }
  };

  /* -------------------- OBSTÁCULOS -------------------- */
  const person = (id, vx, opts = {}) => Object.assign({ person: id, hb: [4, 4, 8, 21], vx, stomp: false }, opts);
  const OB = G.OB = {
    rock: { spr: () => S.rock, hb: [1, 2, 11, 7], small: 1 },
    box: { spr: () => S.box, hb: [1, 1, 11, 12], small: 1 },
    trash: { spr: () => S.trash, hb: [1, 1, 9, 14], small: 1 },
    cone: { spr: () => S.cone, hb: [1, 1, 7, 12], small: 1 },
    puddle: { spr: () => S.puddle, fps: 3, hb: [3, 1, 20, 3], hazard: 'splash', yoff: 2 },
    barrier: { spr: () => S.barrier, hb: [1, 1, 22, 14] },
    sack: { spr: () => S.sack, hb: [1, 2, 11, 7], small: 1 },
    barrel: { spr: () => S.barrel, hb: [1, 1, 9, 14], small: 1 },
    tire: { spr: () => S.tire, fps: 10, hb: [1, 8, 11, 12], small: 1, flame: 1 },
    cart: { spr: () => S.cart, hb: [1, 1, 20, 18] },
    dog: { spr: () => S.dog, fps: 10, hb: [1, 1, 16, 9], vx: -75, bark: 1 },
    dog2: { spr: () => S.dog2, fps: 10, hb: [1, 1, 16, 9], vx: -60, bark: 1 },
    dog3: { spr: () => S.dog3, fps: 10, hb: [1, 1, 16, 9], vx: -90, bark: 1 },
    pigeon: { spr: () => S.pigeon, fps: 8, hb: [1, 2, 10, 5], vx: -25, air: 15 },
    pigeonHigh: { spr: () => S.pigeon, fps: 8, hb: [1, 2, 10, 5], vx: -25, air: 34, decoy: 1 },
    crow: { spr: () => S.crow, fps: 10, hb: [1, 2, 10, 5], vx: -45, air: 15, sine: 3 },
    beam: { spr: () => S.beam, hb: [0, 0, 30, 6], air: 16, chain: 1 },
    bricks: { spr: () => S.bricks, hb: [0, 0, 12, 8], fall: 1, small: 1 },
    ditch: { w: 26, h: 4, hb: [5, 0, 16, 4], hazard: 'ditch', ditch: 1 },
    moto: { spr: () => S.moto, fps: 10, hb: [3, 4, 24, 18], vx: -105 },
    bike: { spr: () => S.bike, fps: 8, hb: [3, 4, 20, 20], vx: -80 },
    brayan: person('brayan', -22, { walk: 1 }),
    manguera: person('manguera', 0, { water: 1 }),
    tarjetas: person('tarjetas', 0),
    maton: person('maton', -32, { walk: 1, stomp: true }),
    maton2: person('maton2', -38, { walk: 1, stomp: true }),
    achi: person('achi', -28, { walk: 1, stomp: true, minion: 1 }),
    stamp: { spr: () => S.stamp, hb: [1, 1, 12, 13], vx: -70, spin: 0 },
    paper: { spr: () => S.paper, fps: 10, hb: [1, 1, 10, 6], vx: -115, air: 15 },
    paperHigh: { spr: () => S.paper, fps: 10, hb: [1, 1, 10, 6], vx: -115, air: 30 },
    filebox: { spr: () => S.filebox, hb: [1, 1, 12, 11], fall: 1 },
    coneThrow: { spr: () => S.cone, hb: [1, 1, 7, 12], vx: -70 },
    coneDrop: { spr: () => S.cone, hb: [1, 1, 7, 12], fall: 1 },
    // ---- nivel 2 (carretera; las alturas de lo que vuela están pensadas para el camión agachado) ----
    poli: person('poli', -18, { walk: 1, stomp: true }),
    mujer1: person('mujer1', -16, { walk: 1, stomp: true }),
    mujer2: person('mujer2', -12, { walk: 1, stomp: true }),
    mujer3: person('mujer3', -18, { walk: 1, stomp: true }),
    mujer4: person('mujer4', -14, { walk: 1, stomp: true }),
    transito: person('transito', 0, { stomp: true }),
    poliMin: person('poliMin', -28, { walk: 1, stomp: true, minion: 1 }),
    beamBus: { spr: () => S.beam, hb: [0, 0, 30, 6], air: 36, chain: 1 },
    pigeonBus: { spr: () => S.pigeon, fps: 8, hb: [1, 2, 10, 5], vx: -25, air: 36 },
    crowBus: { spr: () => S.crow, fps: 10, hb: [1, 2, 10, 5], vx: -45, air: 36, sine: 3 },
    goo: { spr: () => S.goo, fps: 6, hb: [1, 2, 12, 8], vx: -45 },
    gooAir: { spr: () => S.gooAir, fps: 8, hb: [1, 1, 12, 7], vx: -75, air: 36 },
    gooDrop: { spr: () => S.gooDrop, hb: [1, 1, 10, 11], fall: 1 },
    // ---- nivel 3: el robot aplasta todo ----
    patrulla: { spr: () => S.patrolL, hb: [3, 6, 60, 18], vx: -35, stomp: true, vehicle: 1 },
    camioneta: { spr: () => S.carsL[3], hb: [3, 6, 72, 22], vx: -30, stomp: true, vehicle: 1 },
    camioneta2: { spr: () => S.carsL[4], hb: [3, 6, 72, 22], vx: -30, stomp: true, vehicle: 1 },
    pajaro: { spr: () => S.pigeon, fps: 8, hb: [1, 2, 10, 5], vx: -30, air: 40 },
    cuervo: { spr: () => S.crow, fps: 10, hb: [1, 2, 10, 5], vx: -45, air: 40, sine: 3 },
    fishLow: { spr: () => S.fish, fps: 8, hb: [1, 1, 16, 9], vx: -60, air: 6, sine: 4, stomp: true },
    fishHi: { spr: () => S.fish, fps: 8, hb: [1, 1, 16, 9], vx: -70, air: 46, sine: 3, stomp: true },
    crab: { spr: () => S.crab, fps: 6, hb: [1, 2, 16, 9], vx: -40, stomp: true },
    octo: { spr: () => S.octo, fps: 4, hb: [1, 1, 14, 15], vx: -30, air: 16, sine: 6, stomp: true },
    motoV: { spr: () => S.motoV, fps: 10, hb: [3, 4, 24, 20], vx: -95, air: 8, sine: 4, stomp: true },
    motoVHi: { spr: () => S.motoV, fps: 10, hb: [3, 4, 24, 20], vx: -95, air: 46, sine: 3, stomp: true },
    satBox: { spr: () => S.sat, hb: [0, 0, 17, 11], vx: -65 },
    becas: { spr: () => S.becas, hb: [0, 0, 25, 11], vx: -95, air: 46 },
    palo: { spr: () => S.palo, fps: 8, hb: [1, 1, 16, 6], vx: -110, air: 4, sine: 2 },
    alien: { spr: () => S.alien, fps: 6, hb: [2, 1, 10, 14], vx: -26, stomp: true, minion: 1, heal: 1 }
  };
  for (const k in OB) {
    const d = OB[k]; d.id = k; d.vx = d.vx || 0; d.air = d.air || 0;
    if (d.person) { const pp = G.PEOPLE[d.person]; d.spr = () => d.walk ? pp.walkL : pp.standL; d.fps = d.walk ? 7 : 0; }
    const s = d.spr && d.spr(); const c = Array.isArray(s) ? s[0] : s;
    if (c) { d.w = c.width; d.h = c.height; }
  }

  G.Obstacle = class {
    constructor(def, x, extra = {}) {
      this.def = def; this.x = x; this.t = 0; this.passed = false; this.dead = false; this.hit = false;
      this.y = GROUND - def.air + (def.yoff || 0); // base (pie)
      this.vx = def.vx; this.rot = 0; this.who = extra.who;
      if (def.fall) { this.fallY = -30; }
      Object.assign(this, extra);
    }
    get w() { return this.def.w; } get h() { return this.def.h; }
    update(dt, camX) {
      this.t += dt;
      if (this.dead) { this.vy += 600 * dt; this.y += this.vy * dt; this.x += this.dvx * dt; this.rot += dt * 10; return; }
      this.x += this.vx * dt;
      if (this.def.sine) this.y = GROUND - this.def.air + Math.sin(this.t * 6) * this.def.sine;
      if (this.def.fall) {
        const sx = this.x - camX;
        const target = CFG.PLAYER_X + ((G.LEVEL && G.LEVEL.fallAhead) || 44);
        const k = G.clamp((sx - target) / 120, 0, 1);
        const ny = G.lerp(GROUND, -20, k * k);
        if (ny >= GROUND && this.fallY < GROUND) { G.FX.burst(this.x + this.w / 2, GROUND, 6, ['#a0a0a0', '#d8d0c0'], 50); G.Audio.sfx('land'); }
        this.fallY = ny; this.y = ny;
      }
      if (this.def.bark && !this.barked && this.x - camX < CFG.W - 30) { this.barked = true; G.Audio.sfx('bark'); }
      if (this.def.water && Math.random() < 0.5) G.FX.add({ x: this.x + 14, y: GROUND - 16, vx: G.rand(-40, -10), vy: G.rand(-30, 0), g: 300, life: 0.5, max: 0.5, color: P.waterL });
      if (this.def.flame && Math.random() < 0.3) G.FX.add({ x: this.x + G.rand(3, 9), y: this.y - 18, vx: G.rand(-5, 5), vy: -30, g: -10, life: 0.6, max: 0.6, color: G.pick([P.orange, P.yellow, P.red]) });
    }
    hb(camX) {
      const d = this.def, [hx, hy, hw, hh] = d.hb;
      if (d.ditch) return { x: this.x - camX + hx, y: GROUND - 2, w: hw, h: 4 };
      return { x: this.x - camX + hx, y: this.y - this.h + hy, w: hw, h: hh };
    }
    knock() {
      this.dead = true; this.vy = -180; this.dvx = 90;
    }
    draw(ctx, camX) {
      const d = this.def;
      const sx = Math.round(this.x - camX);
      if (d.ditch) {
        ctx.fillStyle = '#1a1210'; ctx.fillRect(sx + 2, GROUND - 1, d.w - 4, 12);
        ctx.fillStyle = '#3a2a20'; ctx.fillRect(sx, GROUND - 1, 2, 12); ctx.fillRect(sx + d.w - 2, GROUND - 1, 2, 12);
        ctx.fillStyle = '#000'; ctx.fillRect(sx + 4, GROUND + 3, d.w - 8, 8);
        return;
      }
      let spr = d.spr();
      if (Array.isArray(spr)) spr = spr[d.fps ? Math.floor(this.t * d.fps) % spr.length : 0];
      if (d.fall && this.y < GROUND - 1) {
        const k = 1 - G.clamp((GROUND - this.y) / 170, 0, 1);
        ctx.fillStyle = 'rgba(0,0,0,' + (0.15 + 0.3 * k) + ')';
        const sw = Math.round(this.w * (0.4 + 0.6 * k)); ctx.fillRect(sx + (this.w - sw) / 2, GROUND - 1, sw, 2);
      }
      if (d.chain) { ctx.fillStyle = '#444'; for (let y = 0; y < this.y - this.h; y += 3) { ctx.fillRect(sx + 6, y, 1, 2); ctx.fillRect(sx + 23, y, 1, 2); } }
      if (!d.air && !d.fall && !d.hazard) { ctx.fillStyle = 'rgba(0,0,0,0.2)'; ctx.fillRect(sx + 1, GROUND - 1, this.w - 2, 2); }
      if (this.dead) {
        ctx.save(); ctx.translate(sx + this.w / 2, Math.round(this.y - this.h / 2)); ctx.rotate(this.rot);
        ctx.drawImage(spr, -this.w / 2, -this.h / 2); ctx.restore(); return;
      }
      ctx.drawImage(spr, sx, Math.round(this.y - this.h));
    }
  };

  /* Pools por zona: [id, peso, progreso mínimo] */
  const POOLS = [
    [['rock', 3], ['box', 2], ['trash', 3], ['puddle', 1.5], ['dog2', 1, 0.075], ['pigeon', 1, 0.09]],
    [['cone', 3], ['puddle', 2], ['trash', 1], ['pigeon', 2.2], ['cart', 1], ['box', 1], ['dog3', 0.8], ['moto', 0.6, 0.27], ['brayan', 0.8, 0.24], ['pigeonHigh', 0.5]],
    [['barrier', 2], ['ditch', 2], ['puddle', 1.2], ['sack', 2], ['bricks', 2], ['beam', 2], ['bike', 0.8, 0.42], ['rock', 1], ['moto', 0.5]],
    [['barrel', 2], ['tire', 3], ['crow', 3], ['maton', 1.6], ['maton2', 1], ['ditch', 1.2], ['bricks', 1.2], ['beam', 1], ['dog3', 0.8]]
  ];
  function pickPool(z, prog, filter) {
    const pool = ((G.LEVEL && G.LEVEL.pools) || POOLS)[Math.min(z, 3)].filter(e => !(e[2] && prog < e[2]) && (!filter || filter(OB[e[0]])));
    if (!pool.length) return null;
    let tot = 0; for (const e of pool) tot += e[1];
    let r = Math.random() * tot;
    for (const e of pool) { r -= e[1]; if (r <= 0) return OB[e[0]]; }
    return OB[pool[0][0]];
  }

  /* -------------------- GENERADOR DE OBSTÁCULOS (por tiempos de llegada) --------------------
     Cada obstáculo tiene un tiempo de llegada al jugador. Así los separamos de forma justa
     aunque se muevan a distintas velocidades. */
  G.Spawner = class {
    constructor() { this.reset(); }
    reset() { this.pending = []; this.lastEnd = 0; this.active = false; }
    rel(def, speed) { return speed - def.vx; }
    travel(def, speed) { return (CFG.W + 30 - CFG.PLAYER_X) / this.rel(def, speed); }
    gap(diff) {
      const o = CFG.obstacles, air = G.game.player.airTime;
      return air + o.reaction + G.rand(G.lerp(o.gapMin[0], o.gapMin[1], diff), G.lerp(o.gapMax[0], o.gapMax[1], diff));
    }
    schedule(def, arrive, extra) {
      this.pending.push({ def, arrive, extra });
      const end = arrive + (def.w + 10) / Math.max(40, this.rel(def, G.game.speed));
      this.lastEnd = Math.max(this.lastEnd, end);
    }
    /* Inserta un obstáculo específico (eventos y jefe) respetando separación mínima */
    inject(def, extra, minGap) {
      const g = G.game, now = g.time;
      const air = g.player.airTime;
      const arrive = Math.max(now + this.travel(def, g.speed), this.lastEnd + (minGap ?? (air + 0.45)));
      this.schedule(def, arrive, extra);
      return arrive;
    }
    makePattern(z, prog, diff) {
      const g = G.game, now = g.time, sp = g.speed, air = g.player.airTime;
      const first = pickPool(z, prog);
      let arrive = Math.max(now + this.travel(first, sp), this.lastEnd + this.gap(diff));
      const combo = Math.random() < G.lerp(CFG.obstacles.comboChance[0], CFG.obstacles.comboChance[1], diff);
      this.schedule(first, arrive);
      if (!combo) return;
      const r = Math.random();
      if (first.small && !first.vx && diff > 0.25 && r < 0.45 && !(G.LEVEL && G.LEVEL.noDoubles)) {
        // dos obstáculos pegados: se saltan juntos
        const second = pickPool(z, prog, d => d.small && !d.vx && !d.fall);
        if (second) this.schedule(second, arrive + (first.w + 5) / sp);
      } else if (!first.air && r < 0.8) {
        // suelo -> aire (saltar y luego agacharse)
        const second = pickPool(z, prog, d => d.air && !d.decoy);
        if (second && second.air) this.schedule(second, arrive + (first.w) / this.rel(first, sp) + air + 0.32);
      } else {
        const second = pickPool(z, prog, d => !d.air && !d.vx && !d.fall);
        if (second) this.schedule(second, arrive + first.w / this.rel(first, sp) + air * 0.6 + 0.4);
      }
    }
    update(z, prog, diff) {
      const g = G.game, now = g.time;
      if (this.active && this.pending.length === 0 && this.lastEnd - now < 1.2) this.makePattern(z, prog, diff);
      for (let i = this.pending.length - 1; i >= 0; i--) {
        const it = this.pending[i];
        const rel = this.rel(it.def, g.speed);
        const sx = CFG.PLAYER_X + rel * (it.arrive - now);
        if (sx <= CFG.W + 30) {
          this.pending.splice(i, 1);
          const o = new G.Obstacle(it.def, g.camX + Math.max(sx, CFG.PLAYER_X + 60) - it.def.hb[0], it.extra);
          g.obstacles.push(o);
          if (it.extra && it.extra.onSpawn) it.extra.onSpawn(o);
          else G.policeShout(o);
        }
      }
    }
  };

  /* Los policías del nivel 2 gritan su lema al salir */
  G.policeShout = function (o) {
    const lv = G.LEVEL;
    if (!lv || G.Dialog.bubbles.length >= 2) return;
    const sp = lv.spawnLines && lv.spawnLines[o.def.id];
    if (sp) { if (Math.random() < 0.8) G.Dialog.say(() => o.dead ? null : { x: o.x - G.game.camX + o.w / 2, y: o.y - o.h }, sp.name, G.pick(sp.lines), { color: sp.color || '#9e1630' }); return; }
    if (!lv.policeSay || !lv.policeSay.includes(o.def.person)) return;
    const minion = o.def.minion && lv.minionLines;
    G.Dialog.say(() => o.dead ? null : { x: o.x - G.game.camX + o.w / 2, y: o.y - o.h }, minion ? 'FUERZA CIVIL' : (o.def.person === 'transito' ? 'TRÁNSITO' : 'POLICÍA'), G.pick(minion ? lv.minionLines : lv.policeLines), { color: '#1d3a8a' });
  };

  /* -------------------- PERSONAJES DE FONDO -------------------- */
  G.BgNPC = class {
    constructor(who, line, camX, opts = {}) {
      this.who = who; this.line = line; this.spoken = false;
      const looks = G.PEOPLE[who] ? who : 'peaton';
      this.spr = G.PEOPLE[looks];
      this.lx = camX * 0.4 + CFG.W + 10 + (opts.dx || 0); // coordenadas de la capa intermedia
      this.vx = opts.vx ?? G.pick([-12, 0, 0, 10]);
      this.t = 0;
    }
    sx(camX) { return this.lx - camX * 0.4; }
    update(dt, camX) {
      this.t += dt; this.lx += this.vx * dt;
      const sx = this.sx(camX);
      if (!this.spoken && sx < CFG.W - 70 && this.line) {
        this.spoken = true;
        G.Dialog.say(() => ({ x: this.sx(G.game.camX), y: G.WORLD_Y.MID_BASE - 27 }), (G.CAST[this.who] || {}).name || '', this.line, { who: this.who });
      }
      return sx > -30;
    }
    draw(ctx, camX) {
      const sx = Math.round(this.sx(camX));
      const s = this.spr;
      let img = this.vx === 0 ? (this.who === 'rigo' || sx > CFG.PLAYER_X ? s.standL : s.stand) : (this.vx < 0 ? s.walkL : s.walk)[Math.floor(this.t * 6) % 4];
      if (this.vx === 0 && sx < CFG.PLAYER_X - 10) img = s.stand;
      ctx.drawImage(img, sx - s.ax, G.WORLD_Y.MID_BASE - s.ay - 1);
    }
  };

  /* -------------------- TRÁFICO (capa de la calle, 0.7) -------------------- */
  G.Car = class {
    constructor(camX, opts = {}) {
      this.dir = opts.dir ?? (Math.random() > 0.5 ? 1 : -1);
      const amb = G.LEVEL && G.LEVEL.ambient[G.game.zone];
      this.bus = opts.bus ?? (opts.idx === undefined && Math.random() < ((amb && amb.busChance) || 0));
      this.idx = opts.idx ?? G.randi(0, (this.bus ? S.buses : S.cars).length - 1);
      this.img = (this.bus ? (this.dir > 0 ? S.buses : S.busesL) : (this.dir > 0 ? S.cars : S.carsL))[this.idx];
      if (amb && amb.highway && !opts.patrol && !opts.moto && opts.idx === undefined) {
        const r = Math.random(); this.bus = false;
        if (r < 0.45) { this.idx = G.randi(0, S.trailers.length - 1); this.img = (this.dir > 0 ? S.trailers : S.trailersL)[this.idx]; this.trailer = true; }
        else if (r < 0.8) { this.idx = G.randi(3, 4); this.img = (this.dir > 0 ? S.cars : S.carsL)[this.idx]; }
        else opts.patrol = true;
      }
      if (opts.patrol) { this.img = this.dir > 0 ? S.patrol : S.patrolL; this.bus = false; }
      if (opts.moto) { if (!S.motoR) S.motoR = G.flip(S.moto[0]); this.img = this.dir > 0 ? S.motoR : S.moto[0]; this.bus = false; this.vx = this.dir * G.rand(110, 160); }
      this.w = this.img.width; this.h = this.img.height;
      this.vx = this.dir * (opts.speed ?? (this.bus || this.trailer ? G.rand(40, 70) : G.rand(40, 110)));
      // carril derecho (más lejos) y carril contrario (más cerca: se dibuja encima)
      this.lane = this.dir > 0 ? G.WORLD_Y.ROAD_TOP + 10 : G.WORLD_Y.ROAD_TOP + 15;
      this.x = this.dir > 0 ? camX * 0.7 - this.w - 6 : camX * 0.7 + CFG.W + 10;
      if (opts.fromRight) this.x = camX * 0.7 + CFG.W + 10;
      else if (this.dir > 0 && this.vx < G.game.speed * 0.7) this.x = camX * 0.7 + CFG.W + 10; // lo vamos rebasando: aparece por la derecha
      this.who = opts.who; this.line = opts.line; this.spoken = false;
    }
    sx(camX) { return this.x - camX * 0.7; }
    /* ¿Cabe en su carril sin encimarse con otro auto? */
    static fits(car, cars) { return !cars.some(c => c.dir === car.dir && car.x < c.x + c.w + 10 && car.x + car.w + 10 > c.x); }
    update(dt, camX) {
      // no rebasar ni encimarse: si alcanza al de enfrente en su carril, frena a su velocidad
      let lead = null;
      for (const c of G.game.cars) {
        if (c === this || c.dir !== this.dir) continue;
        const ahead = this.dir > 0 ? c.x > this.x : c.x < this.x;
        if (ahead && (!lead || Math.abs(c.x - this.x) < Math.abs(lead.x - this.x))) lead = c;
      }
      let nx = this.x + this.vx * dt;
      if (lead) {
        if (this.dir > 0 && nx + this.w + 8 > lead.x) { nx = Math.min(nx, lead.x - this.w - 8); this.vx = Math.min(this.vx, lead.vx); }
        if (this.dir < 0 && nx < lead.x + lead.w + 8) { nx = Math.max(nx, lead.x + lead.w + 8); this.vx = Math.max(this.vx, lead.vx); }
      }
      this.x = nx;
      const sx = this.sx(camX);
      if (this.who && !this.spoken && sx < CFG.W - 90) {
        this.spoken = true; G.Audio.sfx('honk');
        G.Dialog.say(() => ({ x: this.sx(G.game.camX) + this.w / 2, y: this.lane - this.h - 2 }), G.CAST[this.who].name, this.line, { who: this.who, color: P.red });
      }
      return sx > -this.w - 60 && sx < CFG.W + 140;
    }
    draw(ctx, camX) {
      const x = Math.round(this.sx(camX));
      ctx.drawImage(this.img, x, this.lane - this.h);
      if (this.who) { ctx.fillStyle = P.skin; ctx.fillRect(x + (this.dir > 0 ? 36 : this.w - 39), this.lane - this.h + 8, 3, 3); }
    }
  };

  /* -------------------- DIÁLOGOS -------------------- */
  const D = G.Dialog = { bubbles: [], narr: null, last: -99 };
  D.reset = function () { D.bubbles = []; D.narr = null; D.last = -99; };
  D.say = function (anchor, name, text, opts = {}) {
    if (D.bubbles.length >= 2) D.bubbles.shift();
    const dur = CFG.dialog.holdBase + text.length * CFG.dialog.holdPerChar + text.length / CFG.dialog.charsPerSec;
    D.bubbles.push({ anchor, name, text, t: 0, dur, color: opts.color || P.blueD, shown: 0 });
    D.last = G.game.time;
    G.Audio.sfx('npc');
    if (opts.who) G.game.meet(opts.who);
  };
  D.narrate = function (text, dur = 3.2, opts = {}) { D.narr = { text, t: 0, dur, big: opts.big }; G.Audio.sfx('blip'); };
  D.busy = () => D.bubbles.length > 0;
  D.update = function (dt) {
    for (const b of D.bubbles) {
      b.t += dt;
      const before = Math.floor(b.shown);
      b.shown = Math.min(b.text.length, b.t * CFG.dialog.charsPerSec);
      if (Math.floor(b.shown) !== before && Math.floor(b.shown) % 3 === 0 && b.shown < b.text.length) G.Audio.sfx('blip');
    }
    D.bubbles = D.bubbles.filter(b => b.t < b.dur);
    if (D.narr) { D.narr.t += dt; if (D.narr.t > D.narr.dur) D.narr = null; }
  };
  D.draw = function (ctx) {
    for (const b of D.bubbles) {
      const a = b.anchor(); if (!a) continue;
      const txt = b.text.slice(0, Math.floor(b.shown));
      const lines = G.wrap(b.text, 104);
      const w = Math.max(...lines.map(l => G.textWidth(l)), G.textWidth(b.name)) + 8;
      const h = lines.length * 7 + 5;
      let x = G.clamp(Math.round(a.x - w / 2), 2, CFG.W - w - 2);
      let y = Math.max((G.game.boss && G.game.boss.state !== 'gone') ? 52 : 34, Math.round(a.y - h - 6));
      // cola
      ctx.fillStyle = P.ink; const tx = G.clamp(Math.round(a.x), x + 4, x + w - 5);
      ctx.fillRect(tx - 1, y + h, 4, 2); ctx.fillRect(tx, y + h + 2, 2, 2); ctx.fillRect(tx, y + h + 4, 1, 1);
      ctx.fillStyle = P.white; ctx.fillRect(tx, y + h, 2, 1); ctx.fillRect(tx, y + h + 1, 1, 2);
      G.box(ctx, x, y, w, h, P.white, P.ink, 'rgba(0,0,0,0.3)');
      // nombre
      if (b.name) { const nw = G.textWidth(b.name) + 4; G.box(ctx, x + 2, y - 6, nw, 7, b.color, P.ink, null); G.text(ctx, b.name, x + 4, y - 5, P.white); }
      let shown = txt.length, yy = y + 3;
      for (const l of lines) {
        const part = l.slice(0, Math.max(0, shown)); shown -= l.length + 1;
        G.text(ctx, part, x + 4, yy + 1, P.ink); yy += 7;
      }
    }
    if (D.narr) {
      const n = D.narr;
      const lines = G.wrap(n.text, 250);
      const w = Math.max(...lines.map(l => G.textWidth(l))) + 16, h = lines.length * 8 + 8;
      const x = Math.round((CFG.W - w) / 2), y = (G.game.boss && G.game.boss.state !== 'gone') ? 52 : 32;
      const k = Math.min(1, n.t * 6, (n.dur - n.t) * 6);
      ctx.globalAlpha = Math.max(0, k);
      G.box(ctx, x, y, w, h, 'rgba(20,16,30,0.92)', P.yellow, 'rgba(0,0,0,0.5)');
      lines.forEach((l, i) => G.text(ctx, l, CFG.W / 2, y + 5 + i * 8, P.white, { align: 'center' }));
      ctx.globalAlpha = 1;
    }
  };
})();
