/* =========================================================
   Núcleo del juego: máquina de estados, actualización, colisiones,
   progreso, HUD y pantallas (MENU, INTRO, PLAYING, BOSS, ENDING,
   GAME_OVER, VICTORY).
   ========================================================= */
(function () {
  const G = window.G, CFG = G.CFG, S = G.SPR, P = G.PAL, I = G.Input;
  const GROUND = CFG.GROUND, L = CFG.courseLength;

  const game = G.game = {
    state: 'SPLASH', paused: false, t: 0,
    player: new G.Player(), spawner: new G.Spawner(),
    obstacles: [], npcs: [], cars: [], popups: [], boss: null,
    camX: 0, pd: 0, speed: 0, time: 0, clock: 0,
    zone: 0, zoneVis: { cur: 0, prev: 0, t: 99 },
    hearts: CFG.hearts, score: 0, evIdx: 0,
    stats: null, met: new Set(), shakeT: 0, shakeMag: 0, flash: 0,
    titleCard: null, ending: null, buttons: [], hintT: 0,
    images: {}
  };

  /* ------------------------------ utilidades ------------------------------ */
  game.prog = () => G.clamp(game.pd / L, 0, 1);
  game.displayProg = function () {
    if (game.state === 'BOSS' && game.boss) return 0.80 + 0.15 * (1 - Math.max(0, game.boss.hp) / game.boss.max);
    return game.prog();
  };
  game.zoneAt = function (p) { let z = 0; CFG.zones.forEach((zz, i) => { if (p >= zz.start) z = i; }); return z; };
  game.shake = (t, m) => { game.shakeT = Math.max(game.shakeT, t); game.shakeMag = Math.max(game.shakeMag, m); };
  game.addScore = function (n, sx, sy) {
    game.score += n;
    if (sx !== undefined) game.popups.push({ x: game.camX + sx, y: sy, text: '+' + n, t: 0 });
  };
  const countable = (k) => G.CAST[k] && !k.startsWith('peaton') && (G.CAST[k].lv || 1) === G.LEVEL.n;
  game.meet = function (who) { if (who && countable(who)) { if (!game.met.has(who)) game.score += CFG.score.npc; game.met.add(who); } };
  game.totalCast = () => Object.keys(G.CAST).filter(countable).length;
  game.playerSay = function (text) { G.Dialog.say(() => ({ x: game.player.sx + (game.player.isBus ? 30 : 0), y: game.player.y - (game.player.isBus ? 52 : game.player.isRobot ? 66 : 26) }), 'TÚ', text, { color: P.redD }); };

  game.setZone = function (z, silent) {
    if (z === game.zone && !silent) return;
    const zv = game.zoneVis;
    const zone = CFG.zones[z], vis = zone.vis ?? z;
    if (vis !== zv.cur) { zv.prev = zv.cur; zv.cur = vis; zv.t = silent ? 99 : 0; }
    game.zone = z;
    G.Audio.play(zone.music);
    if (!silent) {
      game.titleCard = { n: z + 1, name: zone.name, t: 0, color: zone.color };
      G.Audio.sfx('zone');
    }
  };

  /* ------------------------------ ciclo de partida ------------------------------ */
  function clearWorld() {
    game.obstacles = []; game.npcs = []; game.cars = []; game.popups = []; game.boss = null;
    game.spawner.reset(); G.Dialog.reset(); G.FX.list = []; game.ending = null; game.titleCard = null;
  }
  game.newGame = function (lvl) {
    G.startLevel(lvl || G.LEVEL.n);
    clearWorld();
    game.player.reset();
    game.hearts = CFG.hearts; game.score = 0; game.time = 0; game.clock = 0; game.camX = 0; game.pd = 0; game.speed = 0;
    game.met = new Set(); game.evIdx = 0;
    game.stats = { obstacles: 0, stomps: 0, hits: 0, bossHits: 0, retries: 0 };
    game.zone = -1; game.zoneVis = { cur: CFG.zones[0].vis, prev: CFG.zones[0].vis, t: 99 };
    if (G.DEBUG.start > 0) { game.jumpTo(G.DEBUG.start); return; }
    game.state = 'INTRO'; game.t = 0; game.houseOpen = false;
    if (G.LEVEL.intro === 'house') { game.player.visible = false; game.player.sx = 80; game.player.mode = 'stand'; }
    game.zone = 0; G.Audio.play(CFG.zones[0].music);
    if (G.LEVEL.intro === 'robot') {
      game.state = 'PLAYING';
      game.startScene('transform', () => { game.zone = -1; game.setZone(0); game.hintT = 6; game.randomDialogT = 5; game.walkerT = 1; game.trafficT = 1.5; });
    }
  };
  /* Escenas animadas (nivel 3) */
  game.startScene = function (name, onEnd) {
    const def = G.Scenes[name]; if (!def) return;
    game.scene = { name, t: 0, ret: game.state, onEnd };
    game.state = 'SCENE';
    if (def.start) def.start(game.scene);
  };
  function updateScene(dt) {
    const g = game, sc = g.scene, def = G.Scenes[sc.name];
    sc.t += dt;
    if (def.update) def.update(sc, dt);
    if ((I.confirm() || I.jumpPressed()) && sc.t > 1 && sc.name !== 'wings') sc.t = def.dur;
    if (sc.t >= def.dur) {
      if (sc.name === 'wings' && g.zone !== 2) { g.pd = 0.40 * L; g.setZone(2); }
      if (def.end) def.end(sc);
      g.state = sc.ret === 'SCENE' ? 'PLAYING' : sc.ret; g.scene = null;
      g.obstacles = g.obstacles.filter(o => o.x - g.camX > CFG.W * 0.6);
      I.clearEdges();
      if (sc.onEnd) sc.onEnd();
    }
  }
  /* Coloca al jugador en un punto del recorrido (puntos de control / depuración) */
  game.jumpTo = function (p) {
    clearWorld();
    game.player.reset();
    game.pd = p * L; game.camX = game.pd; game.speed = CFG.speedStart * 0.6;
    game.evIdx = G.EVENTS.findIndex(e => e.at >= p); if (game.evIdx < 0) game.evIdx = G.EVENTS.length;
    game.state = 'PLAYING'; game.t = 0; game.hintT = 4;
    game.zone = -1;
    const z = game.zoneAt(p);
    game.zoneVis = { cur: CFG.zones[z].vis, prev: CFG.zones[z].vis, t: 99 };
    game.setZone(Math.min(z, 3), false);
    for (const e of G.EVENTS) if (e.vis !== undefined && e.at <= p && game.zoneAt(e.at) === z) game.zoneVis = { cur: e.vis, prev: e.vis, t: 99 };
    if (p >= 0.8) game.startBoss();
    game.randomDialogT = 4; game.walkerT = 2; game.trafficT = 1;
  };
  game.retry = function () {
    game.stats.retries++;
    game.hearts = CFG.hearts;
    const z = Math.min(game.zoneAt(game.prog()), 4);
    game.score = Math.max(0, game.score - 500);
    game.jumpTo(z === 0 ? 0.01 : CFG.zones[z].start);
  };

  game.startBoss = function () {
    game.state = 'BOSS'; game.spawner.active = false; game.spawner.pending = [];
    game.pd = 0.80 * L;
    game.boss = new G.Boss();
    game.setZone(4);
    G.Audio.play(CFG.zones[4].music);
    if (G.Allies) G.Allies.reset();
    if (G.LEVEL.bossNarr) setTimeout(() => { if (game.state === 'BOSS') G.Dialog.narrate(G.LEVEL.bossNarr, 3.4); }, 600);
  };
  game.onBossDefeated = function () {
    game.state = 'ENDING';
    game.pd = 0.95 * L;
    game.addScore(2000);
    game.setZone(5);
    if (G.LEVEL.ending === 'finish') {
      const finishX = game.camX + game.player.sx + 64 + (L - game.pd);
      game.ending = { phase: 'drive', t: 0, finishX };
      G.Dialog.narrate('¡La meta está cerca!', 2.6);
      setTimeout(() => game.playerSay('¡Ya llegamos, compa!'), 1600);
      return;
    }
    G.Dialog.narrate(G.NARR.final, 3);
    const doorOff = 58;
    const busX = game.camX + game.player.sx + (L - game.pd) - doorOff;
    game.ending = { phase: 'walk', t: 0, busX, doorX: busX + doorOff, locked: false, busVX: 0, door: false, full: false };
    setTimeout(() => game.playerSay('¡Ya lo veo! ¡Espérame!'), 1800);
  };
  game.die = function () {
    game.player.mode = 'dead'; game.player.vy = -220; game.player.onGround = false;
    game.deathT = 0; G.Audio.sfx('hit'); G.Audio.play('gameover');
  };

  /* ------------------------------ eventos guionizados ------------------------------ */
  function fireEvent(e) {
    const g = game;
    switch (e.type) {
      case 'bg': {
        g.npcs.push(new G.BgNPC(e.who, G.CAST[e.who].lines[e.line], g.camX, { vx: 0 }));
        if (e.then) g.spawner.inject(G.OB[e.then.ob], { who: e.then.who, onSpawn: () => g.meet(e.then.who) });
        break;
      }
      case 'ob': {
        const who = e.who, line = G.CAST[who].lines[e.line];
        g.spawner.inject(G.OB[e.ob], {
          who, onSpawn: (o) => G.Dialog.say(() => o.dead ? null : { x: o.x - g.camX + o.w / 2, y: o.y - o.h }, G.CAST[who].name, line, { who })
        });
        break;
      }
      case 'traffic':
        { const c = new G.Car(g.camX, { dir: 1, idx: S.CAR_IDX.vocho, bus: false, speed: 25, fromRight: true, who: e.who, line: G.CAST[e.who].lines[e.line] }); g.cars = g.cars.filter(o => !(o.dir === c.dir && c.x < o.x + o.w + 10 && c.x + c.w + 10 > o.x)); g.cars.push(c); }
        break;
      case 'narr': G.Dialog.narrate(e.text, 3.5); break;
      case 'scene': g.startScene(e.scene); break;
      case 'say':
        g.playerSay(e.text);
        if (e.vis !== undefined) { const zv = g.zoneVis; zv.prev = zv.cur; zv.cur = e.vis; zv.t = 0; }
        break;
    }
  }

  function ambient(dt) {
    const g = game, z = g.zone;
    // diálogos aleatorios con personajes compatibles con la zona
    g.randomDialogT -= dt;
    if (g.randomDialogT <= 0 && !G.Dialog.busy() && g.time - G.Dialog.last > CFG.dialog.minInterval && g.state === 'PLAYING') {
      g.randomDialogT = G.rand(...CFG.dialog.randomEvery);
      const pool = Object.keys(G.CAST).filter(k => (G.CAST[k].lv || 1) === G.LEVEL.n && G.CAST[k].zones.includes(z) && G.PEOPLE[k]);
      if (pool.length) {
        const who = G.pick(pool), c = G.CAST[who];
        const line = (c.lines.length && Math.random() < 0.55) ? G.pick(c.lines) : G.pick(G.GENERIC_LINES);
        g.npcs.push(new G.BgNPC(who, line, g.camX));
      }
    }
    // transeúntes sin diálogo
    const amb = G.LEVEL.ambient[z] || {};
    g.walkerT -= dt;
    if (g.walkerT <= 0) {
      g.walkerT = G.rand(...(amb.every || [2.5, 6]));
      if (amb.walkers && Math.random() < (amb.chance ?? 1)) g.npcs.push(new G.BgNPC(G.pick(amb.walkers), null, g.camX, { vx: amb.still ? 0 : G.pick([-14, 12, -8, 0]) }));
    }
    // tráfico (mismos vehículos; los del mismo carril no se enciman)
    g.trafficT -= dt;
    if (g.trafficT <= 0) {
      g.trafficT = amb.traffic ? G.rand(...amb.traffic) : 99;
      if (amb.traffic) {
        const moto = Math.random() < (amb.motoChance || 0);
        const patrol = !moto && Math.random() < (amb.patrolChance || 0);
        const c = new G.Car(g.camX, moto ? { moto: true } : patrol ? { patrol: true } : {});
        if (G.Car.fits(c, g.cars)) g.cars.push(c); else g.trafficT = 0.4;
      }
      if (amb.honk && Math.random() < amb.honk) G.Audio.sfx('honk');
    }
    // partículas ambientales
    const pt = amb.particles;
    if (pt === 'leaves' && Math.random() < dt * 1.2) G.FX.add({ x: g.camX + CFG.W + 5, y: G.rand(60, 140), vx: -G.rand(30, 60), vy: G.rand(5, 20), g: 5, life: 6, max: 6, color: G.pick(['#4a9a3a', '#7ac04a']), size: 2, wobble: 2 });
    if (pt === 'embers' && Math.random() < dt * 6) G.FX.add({ x: g.camX + G.rand(0, CFG.W + 40), y: CFG.H, vx: -10, vy: -G.rand(15, 35), g: -2, life: 4, max: 4, color: G.pick([P.orange, P.red, P.yellow]) });
    if (pt === 'papers' && Math.random() < dt * 3) G.FX.add({ x: g.camX + CFG.W + 5, y: G.rand(30, 140), vx: -G.rand(60, 120), vy: G.rand(-10, 10), g: 0, life: 5, max: 5, color: '#e4e0d4', size: 2, wobble: 3 });
    if (pt === 'green' && Math.random() < dt * 5) G.FX.add({ x: g.camX + G.rand(0, CFG.W + 40), y: CFG.H, vx: -10, vy: -G.rand(15, 35), g: -2, life: 4, max: 4, color: G.pick(['#39ff14', '#1fbf0a', '#c8ffb0']) });
  }

  /* ------------------------------ colisiones ------------------------------ */
  const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  function collisions(dt) {
    const g = game, pl = g.player;
    if (pl.mode === 'dead') return;
    const ph = pl.hitbox();
    for (const o of g.obstacles) {
      if (o.dead || o.hit) continue;
      const hb = o.hb(g.camX);
      if (!o.passed && hb.x + hb.w < ph.x - 2) {
        o.passed = true; g.stats.obstacles++; g.addScore(CFG.score.obstacle);
        if (o.def.minion && g.boss) { g.boss.missed = (g.boss.missed || 0) + 1; if (g.boss.missed % 2 === 0) G.Dialog.narrate(g.boss.cfg.missHint, 3.4); }
      }
      if (o.passed) continue;
      if (o.def.hazard && !pl.onGround) continue;
      const prevBottom = ph.y + ph.h - pl.vy * dt;
      const canStomp = o.def.stomp && pl.vy > 0 && prevBottom <= hb.y + 8;
      if (!overlap(ph, canStomp ? { x: hb.x - 4, y: hb.y - 2, w: hb.w + 8, h: hb.h } : hb)) continue;
      if (canStomp) {
        o.knock(); o.passed = true; pl.vy = -280; pl.onGround = false;
        g.stats.stomps++; G.Audio.sfx('stomp'); g.addScore(CFG.score.stomp, o.x - g.camX, o.y - 30);
        G.FX.burst(o.x + 6, o.y - 20, 10, [P.white, P.yellow], 70);
        if (o.def.minion && g.boss) g.boss.damage();
        if (o.def.heal && g.hearts < CFG.hearts) { g.hearts++; G.Audio.sfx('coin'); g.popups.push({ x: o.x, y: o.y - 40, text: '+♥', t: 0 }); }
        if (o.def.vehicle) { G.Audio.sfx('explode'); G.FX.burst(o.x + 30, o.y - 10, 16, ['#555', '#888', P.orange], 90); }
        const sl = G.LEVEL.stompLines && G.LEVEL.stompLines[g.zone];
        if (o.def.person) g.playerSay('¡Hay... un chiriguillo!');
        else if (sl && Math.random() < 0.6) g.playerSay(G.pick(sl));
        continue;
      }
      if (pl.invuln > 0 || G.DEBUG.god) continue;
      hurt(o);
    }
  }
  function hurt(o) {
    const g = game, pl = g.player;
    g.hearts--; g.stats.hits++;
    (g.debugHits = g.debugHits || []).push(o.def.id + '@' + g.prog().toFixed(3) + (pl.onGround ? 'G' : 'A') + (pl.ducking ? 'D' : ''));
    o.hit = true;
    pl.invuln = CFG.invuln; pl.mode = 'hit'; pl.modeT = 0;
    if (pl.onGround) { pl.vy = -170; pl.onGround = false; }
    g.shake(0.3, 3); G.Audio.sfx('hit');
    if (o.def.hazard === 'splash') { G.Audio.sfx('splash'); G.FX.burst(o.x + 12, GROUND, 18, [P.water, P.waterL], 90, { up: 60 }); g.playerSay(G.pick(['¡Mis tenis!', '¡Ugh, charco!', '¡Ahora huelo a drenaje!'])); }
    else if (o.def.hazard === 'ditch') { G.FX.burst(o.x + 12, GROUND, 12, ['#5a4030', '#8a6a4a'], 70); g.playerSay('¡¿Quién dejó este hoyo?!'); }
    else { o.knock(); G.FX.burst(pl.wx(), pl.y - 12, 10, [P.white, P.yellow, P.red], 80); if (o.def.person) g.playerSay('¡Hay... un chiriguillo!'); else if (Math.random() < 0.5) g.playerSay(G.pick(G.LEVEL.hurtLines)); }
    if (g.hearts <= 0) g.die();
  }

  /* ------------------------------ autopiloto (pruebas) ------------------------------ */
  function autopilot() {
    const g = game, pl = g.player;
    let duck = false;
    const ph = pl.hitbox();
    let best = null, bestT = 9;
    for (const o of g.obstacles) {
      if (o.dead || o.hit || o.passed) continue;
      const hb = o.hb(g.camX);
      const rel = g.speed - o.vx;
      const tt = (hb.x - (ph.x + ph.w)) / rel;
      if (tt < -0.15 - (hb.w + (pl.isBus ? ph.w : 0)) / rel) continue;
      if (o.def.decoy || (o.def.air >= 28 && !pl.isBus && !pl.isRobot)) continue;
      if (tt < bestT) { bestT = tt; best = { o, hb, rel }; }
    }
    if (best) {
      const { o } = best;
      const duckH = pl.ducking ? ph.h + 2 : (pl.isRobot ? 36 : pl.isBus ? 26 : 13);
      if (o.def.air > duckH) duck = bestT < 0.45;
      else if (o.def.stomp && !(o.def.air >= 28) && bestT < (pl.isBus ? 0.25 : pl.isRobot ? 0.6 : 0.47) && pl.onGround) { I._jump = true; I.jumpHeld = true; g._autoHold = 0.4; }
      else if (bestT < 0.11 + (o.h > 16 ? 0.02 : 0) && pl.onGround) { I._jump = true; I.jumpHeld = true; g._autoHold = pl.isBus ? 1.1 : 0.32; }
    }
    if (g._autoHold > 0) { g._autoHold -= 1 / 120; if (g._autoHold <= 0) I.jumpHeld = false; }
    I.duckHeld = duck && pl.onGround;
  }

  /* ------------------------------ actualización ------------------------------ */
  game.update = function (dt) {
    const g = game;
    g.t += dt;
    if (I.pause() && ['PLAYING', 'BOSS', 'ENDING'].includes(g.state)) { g.paused = !g.paused; G.Audio.sfx('select'); }
    if (g.paused) { I.jumpPressed(); return; }
    if (g.shakeT > 0) g.shakeT -= dt; else g.shakeMag = 0;
    g.zoneVis.t += dt;
    if (g.flash > 0) g.flash -= dt;
    if (g.titleCard) { g.titleCard.t += dt; if (g.titleCard.t > 3) g.titleCard = null; }

    switch (g.state) {
      case 'SPLASH':
        if (I.confirm()) { G.Audio.init(); G.Audio.sfx('select'); g.state = 'MENU'; g.t = 0; G.Audio.play('menu'); I.clearEdges(); }
        I.jumpPressed();
        return;
      case 'MENU':
        if (I.confirm()) { G.Audio.init(); G.Audio.sfx('select'); g.newGame(G.START_LEVEL || 1); }
        I.jumpPressed();
        G.FX.update(dt);
        return;
      case 'INTRO': updateIntro(dt); break;
      case 'SCENE': updateScene(dt); break;
      case 'PLAYING': case 'BOSS': updatePlay(dt); break;
      case 'ENDING': updateEnding(dt); break;
      case 'GAME_OVER':
        if (I.restart()) { G.Audio.sfx('select'); g.newGame(); }
        else if (I.confirm()) { G.Audio.sfx('select'); g.retry(); }
        I.jumpPressed();
        break;
      case 'VICTORY': {
        // créditos: el camión avanza por la carretera con la cámara siguiéndolo
        g.speed = G.lerp(g.speed || 0, 110, dt * 1.5);
        g.camX += g.speed * dt;
        if (G.LEVEL.player !== 'walk') { g.player.visible = true; g.player.update(dt, g.speed, false); }
        else if (g.ending) { g.ending.full = true; g.ending.door = false; g.ending.busX = g.camX + CFG.W / 2 - 70; }
        g.cars = g.cars.filter(c => c.update(dt, g.camX));
        if (Math.random() < dt * 4) G.FX.confetti(2);
        CREDITS_T = G.LEVEL.statsFirst ? 0 : (G.LEVEL.creditsT || 9);
        if (G.LEVEL.statsFirst) {
          // final del juego: primero las estadísticas, luego la pantalla de despedida (se queda fija)
          if (!g.finalScr) { if (g.t > 1 && I.confirm()) { G.Audio.sfx('select'); g.toFinal(); } }
          else { g.ft += dt; if (g.ft > 1.5 && I.confirm()) { G.Audio.sfx('select'); g.state = 'MENU'; g.t = 0; G.Audio.play('menu'); } }
        }
        else if (g.t < CREDITS_T) { if (I.confirm() && g.t > 0.8) g.t = CREDITS_T; }
        else if (g.t > CREDITS_T + 1 && I.confirm()) { G.Audio.sfx('select'); g.newGame(Math.min(3, G.LEVEL.n + 1)); }
        I.jumpPressed();
        break;
      }
    }
    G.FX.update(dt);
    G.Dialog.update(dt);
    for (const p of g.popups) { p.t += dt; p.y -= 20 * dt; }
    g.popups = g.popups.filter(p => p.t < 0.9);
  };

  function updateIntro(dt) {
    const g = game, pl = g.player, t = g.t;
    I.confirm();
    if (G.LEVEL.intro === 'drive') {
      if (t > 0.3 && t - dt <= 0.3) { G.Dialog.narrate(G.LEVEL.introNarr || (G.LEVEL.title + ': LA CARRETERA'), 2.4); G.Audio.sfx('horn'); }
      if (t > 1.2 && t - dt <= 1.2) g.playerSay(G.LEVEL.introSay || '¡Ahora me toca manejar!');
      g.speed = Math.min(CFG.speedStart * 0.7, g.speed + 60 * dt);
      g.camX += g.speed * dt; g.pd = Math.min(g.pd + g.speed * dt, 0.01 * L);
      pl.update(dt, g.speed, false);
      if (t > 3.2 || (I.jumpPressed() && t > 1)) {
        g.state = 'PLAYING'; g.hintT = 6;
        g.randomDialogT = 5; g.walkerT = 1; g.trafficT = 1.5;
        g.zone = -1; g.setZone(0);
      }
      return;
    }
    if (t > 0.7 && t - dt <= 0.7) { G.Audio.sfx('door'); g.houseOpen = true; }
    if (t > 1.0 && t - dt <= 1.0) { pl.visible = true; pl.mode = 'stand'; G.FX.burst(80, GROUND - 4, 6, ['#d8d0c0'], 30); }
    if (t > 1.6 && t - dt <= 1.6) { g.houseOpen = false; G.Audio.sfx('door'); g.playerSay(G.NARR.intro); }
    const skip = I.jumpPressed() && t > 2.0;
    if (skip && t < 6.2) { g.t = 6.2; G.Dialog.bubbles = []; }
    if (g.t > 6.2) {
      pl.mode = 'normal';
      pl.sx += 46 * dt; pl.dist += 46 * dt;
      if (pl.sx >= CFG.PLAYER_X) {
        pl.sx = CFG.PLAYER_X;
        g.state = 'PLAYING'; g.speed = 46; g.hintT = 6;
        g.randomDialogT = 6; g.walkerT = 1.5; g.trafficT = 3;
        g.zone = -1; g.setZone(0);
      }
    }
    pl.update(dt, 0, false);
  }

  function updatePlay(dt) {
    const g = game, pl = g.player;
    if (G.DEBUG.auto) autopilot();
    const dead = pl.mode === 'dead';
    if (dead) {
      g.deathT += dt;
      g.speed = Math.max(0, g.speed - 200 * dt);
      if (g.deathT > 1.6) { g.state = 'GAME_OVER'; g.t = 0; I.clearEdges(); }
    } else if (g.state === 'BOSS') {
      g.speed = G.lerp(g.speed, CFG.bossSpeed, dt * 2);
    } else {
      const target = G.lerp(CFG.speedStart, CFG.speedMax, G.clamp(g.prog() / 0.8, 0, 1));
      g.speed = g.speed < target ? Math.min(target, g.speed + 50 * dt) : target;
    }
    g.time += dt; if (!dead) g.clock += dt;
    g.camX += g.speed * dt;
    if (g.state === 'PLAYING') g.pd += g.speed * dt;
    if (g.hintT > 0) g.hintT -= dt;

    const prog = g.prog();
    if (g.state === 'PLAYING') {
      const z = g.zoneAt(prog);
      if (z !== g.zone && z <= 3) g.setZone(z);
      while (g.evIdx < G.EVENTS.length && prog >= G.EVENTS[g.evIdx].at) fireEvent(G.EVENTS[g.evIdx++]);
      const o = CFG.obstacles;
      g.spawner.active = !dead && prog > o.warmup && prog < 0.8 - o.calmBeforeBoss;
      if (prog >= 0.8 && !dead) { g.startBoss(); }
    }
    pl.update(dt, g.speed, !dead);
    const diff = G.clamp(prog / 0.8, 0, 1);
    g.spawner.update(Math.min(g.zone, 3), prog, diff);
    for (const o of g.obstacles) o.update(dt, g.camX);
    g.obstacles = g.obstacles.filter(o => o.x - g.camX > -80 && o.y < CFG.H + 60);
    collisions(dt);
    if (g.boss) g.boss.update(dt);
    if (G.LEVEL.allies && g.state === 'BOSS' && G.Allies) G.Allies.update(dt, g.boss);
    if (g.state === 'PLAYING' || g.state === 'BOSS') ambient(dt);
    g.npcs = g.npcs.filter(n => n.update(dt, g.camX));
    g.cars = g.cars.filter(c => c.update(dt, g.camX));
    if (g.zone === 4 && Math.random() < dt * 0.25) { g.flash = 0.25; }
  }

  function updateEnding(dt) {
    const g = game, pl = g.player, e = g.ending;
    e.t += dt; g.time += dt;
    I.confirm();
    G.FX.update(0);
    if (e.phase === 'drive') {
      g.clock += dt;
      g.speed = G.lerp(g.speed, 120, dt * 2);
      g.camX += g.speed * dt;
      pl.update(dt, g.speed, true);
      g.pd = G.clamp(L - (e.finishX - (g.camX + pl.sx + 64)), 0.95 * L, L);
      g.cars = g.cars.filter(c => c.update(dt, g.camX));
      for (const o of g.obstacles) o.update(dt, g.camX);
      if (g.pd >= L) {
        e.phase = 'finished'; e.t = 0; G.Audio.play(G.LEVEL.victoryMusic || 'victory'); G.Audio.sfx('confetti'); G.Audio.sfx('horn');
        G.FX.confetti(80); game.shake(0.2, 2);
      }
    } else if (e.phase === 'finished') {
      g.speed = Math.max(0, g.speed - 90 * dt); g.camX += g.speed * dt;
      pl.update(dt, g.speed, false);
      if (Math.random() < dt * 6) G.FX.confetti(3);
      if (e.t > 3.2) { g.state = 'VICTORY'; g.t = 0; g.finalScr = false; g.ft = 0; I.clearEdges(); finalScore(); }
    } else if (e.phase === 'walk') {
      g.clock += dt;
      g.speed = G.lerp(g.speed, 92, dt * 2);
      const busSX = e.busX - g.camX;
      if (!e.locked && busSX + 140 <= CFG.W - 8) e.locked = true;
      if (!e.locked) { g.camX += g.speed * dt; }
      else { pl.sx += 62 * dt; pl.dist += 62 * dt - g.speed * dt; }
      pl.update(dt, g.speed, true);
      g.pd = G.clamp(L - (e.doorX - pl.wx()), 0.95 * L, L);
      g.npcs = g.npcs.filter(n => n.update(dt, g.camX));
      g.cars = g.cars.filter(c => c.update(dt, g.camX));
      for (const o of g.obstacles) o.update(dt, g.camX);
      g.obstacles = g.obstacles.filter(o => o.x - g.camX > -80 && o.y < CFG.H + 60);
      if (pl.wx() >= e.doorX && pl.onGround) {
        e.phase = 'arrive'; e.t = 0; pl.mode = 'stand'; g.pd = L; e.door = true; G.Audio.sfx('busdoor');
      }
    } else if (e.phase === 'arrive') {
      pl.modeT += dt;
      if (e.t > 0.6 && e.t - dt <= 0.6) {
        pl.mode = 'win'; pl.modeT = 0; G.Audio.play(G.LEVEL.victoryMusic || 'victory'); G.Audio.sfx('confetti');
        G.FX.confetti(70); game.shake(0.2, 2);
        G.FX.burst(pl.wx(), pl.y - 20, 30, [P.yellow, P.white, P.green, P.orange], 120, { size: 2 });
      }
      if (e.t > 0.6 && e.t < 2.6) { pl.y = GROUND - Math.abs(Math.sin((e.t - 0.6) * 6)) * 10; }
      if (e.t > 2.8 && e.t - dt <= 2.8) { pl.visible = false; pl.y = GROUND; G.Audio.sfx('door'); }
      if (e.t > 3.3 && e.t - dt <= 3.3) { e.door = false; e.full = true; G.Audio.sfx('busdoor'); }
      if (e.t > 3.9 && e.t - dt <= 3.9) G.Audio.sfx('horn');
      if (e.t > 4.0) { e.busVX = Math.min(220, e.busVX + 90 * dt); e.busX += e.busVX * dt; if (Math.random() < 0.5) G.FX.add({ x: e.busX + 2, y: GROUND - 6, vx: -30, vy: -10, g: -5, life: 0.8, max: 0.8, color: '#9a9a9a', size: 2 }); }
      if (e.t > 5.6) { g.state = 'VICTORY'; g.t = 0; g.finalScr = false; g.ft = 0; I.clearEdges(); finalScore(); }
    }
  }
  function finalScore() {
    const g = game;
    g.score += Math.floor(L / CFG.pxPerMeter) * CFG.score.perMeter;
    if (g.stats.hits === 0) g.score += CFG.score.noHitBonus;
    g.score += Math.max(0, Math.floor(3000 - g.clock * 8));
  }

  /* ------------------------------ render ------------------------------ */
  game.render = function (ctx) {
    const g = game;
    g.buttons = [];
    ctx.imageSmoothingEnabled = false;
    if (g.state === 'MENU') { drawMenu(ctx); drawTouchUI(ctx); return; }
    if (g.state === 'SPLASH') { drawSplash(ctx); return; }
    if (g.state === 'SCENE') {
      const def = G.Scenes[g.scene.name];
      ctx.save(); if (g.shakeT > 0) ctx.translate(Math.round(G.rand(-g.shakeMag, g.shakeMag)), Math.round(G.rand(-g.shakeMag, g.shakeMag)));
      if (def.overlay) drawWorld(ctx);
      def.draw(ctx, g.scene);
      ctx.restore();
      if (g.flash > 0) { ctx.fillStyle = 'rgba(255,255,255,' + Math.min(1, g.flash * 1.6).toFixed(2) + ')'; ctx.fillRect(0, 0, CFG.W, CFG.H); }
      G.Dialog.draw(ctx);
      if (g.scene.t > 1 && g.scene.name !== 'wings') G.text(ctx, I.touch ? 'TOCA PARA SALTAR ESCENA' : 'ENTER: SALTAR ESCENA', CFG.W - 4, CFG.H - 8, P.greyL, { align: 'right', outline: P.ink });
      return;
    }
    ctx.save();
    if (g.shakeT > 0) ctx.translate(Math.round(G.rand(-g.shakeMag, g.shakeMag)), Math.round(G.rand(-g.shakeMag, g.shakeMag)));
    drawWorld(ctx);
    ctx.restore();
    G.Dialog.draw(ctx);
    drawHUD(ctx);
    if (g.titleCard) drawTitleCard(ctx);
    if (g.state === 'ENDING' && g.ending.phase === 'arrive' && g.ending.t > 0.6) drawBigBanner(ctx, Math.min(1, (g.ending.t - 0.6) * 3));
    if (g.state === 'ENDING' && g.ending.phase === 'finished') drawBigBanner(ctx, Math.min(1, g.ending.t * 3));
    if (g.state === 'GAME_OVER') drawGameOver(ctx);
    if (g.state === 'VICTORY') drawVictory(ctx);
    if (g.paused) drawPause(ctx);
    drawTouchUI(ctx);
  };

  function drawWorld(ctx) {
    const g = game, zv = g.zoneVis;
    const a = Math.min(1, zv.t / 2.5);
    const both = a < 1 && zv.prev !== zv.cur;
    if (both) G.drawBackdrop(ctx, zv.prev, g.camX, 1);
    G.drawBackdrop(ctx, zv.cur, g.camX, both ? a : 1);
    if (zv.cur === 17) G.drawCdmxFx(ctx, g.t);
    for (const n of g.npcs) n.draw(ctx, g.camX);
    if (G.ZV[zv.cur].fog) drawFog(ctx, zv.cur);
    if (both) G.drawRoad(ctx, zv.prev, g.camX, 1);
    G.drawRoad(ctx, zv.cur, g.camX, both ? a : 1);
    for (const c of g.cars) if (c.dir > 0) c.draw(ctx, g.camX);
    for (const c of g.cars) if (c.dir < 0) c.draw(ctx, g.camX);
    if (both) G.drawGround(ctx, zv.prev, g.camX, 1);
    G.drawGround(ctx, zv.cur, g.camX, both ? a : 1);
    // casa del protagonista
    const hx = 20 - Math.round(g.camX);
    if (hx > -100 && G.LEVEL.intro === 'house') ctx.drawImage(g.houseOpen ? S.houseOpen : S.house, hx, GROUND - 64);
    // camión y parada
    if (g.ending && g.ending.finishX) { // arco de meta del nivel 2
      const fx = Math.round(g.ending.finishX - g.camX);
      if (fx > -40 && fx < CFG.W + 40) {
        ctx.fillStyle = '#d8d8d8'; ctx.fillRect(fx - 2, GROUND - 76, 4, 78); ctx.fillRect(fx + 70, GROUND - 76, 4, 78);
        ctx.fillStyle = '#14101e'; ctx.fillRect(fx - 4, GROUND - 90, 82, 16);
        for (let k = 0; k < 20; k++) { ctx.fillStyle = k % 2 ? '#14101e' : '#f4f4f4'; ctx.fillRect(fx - 4 + k * 4, GROUND - 74, 4, 3); }
        G.text(ctx, G.LEVEL.finishText || 'FIN DE LA RUTA', fx + 37, GROUND - 86, P.yellow, { align: 'center' });
      }
    }
    if (g.ending && g.ending.busX !== undefined) {
      const e = g.ending, bx = Math.round(e.busX - g.camX);
      if (e.phase === 'walk' || e.t < 4.2) ctx.drawImage(S.stop, Math.round(e.doorX - 76 - g.camX), GROUND - 34);
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(bx + 4, GROUND - 2, 132, 4);
      ctx.drawImage(e.full ? S.busFull : e.door ? S.busOpen : S.bus, bx, GROUND - 48);
    }
    for (const o of g.obstacles) if (o.def.hazard) o.draw(ctx, g.camX);
    for (const o of g.obstacles) if (!o.def.hazard) o.draw(ctx, g.camX);
    if (g.boss) g.boss.draw(ctx);
    if (G.LEVEL.allies && g.state === 'BOSS' && G.Allies) G.Allies.draw(ctx);
    g.player.draw(ctx);
    G.FX.draw(ctx, g.camX);
    for (const p of g.popups) G.text(ctx, p.text, p.x - g.camX, p.y, P.yellow, { outline: P.ink });
    if (g.flash > 0) { ctx.fillStyle = 'rgba(255,255,255,' + (g.flash * 1.6).toFixed(2) + ')'; ctx.fillRect(0, 0, CFG.W, CFG.H); }
    if (G.ZV[zv.cur].fog) { // viñeta oscura
      ctx.fillStyle = 'rgba(10,0,20,0.25)'; ctx.fillRect(0, 0, CFG.W, 6); ctx.fillRect(0, CFG.H - 6, CFG.W, 6);
    }
  }
  function drawFog(ctx, z) {
    const g = game;
    for (let i = 0; i < 4; i++) {
      const y = 80 + i * 14 + Math.sin(g.t * 0.5 + i) * 4;
      const off = ((g.t * (8 + i * 4) + g.camX * 0.2 * (i + 1)) % 160);
      ctx.fillStyle = z === 4 ? 'rgba(120,40,60,0.10)' : z === 10 ? 'rgba(240,138,36,0.07)' : 'rgba(200,190,220,0.10)';
      for (let x = -160; x < CFG.W + 160; x += 160) ctx.fillRect(Math.round(x - off), Math.round(y), 120, 10);
    }
  }

  function fmtTime(s) { s = Math.floor(s); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); }
  G.fmtTime = fmtTime;

  function drawHUD(ctx) {
    const g = game;
    if (g.state === 'INTRO' && g.t < 6 && G.LEVEL.intro === 'house') return;
    ctx.fillStyle = 'rgba(20,16,30,0.78)'; ctx.fillRect(0, 0, CFG.W, 22);
    ctx.fillStyle = P.ink; ctx.fillRect(0, 22, CFG.W, 1);
    // barra de progreso CASA ━━━●━━━ CAMIÓN
    ctx.drawImage(G.LEVEL.hudStart(), 3, 2);
    const bx = 16, bw = CFG.W - 102, by = 5;
    for (const z of CFG.zones) {
      const x0 = bx + Math.round(z.start * bw), x1 = bx + Math.round(z.end * bw);
      ctx.fillStyle = G.mixHex(z.color, '#1a1c2c', 0.6); ctx.fillRect(x0, by, x1 - x0, 3);
      ctx.fillStyle = P.ink; ctx.fillRect(x1 - 1, by - 1, 1, 5);
    }
    const dp = g.displayProg();
    for (const z of CFG.zones) {
      const x0 = bx + Math.round(z.start * bw), x1 = bx + Math.round(Math.min(z.end, dp) * bw);
      if (x1 > x0) { ctx.fillStyle = z.color; ctx.fillRect(x0, by, x1 - x0 - (x1 === bx + Math.round(z.end * bw) ? 1 : 0), 3); }
    }
    ctx.drawImage(S.playerHead, Math.round(bx + dp * bw - 4), 0);
    ctx.drawImage(G.LEVEL.hudEnd(), bx + bw + 4, 3);
    G.text(ctx, Math.floor(dp * 100) + '%', CFG.W - 64, 4, P.white);
    G.text(ctx, fmtTime(g.clock), CFG.W - 4, 4, P.greyL, { align: 'right' });
    // fila 2
    for (let i = 0; i < CFG.hearts; i++) ctx.drawImage(i < g.hearts ? S.heart : S.heartE, 3 + i * 8, 13);
    const z = CFG.zones[Math.max(0, g.zone)];
    G.text(ctx, z.name, 30, 14, z.color);
    const left = Math.max(0, Math.round((1 - dp) * L / CFG.pxPerMeter));
    G.text(ctx, 'FALTAN ' + left + ' M', CFG.W / 2 + 36, 14, P.white, { align: 'center' });
    G.text(ctx, 'PTS ' + String(g.score).padStart(6, '0'), CFG.W - 4, 14, P.yellow, { align: 'right' });
    // barra del jefe
    if (g.boss && g.boss.state !== 'gone') {
      const b = g.boss, k = b.shown;
      const w = Math.min(CFG.W - 16, Math.max(160, G.textWidth(CFG.boss.name, 1) + G.textWidth(CFG.boss.title, 1) + 14)), x = Math.round((CFG.W - w) / 2), y = 30;
      ctx.globalAlpha = k;
      G.box(ctx, x - 4, y - 4, w + 8, 18, 'rgba(20,16,30,0.85)', P.redD, null);
      G.text(ctx, CFG.boss.name, x, y - 1, P.white);
      G.text(ctx, CFG.boss.title, x + w, y - 1, P.orange, { align: 'right' });
      ctx.fillStyle = P.ink; ctx.fillRect(x, y + 6, w, 5);
      const hpw = Math.round((w - 2) * Math.max(0, b.hp) / b.max);
      ctx.fillStyle = b.flash > 0 ? P.white : P.red; ctx.fillRect(x + 1, y + 7, hpw, 3);
      ctx.fillStyle = P.ink; for (let i = 1; i < b.max; i++) ctx.fillRect(x + 1 + Math.round((w - 2) * i / b.max), y + 7, 1, 3);
      ctx.globalAlpha = 1;
    }
    // ayuda de controles
    if (g.hintT > 0 && g.state === 'PLAYING') {
      ctx.globalAlpha = Math.min(1, g.hintT);
      const s = I.touch ? 'TOCA A LA DERECHA: SALTAR    MANTÉN IZQUIERDA: AGACHARSE' : G.LEVEL.hint.keys;
      G.box(ctx, CFG.W / 2 - G.textWidth(s) / 2 - 5, CFG.H - 14, G.textWidth(s) + 10, 11, 'rgba(20,16,30,0.85)', P.greyD, null);
      G.text(ctx, s, CFG.W / 2, CFG.H - 11, P.white, { align: 'center' });
      ctx.globalAlpha = 1;
    }
  }

  function drawTitleCard(ctx) {
    const c = game.titleCard;
    const k = c.t < 0.4 ? c.t / 0.4 : c.t > 2.5 ? Math.max(0, 1 - (c.t - 2.5) / 0.5) : 1;
    const x = Math.round(-200 + 200 * Math.min(1, c.t / 0.4) + (c.t > 2.5 ? (c.t - 2.5) * 600 : 0));
    ctx.globalAlpha = k;
    ctx.fillStyle = 'rgba(20,16,30,0.85)'; ctx.fillRect(0, 44, CFG.W, 26);
    ctx.fillStyle = c.color; ctx.fillRect(0, 44, CFG.W, 1); ctx.fillRect(0, 69, CFG.W, 1);
    G.text(ctx, 'ZONA ' + c.n, CFG.W / 2 + x, 48, P.greyL, { align: 'center' });
    G.text(ctx, c.name, CFG.W / 2 + x, 56, c.color, { align: 'center', scale: 2, shadow: P.ink });
    ctx.globalAlpha = 1;
  }
  function drawBigBanner(ctx, k) {
    ctx.globalAlpha = k;
    const s = G.LEVEL.victory;
    const y = 50 + Math.round(Math.sin(game.t * 4) * 2);
    ctx.fillStyle = 'rgba(20,16,30,0.7)'; ctx.fillRect(0, y - 6, CFG.W, 22);
    G.text(ctx, s, CFG.W / 2, y, P.yellow, { align: 'center', scale: 2, outline: P.ink });
    ctx.globalAlpha = 1;
  }

  function button(ctx, label, x, y, w, h, action, color = P.green) {
    const hover = game.hoverBtn === label;
    G.box(ctx, x, y, w, h, hover ? G.mixHex(color, '#ffffff', 0.25) : color, P.ink, 'rgba(0,0,0,0.5)');
    G.text(ctx, label, x + w / 2, y + Math.floor((h - 5) / 2), P.white, { align: 'center', shadow: P.ink });
    game.buttons.push({ x, y, w, h, action, label });
  }

  /* Fondo del menú: el mural con el personaje, completo y sin marcos; los lados se rellenan
     con el mismo mural desenfocado para cualquier ancho de pantalla */
  function drawMural(ctx) {
    const g = game, img = g.images.menu, bg = g.images.menuBg;
    if (bg && bg.complete && bg.naturalWidth) ctx.drawImage(bg, Math.round((CFG.W - bg.naturalWidth) / 2), 0);
    else { ctx.fillStyle = '#0e0b16'; ctx.fillRect(0, 0, CFG.W, CFG.H); }
    if (img && img.complete && img.naturalWidth) {
      const k = CFG.H / img.naturalHeight, w = Math.round(img.naturalWidth * k);
      ctx.drawImage(img, Math.round((CFG.W - w) / 2), 0, w, CFG.H);
    }
  }
  function drawSplash(ctx) {
    const g = game;
    drawMural(ctx);
    if (Math.floor(g.t * 2) % 2 === 0) G.text(ctx, I.touch ? 'TOCA LA PANTALLA PARA COMENZAR' : 'PRESIONA CUALQUIER TECLA O HAZ CLIC', CFG.W / 2, 166, P.white, { align: 'center', outline: P.ink });
  }
  function drawMenu(ctx) {
    const g = game;
    drawMural(ctx);
    const blink = Math.floor(g.t * 2) % 2 === 0;
    button(ctx, (G.START_LEVEL > 1 ? '▶ NIVEL ' + G.START_LEVEL : '▶ JUGAR') + (I.touch ? '' : ' (ESPACIO)'), CFG.W / 2 - 46, 146, 92, 13, () => { G.Audio.init(); G.Audio.sfx('select'); g.newGame(G.START_LEVEL || 1); }, blink ? P.green : '#1f7d36');
    G.text(ctx, I.touch ? 'TOCA LA DERECHA: SALTAR   MANTÉN LA IZQUIERDA: AGACHARSE' : '▲ W / ESPACIO: SALTAR   ▼ S: AGACHAR   P: PAUSA   M: MÚSICA', CFG.W / 2, 166, P.white, { align: 'center', outline: P.ink });
    G.FX.draw(ctx, 0);
  }

  function drawGameOver(ctx) {
    const g = game;
    ctx.fillStyle = 'rgba(20,10,20,0.7)'; ctx.fillRect(0, 0, CFG.W, CFG.H);
    G.text(ctx, '¡LLEGASTE TARDE!', CFG.W / 2, 44, P.red, { align: 'center', scale: 2, outline: P.ink });
    G.text(ctx, G.LEVEL.n === 2 ? 'PERDERÁS EL BONO DE PUNTUALIDAD Y ASISTENCIA' : 'EL CAMIÓN NO ESPERA A NADIE...', CFG.W / 2, 64, P.white, { align: 'center' });
    const z = CFG.zones[Math.min(g.zoneAt(g.prog()), 4)];
    G.text(ctx, 'PUNTO DE CONTROL: ' + z.name, CFG.W / 2, 78, z.color, { align: 'center' });
    button(ctx, I.touch ? 'REINTENTAR' : 'REINTENTAR (ENTER)', CFG.W / 2 - 90, 96, 180, 15, () => { G.Audio.sfx('select'); g.retry(); }, P.green);
    button(ctx, I.touch ? 'EMPEZAR DE NUEVO' : 'EMPEZAR DE NUEVO (R)', CFG.W / 2 - 90, 116, 180, 15, () => { G.Audio.sfx('select'); g.newGame(); }, P.redD);
  }
  function drawPause(ctx) {
    const A = G.Audio, cx = CFG.W / 2;
    ctx.fillStyle = 'rgba(20,16,30,0.75)'; ctx.fillRect(0, 0, CFG.W, CFG.H);
    G.text(ctx, 'PAUSA', cx, 34, P.white, { align: 'center', scale: 3, outline: P.ink });
    button(ctx, '▶ CONTINUAR', cx - 60, 62, 120, 16, () => { game.paused = false; }, P.green);
    button(ctx, 'MÚSICA: ' + (A.musicOn ? 'SÍ' : 'NO'), cx - 60, 82, 120, 16, () => G.toggleMusic(), A.musicOn ? P.blueD : P.greyD);
    button(ctx, 'EFECTOS: ' + (A.sfxOn ? 'SÍ' : 'NO'), cx - 60, 102, 120, 16, () => G.toggleSfx(), A.sfxOn ? P.blueD : P.greyD);
    button(ctx, 'PANTALLA COMPLETA', cx - 60, 122, 120, 16, () => G.toggleFull(), P.purple);
    button(ctx, 'SALIR AL MENÚ', cx - 60, 142, 120, 16, () => { game.paused = false; G.Audio.play('menu'); game.state = 'MENU'; game.t = 0; }, P.redD);
  }
  /* controles táctiles dibujados sobre el juego */
  function drawTouchUI(ctx) {
    const g = game;
    if (!I.touch) return;
    if (['PLAYING', 'BOSS', 'ENDING', 'INTRO'].includes(g.state) && !g.paused) {
      const r = 15, y = CFG.H - r - 6;
      ctx.globalAlpha = I.duckHeld ? 0.6 : 0.28;
      ctx.fillStyle = '#000'; G.painter(ctx).circle(r + 8, y, r, I.duckHeld ? P.blue : '#14101e');
      ctx.globalAlpha = I.jumpHeld ? 0.6 : 0.28;
      G.painter(ctx).circle(CFG.W - r - 8, y, r, I.jumpHeld ? P.green : '#14101e');
      ctx.globalAlpha = 0.85;
      G.text(ctx, '▼', r + 8, y - 4, P.white, { align: 'center', scale: 2 });
      G.text(ctx, '▲', CFG.W - r - 8, y - 4, P.white, { align: 'center', scale: 2 });
      ctx.globalAlpha = 1;
      // botón de pausa
      button(ctx, 'II', CFG.W - 18, 25, 15, 12, () => { game.paused = true; G.Audio.sfx('select'); }, 'rgba(20,16,30,0.7)');
    }
    if (g.state === 'MENU') button(ctx, G.Audio.musicOn ? '♪' : '♪ X', CFG.W - 22, 6, 18, 12, () => G.toggleMusic(), 'rgba(20,16,30,0.7)');
  }
  function rank(st, time) {
    if (st.hits === 0) return 'LEYENDA DEL TRANSPORTE';
    if (st.hits <= 2 && !st.retries) return 'PUNTUALÍSIMO';
    if (st.hits <= 5 && st.retries <= 1) return 'CASI TARDE';
    return 'LLEGASTE DE MILAGRO';
  }
  let CREDITS_T = 9;
  game.toFinal = function () { game.finalScr = true; game.ft = 0; };
  function drawCredits(ctx, fin) {
    const g = game, t = fin ? g.ft : g.t;
    const lines = G.LEVEL.credits || [['¡FELICIDADES!', P.yellow, 2], ['PERDISTE EL BONO DE', P.white, 2], ['PUNTUALIDAD Y ASISTENCIA', P.white, 2], ['', P.white, 1], ['GRACIAS POR JUGAR', P.green, 2]];
    const a = fin ? Math.min(1, t * 1.5) : Math.min(1, t * 1.5, Math.max(0, (CREDITS_T - t) * 1.5));
    const tot = lines.reduce((s, l) => s + (l[2] === 2 ? 16 : 11), 0);
    if (fin) { ctx.globalAlpha = a * 0.82; ctx.fillStyle = '#14101e'; ctx.fillRect(0, 0, CFG.W, CFG.H); }
    else { ctx.globalAlpha = a * 0.6; ctx.fillStyle = '#14101e'; ctx.fillRect(0, 26, CFG.W, tot + 16); }
    ctx.globalAlpha = 1;
    let yy = fin ? 8 : 34;
    lines.forEach((l, i) => {
      const k = G.clamp((t - 0.4 - i * 0.7) * 2, 0, 1) * a, y = yy;
      yy += l[2] === 2 ? 16 : 11;
      if (k <= 0 || !l[0]) return;
      ctx.globalAlpha = k;
      G.text(ctx, l[0], CFG.W / 2, y + Math.round((1 - k) * 6), l[1], { align: 'center', scale: l[2], outline: P.ink, raw: !!l[3] });
    });
    ctx.globalAlpha = 1;
    if (fin) return drawFinalExtras(ctx, t);
    if (I.touch || t > 2) G.text(ctx, I.touch ? 'TOCA PARA CONTINUAR' : 'ENTER PARA CONTINUAR', CFG.W - 4, CFG.H - 8, P.greyL, { align: 'right' });
  }
  /* Despedida del juego: aportaciones, Instagram y comentarios */
  function drawFinalExtras(ctx, t) {
    const g = game, cx = Math.round(CFG.W / 2), k = G.clamp((t - 4.2) * 2, 0, 1);
    if (k <= 0) return;
    ctx.globalAlpha = k;
    G.text(ctx, 'APORTACIONES VOLUNTARIAS - TRANSFERENCIA AL:', cx, 106, P.greyL, { align: 'center' });
    const clabe = G.CLABE, cw = G.textWidth(clabe, 2) + 10;
    G.box(ctx, cx - cw / 2, 114, cw, 15, g.hoverBtn === 'CLABE' ? '#3a3450' : '#262036', '#fbe043', null);
    G.text(ctx, clabe, cx, 117, P.yellow, { align: 'center', scale: 2 });
    g.buttons.push({ x: cx - cw / 2, y: 114, w: cw, h: 15, label: 'CLABE', action: () => { G.copyText(clabe); g.copiedT = 2; G.Audio.sfx('coin'); } });
    G.text(ctx, g.copiedT > 0 ? '¡CLABE COPIADA!' : (I.touch ? 'TOCA PARA COPIAR' : 'CLIC PARA COPIAR'), cx, 132, g.copiedT > 0 ? P.green : P.greyD, { align: 'center' });
    if (g.copiedT > 0) g.copiedT -= 1 / 60;
    const bw = 92, gap = 6, bx = cx - Math.round((bw * 2 + 56 + gap * 2) / 2), by = 146;
    button(ctx, '   INSTAGRAM', bx, by, bw, 16, () => { G.Audio.sfx('select'); G.openIG(); }, '#a02a8a');
    ctx.drawImage(S.igIcon, bx + 6, by + 1);
    button(ctx, '✉ COMENTARIOS', bx + bw + gap, by, bw, 16, () => { G.Audio.sfx('select'); G.openComments(); }, P.purple);
    button(ctx, 'MENÚ', bx + bw * 2 + gap * 2, by, 56, 16, () => { G.Audio.sfx('select'); g.state = 'MENU'; g.t = 0; G.Audio.play('menu'); }, P.blueD);
    ctx.globalAlpha = 1;
  }
  function drawVictory(ctx) {
    const g = game, st = g.stats;
    if (G.LEVEL.statsFirst && g.finalScr) { drawCredits(ctx, true); G.FX.draw(ctx, game.camX); return; }
    if (g.t < CREDITS_T) return drawCredits(ctx);
    const k = Math.min(1, (g.t - CREDITS_T) * 2);
    ctx.globalAlpha = k;
    ctx.fillStyle = 'rgba(20,16,30,0.78)'; ctx.fillRect(0, 0, CFG.W, CFG.H);
    G.text(ctx, G.LEVEL.victory, CFG.W / 2, 8 + Math.round(Math.sin(g.t * 3) * 1.5), P.yellow, { align: 'center', scale: 2, outline: P.ink });
    // postal del camión real (carpeta objetivo)
    const img = g.images.bus;
    const OX = Math.round((CFG.W - 320) / 2), px = 14 + OX, py = 30, pw = 132, ph = 88;
    G.box(ctx, px - 3, py - 3, pw + 6, ph + 14, P.white, P.ink, 'rgba(0,0,0,0.5)');
    if (G.LEVEL.n === 3) {
      const sky = ctx.createLinearGradient(0, py, 0, py + ph); sky.addColorStop(0, '#4a2a6a'); sky.addColorStop(1, '#f8a060');
      ctx.fillStyle = sky; ctx.fillRect(px, py, pw, ph); ctx.fillStyle = '#ffffff'; ctx.fillRect(px, py + 74, pw, 14);
      ctx.save(); ctx.beginPath(); ctx.rect(px, py, pw, ph); ctx.clip();
      G.drawBusAt(ctx, px + pw / 2 - 2, py + 84, { wings: 1, fly: true }); ctx.restore();
      G.text(ctx, '¡LLEGASTE AL PENAL!', px + pw / 2, py + ph + 3, P.ink, { align: 'center' });
    } else if (G.LEVEL.n === 2) {
      const sky = ctx.createLinearGradient(0, py, 0, py + ph); sky.addColorStop(0, '#4fa6e0'); sky.addColorStop(1, '#fff0c0');
      ctx.fillStyle = sky; ctx.fillRect(px, py, pw, ph); ctx.fillStyle = '#4a4d54'; ctx.fillRect(px, py + 64, pw, 24);
      ctx.drawImage(S.busFull, 0, 0, 140, 50, px + 2, py + 30, 128, 46);
      G.text(ctx, '¡LA RUTA ES TUYA!', px + pw / 2, py + ph + 3, P.ink, { align: 'center' });
    } else {
      if (img && img.complete && img.naturalWidth) ctx.drawImage(img, px, py, pw, ph);
      else ctx.drawImage(S.bus, px - 4, py + 20, pw + 8, 48);
      G.text(ctx, '¡SÍ ALCANZASTE EL CAMIÓN!', px + pw / 2, py + ph + 3, P.ink, { align: 'center' });
    }
    // estadísticas
    const sx = 160 + OX; let y = 32;
    const row = (a, b, c = P.white) => { G.text(ctx, a, sx, y, P.greyL); G.text(ctx, String(b), 308 + OX, y, c, { align: 'right' }); y += 10; };
    row('TIEMPO TOTAL', fmtTime(g.clock));
    row('PUNTUACIÓN', String(g.score).padStart(6, '0'), P.yellow);
    row('OBSTÁCULOS SUPERADOS', st.obstacles);
    row(G.LEVEL.n === 1 ? 'MATONES PISADOS' : G.LEVEL.n === 2 ? 'POLICÍAS APLASTADOS' : 'ENEMIGOS APLASTADOS', st.stomps);
    if (g.totalCast()) row('PERSONAJES ENCONTRADOS', g.met.size + '/' + g.totalCast());
    row('GOLPES RECIBIDOS', st.hits, st.hits ? P.orange : P.green);
    row('JEFE', 'DERROTADO', P.green);
    y += 2;
    G.text(ctx, 'RANGO:', sx, y, P.greyL); y += 8;
    G.text(ctx, rank(st, g.clock), sx, y, P.yellow);
    if (g.t > CREDITS_T + 1) {
      if (G.LEVEL.n === 1) {
        button(ctx, '▶ NIVEL 2', CFG.W / 2 - 124, 156, 120, 15, () => { G.Audio.sfx('select'); g.newGame(2); }, P.green);
        button(ctx, 'VOLVER A JUGAR', CFG.W / 2 + 4, 156, 120, 15, () => { G.Audio.sfx('select'); g.newGame(1); }, P.blueD);
      } else if (G.LEVEL.n === 2) {
        button(ctx, '▶ NIVEL 3', CFG.W / 2 - 154, 156, 100, 15, () => { G.Audio.sfx('select'); g.newGame(3); }, P.green);
        button(ctx, 'VOLVER A JUGAR', CFG.W / 2 - 50, 156, 100, 15, () => { G.Audio.sfx('select'); g.newGame(2); }, P.blueD);
        button(ctx, 'MENÚ', CFG.W / 2 + 54, 156, 100, 15, () => { G.Audio.sfx('select'); g.state = 'MENU'; g.t = 0; G.Audio.play('menu'); }, P.purple);
      } else if (G.LEVEL.statsFirst) {
        button(ctx, I.touch ? '▶ CONTINUAR' : '▶ CONTINUAR (ENTER)', CFG.W / 2 - 124, 156, 120, 15, () => { G.Audio.sfx('select'); g.toFinal(); }, P.green);
        button(ctx, 'VOLVER A JUGAR', CFG.W / 2 + 4, 156, 120, 15, () => { G.Audio.sfx('select'); g.newGame(3); }, P.blueD);
      } else {
        button(ctx, '▶ VOLVER A JUGAR', CFG.W / 2 - 124, 156, 120, 15, () => { G.Audio.sfx('select'); g.newGame(3); }, P.green);
        button(ctx, 'MENÚ', CFG.W / 2 + 4, 156, 120, 15, () => { G.Audio.sfx('select'); g.state = 'MENU'; g.t = 0; G.Audio.play('menu'); }, P.blueD);
      }
    }
    ctx.globalAlpha = 1;
    G.FX.draw(ctx, game.camX);
  }
})();
