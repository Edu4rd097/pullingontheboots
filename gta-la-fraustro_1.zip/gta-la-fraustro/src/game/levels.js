/* =========================================================
   Niveles. Cada nivel reutiliza el mismo motor (obstáculos por tiempos de
   llegada, diálogos, jefe que manda achichincles que se aplastan) y solo
   cambia zonas, escenarios, elenco, vehículo del jugador y jefe.
   ========================================================= */
(function () {
  const G = window.G, CFG = G.CFG, S = G.SPR;
  const BASE = { gravity: CFG.gravity, jumpVel: CFG.jumpVel, fastFall: CFG.fastFall, speedStart: CFG.speedStart, speedMax: CFG.speedMax, bossSpeed: CFG.bossSpeed, PLAYER_X: CFG.PLAYER_X };
  const WALK = ['peaton', 'peaton2', 'peaton3'];

  /* ------------------------------ NIVEL 1 ------------------------------ */
  const L1 = {
    n: 1, title: 'NIVEL 1', player: 'walk', intro: 'house', ending: 'bus',
    zones: CFG.zones.map((z, i) => Object.assign({ vis: i }, z)),
    events: G.EVENTS, pools: null, physics: BASE,
    hudStart: () => S.houseIcon, hudEnd: () => S.busIcon,
    hurtLines: ['¡Auch!', '¡No manches!', '¡Mi cresta!', '¡Ay, mi rodilla!'],
    hint: { keys: '▲ ESPACIO / W: SALTAR    ▼ ABAJO / S: AGACHARSE    P: PAUSA' },
    ambient: [
      { walkers: WALK, every: [2.5, 6], traffic: [4, 8], particles: 'leaves' },
      { walkers: WALK, every: [2.5, 6], traffic: [1.2, 2.8], honk: 0.3, busChance: 0.2 },
      { walkers: WALK, every: [2.5, 6] },
      { walkers: ['misterio'], every: [2.5, 6], chance: 0.4, still: true, particles: 'embers' },
      { particles: 'papers' },
      { walkers: WALK, every: [2.5, 6], traffic: [6, 10] }
    ],
    boss: {
      name: CFG.boss.name, title: CFG.boss.title, hp: CFG.boss.hp,
      spr: () => S.boss, white: () => S.bossWhite, minion: 'achi', minionSay: null,
      patterns: {
        1: [['coneThrow'], ['paper'], ['coneThrow', 'paper'], ['paper', 'coneThrow']],
        2: [['coneThrow', 'coneThrow'], ['paper', 'paperHigh', 'coneThrow'], ['coneDrop', 'paper'], ['coneThrow', 'coneDrop']],
        3: [['coneThrow', 'paper', 'coneThrow'], ['coneDrop', 'coneThrow', 'paper'], ['paper', 'paper', 'coneThrow'], ['coneThrow', 'coneThrow', 'coneDrop']]
      },
      intro: [G.NARR.boss[0], G.NARR.boss[1]], fight: G.NARR.boss.slice(2), hurt: G.NARR.bossHurt, defeat: G.NARR.bossDefeat,
      hint: G.NARR.stompHint, missHint: '¡Cae ENCIMA del achichincle para quitarle una firma al jefe!'
    },
    victory: '¡OBJETIVO ALCANZADO!'
  };

  /* ------------------------------ NIVEL 2: LA CARRETERA ------------------------------ */
  Object.assign(G.CAST, {
    poli:       { lv: 2, name: 'POLICÍA', desc: 'Policía', zones: [0, 1, 2, 3], lines: ['¡Tengo hambre!', 'Es diciembre y la ley lo sabe.', 'Saca una Sor Juana... en corto.'] },
    transito:   { lv: 2, name: 'TRÁNSITO', desc: 'Tránsito', zones: [1, 2, 3], lines: ['¡Tengo hambre!', 'Es diciembre y la ley lo sabe.', 'Saca una Sor Juana... en corto.'] },
    estudiante: { lv: 2, name: 'EL DE LA PREPA', desc: 'Estudiante', zones: [0], lines: ['¡Llévame a la prepa!', 'Hoy hay examen y no estudié.'] },
    aficionado: { lv: 2, name: 'EL AFICIONADO', desc: 'Aficionado', zones: [1], lines: ['¡Hoy ganamos seguro!', '¡Arriba los de amarillo!'] },
    vagabundo:  { lv: 2, name: 'DON CHENTE', desc: 'Vagabundo', zones: [2, 3], lines: ['¿Una monedita, jefe?', 'Yo antes manejaba uno de esos.'] },
    vagabundo2: { lv: 2, name: 'EL GÜERO', desc: 'Vagabundo', zones: [2, 3], lines: ['Ese camión pasa cada hora... o cada día.', '¿No me da un raite?'] },
    mujer1:     { lv: 2, name: 'DOÑA LUPE', desc: 'Señora', zones: [2, 3], lines: ['¡Ese camión nunca para aquí!', '¡Bájale, que no traes huevos!'] },
    mujer2:     { lv: 2, name: 'LA KARLA', desc: 'Chava', zones: [2, 3], lines: ['¿Este pasa por el centro?', '¡Espérame, que voy a la Macro!'] },
    mujer3:     { lv: 2, name: 'LA YESSI', desc: 'Chava', zones: [2, 3], lines: ['¡Bájale a la velocidad!', 'Ese camión huele a llanta quemada.'] },
    mujer4:     { lv: 2, name: 'LA LIC', desc: 'Oficinista', zones: [2, 3], lines: ['¡Voy tarde a la junta!', '¿Aceptan tarjeta?'] }
  });
  for (const k in G.CAST) if (!G.CAST[k].lv) G.CAST[k].lv = 1;

  /* mujeres que gritan "1500" (nivel 2 en Monterrey de noche y nivel 3) */
  const MUJERES_1500 = {};
  ['mujer1', 'mujer2', 'mujer3', 'mujer4'].forEach(k => { MUJERES_1500[k] = { name: (G.CAST[k] && G.CAST[k].name) || 'MUJER', lines: ['1500'], color: '#c84a7a' }; });

  const L2 = {
    n: 2, title: 'NIVEL 2', player: 'bus', intro: 'drive', ending: 'finish',
    zones: [
      { id: 'escomiedo',   name: 'ESCOMIEDO',          start: 0.00, end: 0.25, color: '#cbdbfc', music: 'breaking', vis: 6 },
      { id: 'sanicoranch', name: 'SANICORANCH',        start: 0.25, end: 0.50, color: '#fbe043', music: 'breaking', vis: 7 },
      { id: 'monterrey',   name: 'MONTERREY',          start: 0.50, end: 0.65, color: '#5fcde4', music: 'breaking', vis: 8 },
      { id: 'mtynoche',    name: 'MONTERREY DE NOCHE', start: 0.65, end: 0.80, color: '#ff4fd8', music: 'sandoman', vis: 9 },
      { id: 'jefe2',       name: 'MIGUEL ALEMÁN',        start: 0.80, end: 0.95, color: '#39ff14', music: 'sandoman', vis: 10 },
      { id: 'meta2',       name: 'FIN DE LA RUTA',     start: 0.95, end: 1.00, color: '#99e550', music: 'breaking', vis: 11 }
    ],
    events: [
      { at: 0.040, type: 'bg', who: 'poli', line: 0 },
      { at: 0.090, type: 'bg', who: 'estudiante', line: 0 },
      { at: 0.140, type: 'ob', ob: 'transito', who: 'transito', line: 1 },
      { at: 0.200, type: 'bg', who: 'estudiante', line: 1 },
      { at: 0.280, type: 'bg', who: 'aficionado', line: 0 },
      { at: 0.320, type: 'bg', who: 'transito', line: 2 },
      { at: 0.370, type: 'ob', ob: 'poli', who: 'poli', line: 1 },
      { at: 0.430, type: 'bg', who: 'poli', line: 2 },
      { at: 0.470, type: 'bg', who: 'aficionado', line: 1 },
      { at: 0.530, type: 'bg', who: 'mujer1', line: 0 },
      { at: 0.570, type: 'bg', who: 'vagabundo', line: 0 },
      { at: 0.610, type: 'ob', ob: 'moto', who: 'motosimio', line: 0 },
      { at: 0.670, type: 'bg', who: 'mujer2', line: 0 },
      { at: 0.710, type: 'bg', who: 'vagabundo2', line: 0 },
      { at: 0.750, type: 'ob', ob: 'poli', who: 'poli', line: 0 },
      { at: 0.782, type: 'narr', text: 'Algo verde y fosforescente se acerca por la carretera...' }
    ],
    pools: [
      [['cone', 3], ['barrier', 2], ['ditch', 2], ['tire', 1], ['trash', 1], ['beamBus', 1.2, 0.08], ['pigeonBus', 1, 0.1]],
      [['cone', 2.5], ['poli', 2], ['transito', 1.5], ['barrier', 1], ['ditch', 1], ['beamBus', 1], ['pigeonBus', 1]],
      [['moto', 2], ['cone', 1], ['trash', 1], ['barrel', 1], ['ditch', 1], ['pigeonBus', 1.5], ['cart', 1], ['poli', 1]],
      [['moto', 2.5], ['poli', 2], ['transito', 1], ['tire', 2], ['barrel', 1], ['crowBus', 1.5], ['ditch', 1], ['mujer1', 0.8], ['mujer2', 0.8], ['mujer3', 0.8], ['mujer4', 0.8]]
    ],
    spawnLines: MUJERES_1500,
    noDoubles: true, fallAhead: 120,
    physics: { gravity: 520, jumpVel: 272, fastFall: 1400, speedStart: 165, speedMax: 200, bossSpeed: 120, PLAYER_X: 76 },
    hudStart: () => S.busIcon, hudEnd: () => S.flagIcon,
    hurtLines: ['¡Mi camión!', '¡La suspensión!', '¡Ay, el parabrisas!', '¡Ese bache!'],
    hint: { keys: '▲ ESPACIO / W: SALTAR    ▼ ABAJO / S: AGACHAR EL CAMIÓN    P: PAUSA' },
    ambient: [
      { walkers: ['peaton', 'peaton2', 'estudiante', 'poli'], every: [1.8, 4], traffic: [1.5, 3], busChance: 0.15 },
      { walkers: ['poli', 'transito', 'poli', 'aficionado', 'transito', 'estudiante'], every: [1, 2.2], traffic: [1, 2.2], busChance: 0.05, patrolChance: 0.55, honk: 0.2 },
      { walkers: ['mujer1', 'mujer2', 'mujer3', 'mujer4', 'vagabundo', 'vagabundo2', 'poli', 'peaton'], every: [0.9, 2], traffic: [1.2, 2.6], busChance: 0.2, motoChance: 0.3, honk: 0.2 },
      { walkers: ['mujer1', 'mujer2', 'mujer3', 'mujer4', 'vagabundo', 'vagabundo2', 'poli', 'transito'], every: [0.8, 1.8], traffic: [1.2, 2.5], motoChance: 0.45 },
      { particles: 'green' },
      { walkers: ['peaton3'], every: [3, 6], traffic: [3, 6] }
    ],
    boss: {
      name: 'CHAVACARAT', title: 'DOBLE CABEZA, DOBLE PROBLEMA', hp: 6,
      spr: () => S.rat, white: () => S.ratWhite, minion: 'poliMin', minionSay: '¡Ahí te van mis analfabetas!',
      patterns: {
        1: [['goo'], ['gooAir'], ['goo', 'gooAir'], ['gooAir', 'goo']],
        2: [['goo', 'goo'], ['gooDrop', 'gooAir'], ['gooAir', 'goo', 'gooDrop'], ['goo', 'gooDrop']],
        3: [['goo', 'gooAir', 'goo'], ['gooDrop', 'goo', 'gooAir'], ['gooAir', 'gooAir', 'goo'], ['goo', 'goo', 'gooDrop']]
      },
      intro: ['¿Creíste que llegarías tan fácilmente?', '¡Ahí te van mis analfabetas!'],
      fight: ['¡Ahí te van mis analfabetas!', '¡A ver si puedes superar esto!', '¡Esquiva esto, chofer!'],
      hurt: ['¡Auch, mi peinado!', '¡Eso no estaba en el plan!', '¡Ahí te van mis analfabetas!'],
      defeat: '¡Esto no se queda así!',
      hint: '¡Cae ENCIMA de los policías para quitarle vida a ChavacaRat! Esquiva lo verde.',
      missHint: '¡Aplasta a los analfabetas cayendo encima de ellos con el camión!'
    },
    policeSay: ['poli', 'poliMin', 'transito'], policeLines: ['¡Tengo hambre!', 'Es diciembre y la ley lo sabe.', 'Saca una Sor Juana... en corto.'],
    minionLines: ['¡Fuerza Civil, PROTEJER Y SERVIR!', '¡PROTEJER Y SERVIR!'], // los que lanza ChavacaRat
    victory: '¡NIVEL 2 COMPLETADO!'
  };


  /* ------------------------------ NIVEL 3: EL CAMIÓN VOLADOR ------------------------------ */
  const L3 = {
    n: 3, title: 'NIVEL 3', player: 'bus', intro: 'drive', introNarr: 'NIVEL 3: SAN LUIS POTOSÍ', introSay: 'Voy por ti Claudia... Muajaja', statsFirst: true, victoryMusic: 'lynird', ending: 'finish', finishText: 'RUMBO AL PENAL',
    zones: [
      { id: 'slp',    name: 'SAN LUIS POTOSÍ',  start: 0.00, end: 0.20, color: '#fbe043', music: 'lynird', vis: 12 },
      { id: 'c57',    name: 'CARRETERA 57',     start: 0.20, end: 0.40, color: '#2fae4a', music: 'lynird', vis: 13 },
      { id: 'vera',   name: 'VERACRUZ',         start: 0.40, end: 0.60, color: '#5fcde4', music: 'lynird', vis: 14, fly: true },
      { id: 'edomex', name: 'ESTADO DE MÉXICO', start: 0.60, end: 0.80, color: '#d77bba', music: 'lynird', vis: 15, fly: true },
      { id: 'cdmx',   name: 'CIUDAD DE MÉXICO', start: 0.80, end: 0.95, color: '#ff8a3a', music: 'lynird', vis: 17, fly: true },
      { id: 'penal',  name: 'RUMBO AL PENAL',   start: 0.95, end: 1.00, color: '#99e550', music: 'lynird', vis: 18, fly: true }
    ],
    events: [
      { at: 0.120, type: 'scene', scene: 'vulka' },
      { at: 0.175, type: 'scene', scene: 'hotel' },
      { at: 0.205, type: 'narr', text: 'CARRETERA 57: ¡a aplastar policías!' },
      { at: 0.385, type: 'scene', scene: 'wings' },
      { at: 0.700, type: 'say', text: '¡Oh, llegué a Macuarrolandia!', vis: 16 }
    ],
    pools: [
      [['cone', 2], ['tire', 1.5], ['poli', 2], ['barrel', 1], ['ditch', 1], ['pajaro', 1], ['cuervo', 0.8], ['mujer1', 0.6], ['mujer2', 0.6], ['mujer3', 0.6], ['mujer4', 0.6]],
      [['poli', 3], ['mujer1', 0.8], ['mujer2', 0.8], ['mujer3', 0.8], ['mujer4', 0.8], ['pajaro', 1], ['cuervo', 1], ['cone', 1.2], ['tire', 1], ['barrel', 0.8], ['ditch', 0.6]],
      [['fishLow', 2.5], ['fishHi', 1.5], ['crab', 2.5], ['octo', 2]],
      [['motoV', 3.5], ['motoVHi', 1.5], ['octo', 0.5]]
    ],
    noDoubles: true, fallAhead: 60,
    physics: { gravity: 520, jumpVel: 272, fastFall: 1400, speedStart: 150, speedMax: 180, bossSpeed: 120, PLAYER_X: 80 },
    hudStart: () => S.busIcon, hudEnd: () => S.flagIcon,
    hurtLines: ['¡Mi defensa!', '¡Auch, mi camión!', '¡Se me zafó una llanta!'],
    hint: { keys: '▲ ESPACIO / W: SALTAR Y APLASTAR    ▼ ABAJO / S: AGACHARSE    P: PAUSA' },
    stompLines: { 2: ['¡Toma esto, veracruzano!', '¡Jajaja!', '¡No a la 4T!'] },
    policeSay: ['poli'], policeLines: ['¡Tengo hambre!', 'Es diciembre y la ley lo sabe.', 'Saca una Sor Juana... en corto.'],
    spawnLines: {
      ...MUJERES_1500,
      motoV: { name: 'MOTOCICLISTA', lines: ['¡Cámara, mi valedor!', '¡Puro San Juditas!', '¡Ya te la sabes, carnal!', '¡Carteras y celulares!', '¡Saca la mona, carnal!'] },
      motoVHi: { name: 'MOTOCICLISTA', lines: ['¡Cámara, mi valedor!', '¡Puro San Juditas!', '¡Ya te la sabes, carnal!', '¡Carteras y celulares!', '¡Saca la mona, carnal!'] }
    },
    ambient: [
      { walkers: ['peaton3'], every: [4, 8], traffic: [2.5, 5], highway: true },
      { traffic: [1.5, 3], highway: true },
      { particles: 'leaves' },
      {},
      { particles: 'embers' },
      {}
    ],
    allies: true, bossNarr: 'MODO BIENESTAR ACTIVADO',
    boss: {
      name: 'MODO BIENESTAR', title: 'JEFA DE LAS FUERZAS DEL ORDEN', hp: 6,
      spr: () => S.mecha, white: () => S.mechaWhite, minion: 'alien', minionSay: null,
      patterns: {
        1: [['satBox'], ['becas'], ['satBox', 'becas'], ['palo']],
        2: [['satBox', 'palo'], ['becas', 'satBox'], ['palo', 'becas'], ['satBox', 'satBox']],
        3: [['satBox', 'becas', 'palo'], ['palo', 'satBox', 'becas'], ['becas', 'becas', 'satBox'], ['palo', 'palo', 'satBox']]
      },
      intro: ['¡Modo bienestar activado!', 'Nadie escapa de mis programas.'],
      fight: ['¡Ahí te van tus becas!', '¡El SAT te está vigilando!', '¡Toma tu palo rosado!'],
      hurt: ['¡Mis aliens!', '¡Eso no estaba en la mañanera!', '¡Auch!'],
      defeat: '¡Esto no se queda así...!',
      hint: '¡Aplasta a los ALIENS: te dan vida y le bajan a la jefa! Esquiva SAT, BECAS y palos rosados.',
      missHint: '¡Cae ENCIMA de los aliens para curarte y pegarle a la jefa!'
    },
    victory: '¡NIVEL 3 COMPLETADO!',
    creditsT: 13,
    credits: [
      ['¡FELICIDADES!', '#fbe043', 2],
      ['HAS DERROTADO A LAS', '#f4f4f4', 1], ['FUERZAS DEL ORDEN.', '#f4f4f4', 2],
      ['TE ESPERAN VARIAS CADENAS', '#f08a24', 1], ['PERPETUAS EN EL PENAL.', '#f08a24', 1],
      ['GRACIAS POR JUGAR', '#2fae4a', 2],
      ['made by: .l._iz.R0tt3nT0Th3Cor3.0x_.l.', '#cbdbfc', 1, true]
    ]
  };
  G.LEVELS = { 1: L1, 2: L2, 3: L3 };
  G.startLevel = function (n) {
    const lv = G.LEVELS[n] || L1;
    G.LEVEL = lv;
    CFG.zones = lv.zones;
    G.EVENTS = lv.events;
    Object.assign(CFG, lv.physics);
    CFG.boss = { name: lv.boss.name, title: lv.boss.title, hp: lv.boss.hp };
    return lv;
  };
  G.startLevel(G.START_LEVEL || 1);
})();
