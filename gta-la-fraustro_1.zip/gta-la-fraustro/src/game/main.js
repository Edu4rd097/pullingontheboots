/* =========================================================
   Arranque: lienzo pixel-perfect, entrada (teclado/táctil),
   carga de recursos y game loop con delta time (paso fijo).
   ========================================================= */
(function () {
  /* G.boot() arranca el juego cuando ya existe el <canvas id="game"> (HTML simple: de inmediato;
     Angular: lo llama el componente después de dibujar su plantilla) */
  let booted = false;
  window.G.boot = function () {
  if (booted || !document.getElementById('game')) return;
  booted = true;
  const G = window.G, CFG = G.CFG, I = G.Input, game = G.game;
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  canvas.width = CFG.W; canvas.height = CFG.H;
  ctx.imageSmoothingEnabled = false;

  /* ---------- escalado: en celular horizontal el lienzo se ensancha para llenar la pantalla ---------- */
  function resize() {
    const vw = window.innerWidth, vh = window.innerHeight;
    const portrait = vh > vw;
    let W = 320;
    if (I.touch && !portrait) W = Math.max(320, Math.min(440, Math.round(CFG.H * vw / vh / 2) * 2));
    if (W !== CFG.W) {
      CFG.W = W; canvas.width = W; canvas.height = CFG.H;
      if (G.clearSkyCache) G.clearSkyCache();
      if (game.boss && game.boss.state !== 'dying' && game.boss.state !== 'gone') game.boss.targetX = W - 72;
    }
    const bar = document.getElementById('toolbar');
    const barH = (!I.touch && bar) ? bar.offsetHeight : 0;
    let s = Math.min(vw / CFG.W, (vh - barH) / CFG.H);
    if (!I.touch && s >= 2) s = Math.floor(s);
    s = Math.max(0.5, s);
    canvas.style.width = Math.floor(CFG.W * s) + 'px';
    canvas.style.height = Math.floor(CFG.H * s) + 'px';
    document.getElementById('wrap').style.width = canvas.style.width;
    document.body.classList.toggle('portrait', portrait);
  }
  window.addEventListener('resize', resize);
  window.addEventListener('orientationchange', () => setTimeout(resize, 200));

  /* ---------- recursos de la carpeta del proyecto (opcionales) ---------- */
  function load(src) { const im = new Image(); im.src = src; return im; }
  game.images.menu = load('assets/menu_furia.png');
  game.images.menuBg = load('assets/menu_furia_bg.png');
  // nivel 3
  game.images.hotelDia = load('assets/l3_hotel_dia.png');
  game.images.hotelNoche = load('assets/l3_hotel_noche.png');
  game.images.piramide = load('assets/l3_piramide.png');
  game.images.jet = load('assets/l3_jet.png');
  game.images.aguila = load('assets/l3_aguila.png');
  game.images.quetzal = load('assets/l3_quetzal.png');
  game.images.bus = load('assets/camion_objetivo.png');

  /* ---------- teclado ---------- */
  const JUMP = ['Space', 'ArrowUp', 'KeyW'], DUCK = ['ArrowDown', 'KeyS'];
  window.addEventListener('keydown', (e) => {
    if (JUMP.includes(e.code) || DUCK.includes(e.code) || e.code === 'Enter') e.preventDefault();
    G.Audio.init();
    if (e.repeat) return;
    if (JUMP.includes(e.code)) I.pressJump();
    if (DUCK.includes(e.code)) { I.duckHeld = true; if (game.player.onGround) G.Audio.sfx('duck'); }
    if (e.code === 'Enter' || game.state === 'SPLASH') I._confirm = true;
    if (e.code === 'KeyP' || e.code === 'Escape') I._pause = true;
    if (e.code === 'KeyR') I._restart = true;
    if (e.code === 'KeyM') toggleMusic();
    if (e.code === 'KeyN') toggleSfx();
  });
  window.addEventListener('keyup', (e) => {
    if (JUMP.includes(e.code)) I.releaseJump();
    if (DUCK.includes(e.code)) I.duckHeld = false;
  });
  window.addEventListener('blur', () => {
    I.jumpHeld = false; I.duckHeld = false;
    if (['PLAYING', 'BOSS', 'ENDING'].includes(game.state)) game.paused = true;
  });

  /* ---------- puntero / táctil ---------- */
  function toInternal(e) {
    const r = canvas.getBoundingClientRect();
    return { x: (e.clientX - r.left) * CFG.W / r.width, y: (e.clientY - r.top) * CFG.H / r.height };
  }
  function hitButton(pt) { return game.buttons.find(b => pt.x >= b.x && pt.x <= b.x + b.w && pt.y >= b.y && pt.y <= b.y + b.h); }
  canvas.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    if (e.pointerType === 'touch') enableTouch();
    G.Audio.init();
    const pt = toInternal(e);
    const b = hitButton(pt);
    if (b) { b.action(); I.clearEdges(); return; }
    if (['PLAYING', 'BOSS', 'ENDING', 'INTRO'].includes(game.state)) {
      if (game.paused) return;
      // zona izquierda (35%) = agacharse mientras se mantiene; el resto = saltar
      if (I.touch && pt.x < CFG.W * 0.35) { I.duckHeld = true; duckPtr = e.pointerId; if (game.player.onGround) G.Audio.sfx('duck'); }
      else { I.pressJump(); jumpPtr = e.pointerId; }
    } else if (game.state === 'MENU') { I._confirm = true; if (I.touch) G.goFull(); }
    else if (game.state === 'SPLASH') I._confirm = true;
  });
  let jumpPtr = null, duckPtr = null;
  const up = (e) => {
    if (e.pointerId === jumpPtr) { I.releaseJump(); jumpPtr = null; }
    if (e.pointerId === duckPtr) { I.duckHeld = false; duckPtr = null; }
  };
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', up);
  canvas.addEventListener('contextmenu', (e) => e.preventDefault());
  document.addEventListener('visibilitychange', () => { G.Audio.setPaused(document.hidden || game.paused); if (document.hidden && ['PLAYING', 'BOSS', 'ENDING'].includes(game.state)) game.paused = true; });
  canvas.addEventListener('pointermove', (e) => { const b = hitButton(toInternal(e)); game.hoverBtn = b ? b.label : null; canvas.style.cursor = b ? 'pointer' : 'default'; });

  function enableTouch() { if (!I.touch) { I.touch = true; document.body.classList.add('touch'); resize(); } }
  if (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) enableTouch();

  /* ---------- barra de herramientas ---------- */
  const bm = document.getElementById('btnMusic'), bs = document.getElementById('btnSfx');
  function toggleMusic() { G.Audio.init(); G.Audio.setMusic(!G.Audio.musicOn); bm.classList.toggle('off', !G.Audio.musicOn); }
  function toggleSfx() { G.Audio.init(); G.Audio.setSfx(!G.Audio.sfxOn); bs.classList.toggle('off', !G.Audio.sfxOn); }
  G.toggleMusic = toggleMusic; G.toggleSfx = toggleSfx;
  /* pantalla completa + bloqueo horizontal (Android; en iPhone se logra instalándolo en Inicio) */
  G.goFull = function () {
    const el = document.documentElement;
    if (document.fullscreenElement || document.webkitFullscreenElement) return;
    const r = el.requestFullscreen || el.webkitRequestFullscreen;
    if (!r) return;
    try { Promise.resolve(r.call(el, { navigationUI: 'hide' })).then(() => { try { screen.orientation.lock('landscape').catch(() => {}); } catch (e) {} setTimeout(resize, 300); }).catch(() => {}); } catch (e) {}
  };
  G.toggleFull = function () {
    if (document.fullscreenElement || document.webkitFullscreenElement) (document.exitFullscreen || document.webkitExitFullscreen).call(document);
    else G.goFull();
  };
  document.getElementById('btnPlayPortrait').onclick = () => { document.body.classList.add('allowPortrait'); };
  bm.onclick = () => { G.Audio.init(); toggleMusic(); bm.blur(); };
  bs.onclick = () => { G.Audio.init(); toggleSfx(); bs.blur(); };
  document.getElementById('btnPause').onclick = (e) => { I._pause = true; e.currentTarget.blur(); };
  document.getElementById('btnFull').onclick = (e) => { e.currentTarget.blur(); G.toggleFull(); };

  /* ---------- game loop: delta time con paso fijo ---------- */
  const STEP = 1 / 120;
  let last = performance.now(), acc = 0;
  function frame(now) {
    let dt = Math.min(0.1, (now - last) / 1000) * G.DEBUG.timeScale;
    last = now; acc += dt;
    let n = 0;
    while (acc >= STEP && n < 60) { game.update(STEP); acc -= STEP; n++; }
    G.Audio.setPaused(game.paused || document.hidden);
    game.render(ctx);
    requestAnimationFrame(frame);
  }
  resize();
  if (G.DEBUG.auto || G.DEBUG.start) { G.Audio.musicOn = false; game.state = 'MENU'; }
  requestAnimationFrame(frame);
  window.__game = game;
  };
  if (document.getElementById('game')) window.G.boot();
  else document.addEventListener('DOMContentLoaded', () => window.G.boot());
})();
