/* =========================================================
   NIVEL 3 - escenas animadas (fusión del camión, vulka, hotel,
   alas) y efectos de la pelea final (aliados, naves, meteoros).
   ========================================================= */
(function () {
  const G = window.G, CFG = G.CFG, S = G.SPR, P = G.PAL;
  const GROUND = CFG.GROUND;
  const ease = (t) => t < 0 ? 0 : t > 1 ? 1 : t * t * (3 - 2 * t);

  function caption(ctx, text, y = 30, color = P.yellow, scale = 2) {
    const w = G.textWidth(text, scale) + 16;
    ctx.fillStyle = 'rgba(14,11,22,0.75)'; ctx.fillRect(Math.round(CFG.W / 2 - w / 2), y - 5, w, 5 * scale + 10);
    G.text(ctx, text, CFG.W / 2, y, color, { align: 'center', scale, outline: P.ink });
  }
  function drawRobotAt(ctx, x, y, opts = {}) {
    const R = S.robot;
    if (opts.wings) {
      const wk = opts.wings, wsp = R.wings[Math.floor(G.game.t * 8) % 2];
      ctx.drawImage(wsp, Math.round(x - 56 * wk), Math.round(y - 58), Math.round(112 * wk), 44);
    }
    if (opts.scale && opts.scale !== 1) { const k = opts.scale; ctx.drawImage(R.stand, Math.round(x - 24 * k), Math.round(y - 63 * k), Math.round(48 * k), Math.round(64 * k)); return; }
    ctx.drawImage(opts.fly ? R.fly : opts.frame !== undefined ? R.walk[opts.frame] : R.stand, Math.round(x - R.ax), Math.round(y - R.ay));
  }
  /* Nivel 3: el mismo camión del nivel 2; con alas cuando vuela */
  function drawBusAt(ctx, x, y, opts = {}) {
    const k = opts.scale || 1;
    if (opts.wings) {
      const wk = opts.wings, wsp = S.busWings[Math.floor(G.game.t * 6) % 2];
      ctx.drawImage(wsp, Math.round(x + (14 - 96 * wk) * k), Math.round(y - (40 + 56 * wk) * k), Math.round(120 * wk * k), Math.round(64 * wk * k));
    }
    ctx.drawImage(S.busFull, 0, 0, 140, 50, Math.round(x - 70 * k), Math.round(y - 48 * k), Math.round(140 * k), Math.round(50 * k));
  }
  G.drawRobotAt = drawBusAt; G.drawBusAt = drawBusAt;
  function sayAt(text, x, y) { G.Dialog.say(() => ({ x, y }), 'TÚ', text, { color: P.redD }); }

  const metroPart = G.mk(40, 16, (p) => { p.r(0, 0, 40, 16, '#3fae4a'); p.r(0, 6, 40, 3, '#e8e0b8'); p.r(3, 1, 34, 4, '#1d2b4a'); p.r(0, 14, 40, 2, '#24792e'); });

  G.Scenes = {
    /* El camión se fusiona con partes de vehículos hasta formar el robot */
    transform: {
      overlay: true, dur: 7.6,
      start(sc) { sc.parts = [S.cars[0], S.cars[2], S.cars[3], S.cars[4], metroPart, S.cars[1]].map((img, k) => ({ img, a: k / 6 * Math.PI * 2, rot: 0 })); G.game.player.visible = false; },
      update(sc, dt) {
        const t = sc.t, g = G.game;
        if (t > 0.4 && t - dt <= 0.4) sayAt('Voy por ti Claudia... Muajaja', CFG.PLAYER_X + 30, GROUND - 56);
        if (t > 2.6 && t - dt <= 2.6) { G.Audio.sfx('bossroar'); g.shake(1.8, 2); }
        if (t > 2.6 && t < 4.8 && Math.random() < 0.6) G.FX.burst(g.camX + CFG.PLAYER_X + G.rand(-40, 40), GROUND - G.rand(5, 45), 3, [P.yellow, P.white, P.orange], 80);
        if (t > 4.8 && t - dt <= 4.8) { g.flash = 0.5; G.Audio.sfx('explode'); G.Audio.sfx('zone'); }
        if (t > 4.8) g.player.visible = false;
      },
      draw(ctx, sc) {
        const t = sc.t, x = CFG.PLAYER_X, cx = x, cy = GROUND - 25;
        if (t < 4.8) {
          ctx.drawImage(S.busFull, Math.round(x - 70 + (t > 2.6 ? G.rand(-1, 1) : 0)), GROUND - 48);
          if (t > 2.4) {
            const k = ease((t - 2.4) / 2.3);
            for (const pt of sc.parts) {
              const r = (1 - k) * 260, a = pt.a + k * 4;
              const px = cx + Math.cos(a) * r, py = cy + Math.sin(a) * r * 0.6 - (1 - k) * 20;
              ctx.save(); ctx.translate(px, py); ctx.rotate(a * 2); const s = 0.6 + 0.4 * (1 - k); ctx.drawImage(pt.img, -pt.img.width * s / 2, -pt.img.height * s / 2, pt.img.width * s, pt.img.height * s); ctx.restore();
            }
          }
        } else {
          const k = Math.min(1, (t - 4.8) * 3);
          drawRobotAt(ctx, x, GROUND, { scale: 0.6 + 0.4 * k });
          if (t > 5.2) caption(ctx, '¡FUSIÓN COMPLETA!', 40, P.yellow, 2);
        }
      },
      end() { G.game.player.visible = true; G.game.player.mode = 'normal'; }
    },

    /* San Luis Potosí: vulcanizadora "Los 4 Reyes" */
    vulka: {
      overlay: false, dur: 11,
      start() { G.Audio.sfx('busdoor'); },
      update(sc, dt) {
        const t = sc.t;
        if (t > 7.0 && t - dt <= 7.0) sayAt('Salúdame al Cochiloco y al Benny', 110, GROUND - 56);
        if (Math.random() < dt * 10) G.FX.add({ x: G.game.camX + 90 + G.rand(-8, 8), y: GROUND - 6, vx: G.rand(-40, 40), vy: -G.rand(30, 70), g: 200, life: 0.4, max: 0.4, color: G.pick([P.yellow, P.orange, P.white]), size: 1 });
        if (t > 1 && Math.floor(t * 2) !== Math.floor((t - dt) * 2)) G.Audio.sfx('blip');
      },
      draw(ctx, sc) {
        const W = CFG.W, t = sc.t;
        const gr = ctx.createLinearGradient(0, 0, 0, 120); gr.addColorStop(0, '#5aa8e8'); gr.addColorStop(1, '#f8e8c0'); ctx.fillStyle = gr; ctx.fillRect(0, 0, W, 150);
        ctx.fillStyle = '#c9a27a'; for (let x = 0; x < W; x += 2) { const h = 22 + Math.sin(x * 0.02) * 10; ctx.fillRect(x, 120 - h, 2, h); }
        ctx.fillStyle = '#d8b88a'; ctx.fillRect(0, 118, W, 32); ctx.fillStyle = '#4a4d54'; ctx.fillRect(0, 150, W, 30);
        // la vulka
        const bx = W - 196, by = 50;
        ctx.fillStyle = '#e8c040'; ctx.fillRect(bx, by, 186, 100); ctx.fillStyle = '#c9a227'; ctx.fillRect(bx, by, 186, 4);
        ctx.fillStyle = '#d8283a'; ctx.fillRect(bx + 8, by + 8, 170, 24); ctx.fillStyle = '#9e1630'; ctx.fillRect(bx + 8, by + 30, 170, 2);
        G.text(ctx, 'VULKA', bx + 93, by + 11, '#fbe043', { align: 'center', outline: P.ink });
        G.text(ctx, 'LOS 4 REYES', bx + 93, by + 19, '#ffffff', { align: 'center', scale: 2, outline: P.ink });
        ctx.fillStyle = '#2a2a30'; ctx.fillRect(bx + 14, by + 42, 70, 58); ctx.fillStyle = '#3a3a42'; for (let y = by + 46; y < by + 100; y += 6) ctx.fillRect(bx + 14, y, 70, 1);
        G.text(ctx, 'LLANTAS NUEVAS Y USADAS', bx + 135, by + 44, P.ink, { align: 'center' });
        G.text(ctx, 'ABIERTO 24 HRS', bx + 135, by + 54, '#9e1630', { align: 'center' });
        const p = G.painter(ctx);
        for (let k = 0; k < 4; k++) { p.circle(bx + 110 + (k % 2) * 16, GROUND - 7 - Math.floor(k / 2) * 13, 6, '#15151c'); p.circle(bx + 110 + (k % 2) * 16, GROUND - 7 - Math.floor(k / 2) * 13, 2, '#555'); }
        for (let k = 0; k < 3; k++) { p.circle(bx + 160, GROUND - 7 - k * 13, 6, '#15151c'); p.circle(bx + 160, GROUND - 7 - k * 13, 2, '#555'); }
        // el robot y los 4 Reyes revisando las llantas
        drawBusAt(ctx, 104, GROUND);
        const garcias = ['mecanico1', 'mecanico2', 'mecanico1', 'mecanico2'];
        garcias.forEach((k, j) => {
          const pp = G.PEOPLE[k], x = [22, 38, 182, 198][j];
          const img = j < 2 ? pp.walk[Math.floor(t * 4 + j) % 4] : pp.walkL[Math.floor(t * 4 + j) % 4];
          ctx.drawImage(img, x - pp.ax, GROUND - pp.ay);
        });
        // llanta que ruedan
        const rx = 20 + ((t * 40) % (W - 60)); p.circle(Math.round(rx), GROUND - 7, 6, '#15151c'); p.circle(Math.round(rx), GROUND - 7, 2, '#777');
        caption(ctx, 'SAN LUIS POTOSÍ', 8, P.yellow, 2);
      }
    },

    /* Hotel El Pedregal: el robot estacionado frente al hotel */
    hotel: {
      overlay: false, dur: 5,
      update(sc, dt) { if (sc.t > 4.0 && sc.t - dt <= 4.0) G.Audio.sfx('select'); },
      draw(ctx, sc) {
        const W = CFG.W, H = CFG.H, t = sc.t, g = G.game;
        const img = g.images.hotelDia;
        ctx.fillStyle = '#5aa8e8'; ctx.fillRect(0, 0, W, H);
        ctx.fillStyle = '#c8c2b5'; ctx.fillRect(0, 150, W, 30);
        if (img && img.complete && img.naturalWidth) ctx.drawImage(img, Math.round((W - img.naturalWidth) / 2), 0);
        drawBusAt(ctx, W / 2 + 40, GROUND);
        caption(ctx, 'HOTEL EL PEDREGAL', 10, P.yellow, 2);
        const fade = t < 0.6 ? 1 - t / 0.6 : t > 4.5 ? (t - 4.5) / 0.5 : 0;
        if (fade > 0) { ctx.fillStyle = 'rgba(0,0,0,' + Math.min(1, fade).toFixed(2) + ')'; ctx.fillRect(0, 0, W, H); }
      }
    },

    /* Le salen alas al robot y despega rumbo a Veracruz */
    wings: {
      overlay: true, dur: 5.2,
      start(sc) { G.game.player.visible = false; G.Audio.sfx('bossroar'); G.game.obstacles = []; },
      update(sc, dt) {
        const t = sc.t, g = G.game;
        g.camX += 120 * dt;
        if (t > 1.2) for (const fx of [-6, 6]) G.FX.add({ x: g.camX + CFG.PLAYER_X + fx, y: sc.y + 1, vx: G.rand(-10, 10), vy: G.rand(30, 60), g: 0, life: 0.35, max: 0.35, color: G.pick([P.orange, P.yellow]), size: 2 });
        if (t > 2.6 && t - dt <= 2.6) { g.pd = 0.40 * CFG.courseLength; g.setZone(2); }
      },
      draw(ctx, sc) {
        const t = sc.t, wk = Math.min(1, t / 1.1);
        let y = GROUND;
        if (t > 1.2 && t < 2.8) y = GROUND - ease((t - 1.2) / 1.4) * 60;
        else if (t >= 2.8) y = GROUND - 60 + ease((t - 2.8) / 1.8) * 60;
        sc.y = y;
        drawBusAt(ctx, CFG.PLAYER_X, y, { wings: wk, fly: t > 1.2 });
        if (t < 1.2) for (let k = 0; k < 4; k++) G.painter(ctx).p(CFG.PLAYER_X + G.rand(-30, 30), y - G.rand(20, 60), P.white);
        if (t > 0.6) caption(ctx, t < 2.6 ? '¡A VOLAR!' : '¡RUMBO A VERACRUZ!', 40, P.yellow, 2);
      },
      end() { const g = G.game; g.player.visible = true; g.player.y = GROUND; g.player.vy = 0; g.player.onGround = true; g.spawner.pending = []; g.spawner.lastEnd = g.time + 1.5; g.obstacles = []; g.npcs = []; g.cars = []; }
    }
  };

  /* ---------------- CDMX: naves, meteoros y fuego de fondo ---------------- */
  G.drawCdmxFx = function (ctx, t) {
    const W = CFG.W;
    for (let k = 0; k < 3; k++) {
      const x = (k * 131 + t * (12 + k * 5)) % (W + 60) - 30, y = 14 + k * 16 + Math.sin(t * 1.5 + k) * 5;
      ctx.drawImage(S.ufo[Math.floor(t * 4 + k) % 2], Math.round(x), Math.round(y));
    }
    for (let k = 0; k < 2; k++) {
      const u = ((t * 0.3 + k * 0.5) % 1), x = W * (0.3 + k * 0.4) + 160 - u * 200, y = -10 + u * 110;
      for (let j = 1; j < 7; j++) { ctx.fillStyle = j < 3 ? '#fbe043' : j < 5 ? '#f08a24' : 'rgba(216,40,58,0.6)'; ctx.fillRect(Math.round(x + j * 4), Math.round(y - j * 3), 4 - j * 0.4, 4 - j * 0.4); }
      ctx.drawImage(S.meteor, Math.round(x - 5), Math.round(y - 5));
    }
  };

  /* ---------------- ALIADOS en la pelea final (solo animación) ---------------- */
  const A = G.Allies = { list: [], shots: [], t: 0, next: 0.5, k: 0 };
  A.reset = function () { A.list = []; A.shots = []; A.t = 0; A.next = 0.5; A.k = 0; };
  const img = (n) => G.game.images[n];
  let flipped = {};
  function flipOf(n) { const im = img(n); if (!im || !im.complete || !im.naturalWidth) return null; if (!flipped[n]) flipped[n] = G.flip(G.mk(im.naturalWidth, im.naturalHeight, (p, c) => c.drawImage(im, 0, 0))); return flipped[n]; }
  A.update = function (dt, boss) {
    A.t += dt; A.next -= dt;
    if (A.next <= 0 && boss && boss.state !== 'gone') {
      const type = ['jet', 'aguila', 'quetzal', 'jet', 'soldados'][A.k++ % 5];
      A.next = type === 'quetzal' ? 4.5 : 2.2;
      if (type === 'soldados') { for (let j = 0; j < 3; j++) A.list.push({ type: 'jet', x: -100 - j * 40, y: 26 + j * 16, vx: 210, fired: false, t: 0 }); }
      else A.list.push({ type, x: -130, y: type === 'quetzal' ? 34 : 30 + Math.random() * 40, vx: type === 'jet' ? 230 : type === 'aguila' ? 140 : 70, fired: false, t: 0 });
    }
    const bx = boss ? boss.x : CFG.W - 72, by = boss ? boss.y - 50 : 90;
    for (const a of A.list) {
      a.t += dt; a.x += a.vx * dt; a.y += Math.sin(a.t * 3) * 0.3;
      if (!a.fired && a.x > 40 && boss && boss.state !== 'gone') {
        a.fired = true;
        if (a.type === 'jet') { A.shots.push({ x: a.x + 40, y: a.y + 20, tx: bx, ty: by, t: 0, kind: 'misil' }); G.Audio.sfx('throw'); }
        if (a.type === 'aguila') for (let j = 0; j < 3; j++) A.shots.push({ x: a.x + 40, y: a.y + 40, tx: bx, ty: by + j * 10 - 10, t: -j * 0.15, kind: 'rayo' });
      }
      if (a.type === 'quetzal' && a.x > 20 && a.x < CFG.W - 200 && boss && boss.state !== 'gone') {
        for (let j = 0; j < 3; j++) G.FX.add({ x: G.game.camX + a.x + 118, y: a.y + 30 + G.rand(-3, 3), vx: G.rand(160, 230), vy: G.rand(-20, 30), g: 0, life: 0.8, max: 0.8, color: G.pick([P.orange, P.yellow, P.red]), size: 2 });
        if (Math.random() < dt * 3) { boss.flash = Math.max(boss.flash, 0.08); }
      }
    }
    for (const s of A.shots) {
      s.t += dt; if (s.t < 0) continue;
      const k = Math.min(1, s.t / 0.6); s.cx = s.x + (s.tx - s.x) * k; s.cy = s.y + (s.ty - s.y) * k - Math.sin(k * Math.PI) * 20;
      if (k >= 1 && !s.hit) { s.hit = true; if (boss) boss.flash = Math.max(boss.flash, 0.12); G.FX.burst(G.game.camX + s.tx, s.ty, 10, [P.orange, P.yellow, P.white], 90); }
    }
    A.list = A.list.filter(a => a.x < CFG.W + 160);
    A.shots = A.shots.filter(s => !s.hit);
  };
  A.draw = function (ctx) {
    for (const a of A.list) {
      const im = a.type === 'quetzal' ? img('quetzal') : flipOf(a.type === 'jet' ? 'jet' : 'aguila');
      if (im && (im.width || im.naturalWidth)) ctx.drawImage(im, Math.round(a.x), Math.round(a.y));
      if (a.type === 'jet') { ctx.fillStyle = '#f08a24'; ctx.fillRect(Math.round(a.x) - 6, Math.round(a.y) + 22, 6, 3); }
    }
    for (const s of A.shots) {
      if (s.t < 0 || s.cx === undefined) continue;
      if (s.kind === 'misil') { ctx.fillStyle = '#d8d8d8'; ctx.fillRect(Math.round(s.cx), Math.round(s.cy), 7, 2); ctx.fillStyle = '#f08a24'; ctx.fillRect(Math.round(s.cx) - 3, Math.round(s.cy), 3, 2); }
      else { ctx.fillStyle = '#fbe043'; ctx.fillRect(Math.round(s.cx), Math.round(s.cy), 5, 3); ctx.fillStyle = '#ffffff'; ctx.fillRect(Math.round(s.cx) + 1, Math.round(s.cy) + 1, 3, 1); }
    }
  };
})();
