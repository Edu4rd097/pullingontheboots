/* =========================================================
   NIVEL 3 - sprites: el robot (camión fusionado con vocho, taxis,
   metro y pickups), enemigos voladores, jefa final y proyectiles.
   ========================================================= */
(function () {
  const G = window.G, S = G.SPR, C = G.PAL;

  /* ---------------- ROBOT (ref. imagen del usuario) ----------------
     cabeza de casco plateado con cresta verde/roja, torso de vocho turquesa,
     brazos de taxi con franja de cuadros, piernas de vagón de metro verde
     y pies de defensas de pickup con llanta. Lienzo 48x64, ancla (24, 63). */
  const TEAL = '#1f9a9a', TEAL_L = '#5fc8c8', TEAL_D = '#136a6a';
  const SILVER = '#b8bcc4', SILVER_D = '#7a7e88', METRO = '#3fae4a', METRO_D = '#24792e', CREAM = '#e8e0b8';
  function robot(pose, f) {
    return G.mk(48, 64, (p) => {
      const walk = pose === 'walk', fly = pose === 'fly';
      const legL = walk ? [0, -2, 0, 2][f] : 0, legR = walk ? [0, 2, 0, -2][f] : 0;
      const bob = walk && f % 2 ? -1 : 0;
      const by = 2 + bob;
      // piernas (vagones de metro) + pies (defensa de pickup con llanta)
      const leg = (x, lift, back) => {
        const y0 = by + 38, top = y0 - lift;
        p.r(x, top, 10, 11, back ? METRO_D : METRO); p.r(x, top + 3, 10, 2, CREAM); p.r(x + 2, top + 6, 6, 3, '#1d2b4a');
        p.r(x + 1, top + 11, 8, 2, '#3a3a40');
        p.r(x, top + 13, 10, 8, back ? METRO_D : METRO); p.r(x + 2, top + 15, 6, 3, '#1d2b4a'); p.r(x, top + 19, 10, 1, CREAM);
        p.r(x - 2, top + 21, 14, 3, '#d8dce4'); p.r(x - 2, top + 21, 14, 1, '#ffffff'); p.p(x - 1, top + 22, C.yellow); p.p(x + 10, top + 22, C.yellow);
        if (!fly) { p.circle(x + 5, Math.min(61, top + 25), 3, '#15151c'); p.p(x + 5, Math.min(61, top + 25), '#b9b9c4'); }
      };
      leg(13, fly ? 2 : Math.max(0, legL), true);
      leg(25, fly ? 2 : Math.max(0, legR), false);
      // cadera de engranes
      p.r(14, by + 34, 20, 5, '#4a4a52'); for (let x = 15; x < 34; x += 4) p.r(x, by + 35, 2, 3, '#7a7a82');
      // brazos de taxi
      const sw = walk ? [-1, 0, 1, 0][f] : 0;
      const arm = (x, s, back) => {
        p.r(x, by + 17 + s, 8, 9, back ? '#d8d8d8' : '#f4f4f4'); for (let k = 0; k < 8; k += 2) { p.r(x + k, by + 21 + s, 1, 2, C.ink); p.r(x + k + 1, by + 21 + s, 1, 2, C.yellow); }
        p.circle(x + 4, by + 19 + s, 2, back ? '#c09020' : C.yellow);
        p.r(x + 1, by + 26 + s, 6, 3, '#3a3a40');
        p.r(x, by + 29 + s, 8, 7, back ? '#d8d8d8' : '#f4f4f4'); p.r(x, by + 33 + s, 8, 1, C.ink); p.p(x + 6, by + 30 + s, C.red);
        p.r(x + 1, by + 36 + s, 6, 4, SILVER_D); p.p(x + 1, by + 40 + s, SILVER_D); p.p(x + 6, by + 40 + s, SILVER_D);
      };
      arm(4, -sw, true);
      // torso de vocho
      p.r(12, by + 17, 24, 18, TEAL); p.r(14, by + 15, 20, 2, TEAL); p.r(16, by + 14, 16, 1, TEAL);
      p.r(15, by + 16, 6, 1, TEAL_L); p.r(23, by + 17, 2, 14, TEAL_D);
      p.circle(17, by + 27, 3, '#dfe6ee'); p.circle(31, by + 27, 3, '#dfe6ee'); p.p(16, by + 26, '#ffffff'); p.p(30, by + 26, '#ffffff');
      p.r(12, by + 32, 24, 2, '#c8ccd4');
      // collar de picos
      for (let x = 15; x < 34; x += 3) { p.p(x, by + 13, '#2a2a30'); p.p(x + 1, by + 12, '#2a2a30'); }
      p.r(15, by + 13, 18, 2, '#2a2a30');
      arm(36, sw, false);
      // cabeza: casco plateado con visor amarillo y cresta verde/roja
      p.r(17, by + 1, 14, 12, SILVER); p.r(17, by + 1, 3, 12, SILVER_D); p.r(19, by + 10, 10, 3, SILVER_D);
      p.r(21, by + 5, 9, 2, '#2a2a30'); p.r(22, by + 5, 2, 2, pose === 'dead' ? C.ink : '#fff27a'); p.r(27, by + 5, 2, 2, pose === 'dead' ? C.ink : '#fff27a');
      p.r(22, by + 9, 7, 1, '#2a2a30');
      const cols = [C.green, C.red, C.green, C.red, C.green, C.red];
      for (let k = 0; k < 6; k++) { const hgt = [4, 6, 7, 7, 6, 4][k]; p.r(18 + k * 2, by + 1 - hgt, 2, hgt, cols[k]); }
    });
  }
  const R = S.robot = {
    walk: [0, 1, 2, 3].map(f => robot('walk', f)),
    stand: robot('stand', 0), fly: robot('fly', 0), dead: robot('dead', 0), ax: 24, ay: 63
  };
  R.duck = G.mk(48, 40, (p, ctx) => ctx.drawImage(R.stand, 0, 0, 48, 64, 0, 0, 48, 40));
  // alas mecánicas con plumas verdes (aparecen al volar)
  R.wings = [0, 1].map(f => G.mk(112, 44, (p) => {
    const up = f === 0, cols = [C.green, '#f4f4f4', C.red];
    for (let k = 0; k < 6; k++) {
      const len = 50 - k * 6, y = up ? 2 + k * 4 : 14 + k * 4;
      const dy = up ? -Math.round(k * 0.5) : Math.round(k * 0.5);
      p.r(56 - len, y + dy, len, 4, k % 2 ? '#c8ccd4' : '#9aa0aa'); p.r(56 - len, y + dy, 7, 4, cols[k % 3]); p.r(56 - len, y + dy + 3, len, 1, '#6a6e78');
      p.r(56, y + dy, len, 4, k % 2 ? '#c8ccd4' : '#9aa0aa'); p.r(56 + len - 7, y + dy, 7, 4, cols[k % 3]); p.r(56, y + dy + 3, len, 1, '#6a6e78');
    }
    p.r(50, 16, 12, 8, '#5a5e68');
  }));

  /* ---------------- ENEMIGOS VOLADORES ---------------- */
  S.fish = [0, 1].map(f => G.mk(18, 11, (p) => {
    p.r(3, 3, 11, 5, '#4a8ad0'); p.r(4, 2, 8, 1, '#7ab8f0'); p.r(4, 7, 9, 2, '#d8e8f8'); p.r(0, 4, 3, 3, '#4a8ad0'); p.p(1, 4, C.ink);
    p.r(14, 2 + f, 4, 7 - f * 2, '#2a5aa0'); p.r(6, f ? 0 : 8, 6, 3, '#9ad0ff'); p.p(2, 6, C.red);
  }));
  S.crab = [0, 1].map(f => G.mk(18, 12, (p) => {
    p.r(4, 4, 10, 5, '#d8402a'); p.r(5, 3, 8, 1, '#f06a4a'); p.p(6, 1, C.ink); p.p(11, 1, C.ink); p.r(6, 2, 1, 2, '#d8402a'); p.r(11, 2, 1, 2, '#d8402a');
    p.r(0, 2 - f, 4, 3, '#e8502a'); p.r(14, 2 - f, 4, 3, '#e8502a'); p.p(0, 1 - f, '#e8502a'); p.p(17, 1 - f, '#e8502a');
    for (let k = 0; k < 3; k++) { p.r(4 + k * 2, 9, 1, 2 + (k + f) % 2, '#b02a1a'); p.r(12 - k * 2, 9, 1, 2 + (k + f + 1) % 2, '#b02a1a'); }
  }));
  S.octo = [0, 1].map(f => G.mk(16, 17, (p) => {
    p.circle(8, 6, 6, '#9a4ac8'); p.r(5, 2, 4, 2, '#c08ae8'); p.r(5, 6, 2, 2, '#ffffff'); p.r(10, 6, 2, 2, '#ffffff'); p.p(6, 7, C.ink); p.p(11, 7, C.ink);
    for (let k = 0; k < 5; k++) { const x = 2 + k * 3; p.r(x, 11, 2, 3, '#7a2aa8'); p.r(x + ((k + f) % 2 ? 1 : -1), 14, 2, 3, '#7a2aa8'); }
  }));
  // motociclista volador del Estado de México (moto con turbinas)
  S.motoV = [0, 1].map(f => G.mk(30, 28, (p, ctx) => {
    ctx.drawImage(S.moto[f], 0, 0);
    p.r(2, 24, 5, 3, f ? C.orange : C.yellow); p.r(21, 24, 5, 3, f ? C.yellow : C.orange); p.r(3, 26, 3, 2, C.red); p.r(22, 26, 3, 2, C.red);
  }));
  S.patrolLane = S.patrolL;

  /* ---------------- PROYECTILES DE LA JEFA ---------------- */
  const label = (w, h, bg, fg, txt, border) => G.mk(w, h, (p, ctx) => { p.r(0, 0, w, h, border); p.r(1, 1, w - 2, h - 2, bg); G.text(ctx, txt, w / 2, Math.floor((h - 5) / 2), fg, { align: 'center' }); });
  S.sat = label(17, 11, '#f4f4f4', '#9e1630', 'SAT', '#9e1630');
  S.becas = label(25, 11, '#2fae4a', '#ffffff', 'BECAS', '#1f7d36');
  S.palo = [0, 1].map(f => G.mk(18, 8, (p) => { p.line(1, f ? 6 : 2, 16, f ? 2 : 6, '#ff6fb0', 2); p.line(2, f ? 6 : 2, 15, f ? 2 : 6, '#ffb0d8', 1); }));
  S.alien = [0, 1].map(f => G.mk(14, 16, (p) => {
    p.circle(7, 5, 5, '#5fe05f'); p.r(3, 4, 3, 3, C.ink); p.r(8, 4, 3, 3, C.ink); p.p(4, 4, '#ffffff'); p.p(9, 4, '#ffffff');
    p.r(5, 10, 4, 4, '#4ac84a'); p.r(3 - f, 11, 2, 1, '#4ac84a'); p.r(9 + f, 11, 2, 1, '#4ac84a'); p.r(5, 14, 1, 2, '#3aa83a'); p.r(8, 14, 1, 2, '#3aa83a');
    p.r(6, -1 + 1, 1, 1, '#5fe05f'); p.p(2, 0, '#5fe05f'); p.p(11, 0, '#5fe05f');
  }));
  S.heartPlus = G.mk(9, 8, (p, ctx) => { ctx.drawImage(S.heart, 0, 1); p.r(7, 0, 1, 3, C.white); p.r(6, 1, 3, 1, C.white); });

  /* ---------------- FONDO DE LA CDMX: naves, meteoros ---------------- */
  S.ufo = [0, 1].map(f => G.mk(26, 12, (p) => {
    p.r(2, 6, 22, 3, '#9aa0aa'); p.r(0, 7, 26, 2, '#7a7e88'); p.circle(13, 5, 5, '#8ad0ff'); p.r(9, 2, 6, 2, '#c8ecff');
    for (let k = 0; k < 4; k++) p.p(4 + k * 6, 8, (k + f) % 2 ? C.yellow : C.red);
    p.r(10, 10, 6, 2, f ? '#c8ffb0' : '#8af08a');
  }));
  S.meteor = G.mk(10, 10, (p) => { p.circle(5, 5, 4, '#6a4a3a'); p.circle(4, 4, 2, '#8a6a5a'); p.p(6, 6, '#3a2a20'); });

  /* ---------------- JEFA FINAL (original): MODO BIENESTAR ----------------
     máscara mecánica gigante guinda y plata con ojos de rayo, flotando
     sobre una nube de programas sociales */
  function mecha(mode) {
    return G.mk(64, 80, (p) => {
      const G1 = '#8a1538', G2 = '#5a0e24', SIL = '#c8ccd4', SIL2 = '#8a8e98';
      // nube de "programas"
      for (let k = 0; k < 7; k++) p.circle(8 + k * 8, 70 + (k % 2) * 2, 7, k % 2 ? '#f0f0f8' : '#d8d8e8');
      p.r(14, 64, 36, 2, '#c8c8d8');
      // cuello y hombros
      p.r(18, 52, 28, 12, G1); p.r(10, 56, 44, 8, G2); p.r(28, 52, 8, 12, SIL);
      // cabeza
      p.r(12, 8, 40, 44, SIL); p.r(10, 14, 44, 32, SIL); p.r(12, 8, 6, 44, SIL2); p.r(46, 8, 6, 44, SIL2);
      p.r(12, 4, 40, 8, G1); p.r(20, 0, 24, 6, G1); p.r(26, 0, 12, 2, G2); // tocado / chongo mecánico
      p.r(8, 22, 4, 12, G1); p.r(52, 22, 4, 12, G1); // orejeras
      // ojos de rayo
      const glow = mode === 'hurt' || mode === 'dead' ? '#ff8a8a' : '#fffbe0';
      p.r(16, 18, 12, 8, '#2a1018'); p.r(36, 18, 12, 8, '#2a1018');
      if (mode === 'dead') { for (const x of [18, 38]) { p.line(x, 19, x + 7, 25, C.ink, 2); p.line(x + 7, 19, x, 25, C.ink, 2); } }
      else { p.r(17, 19, 10, 6, glow); p.r(37, 19, 10, 6, glow); p.r(19, 20, 6, 4, '#ffffff'); p.r(39, 20, 6, 4, '#ffffff'); }
      if (mode !== 'dead') { p.line(18, 18, 8, 4, '#fff27a', 1); p.line(46, 18, 56, 2, '#fff27a', 1); p.line(8, 4, 4, 0, '#fff27a', 1); }
      // nariz y boca gritando (rejilla)
      p.r(30, 26, 4, 8, SIL2);
      p.r(22, 36, 20, 12, '#2a1018'); p.r(24, 38, 16, 2, '#f4f4f4'); p.r(24, 45, 16, 2, '#f4f4f4'); p.r(26, 40, 12, 5, G1);
      if (mode === 'attack') { p.r(20, 34, 24, 16, '#2a1018'); p.r(22, 36, 20, 2, '#f4f4f4'); p.r(22, 47, 20, 2, '#f4f4f4'); p.r(25, 39, 14, 7, '#ff6fb0'); }
      // remaches
      for (const [x, y] of [[14, 12], [48, 12], [14, 46], [48, 46]]) p.p(x, y, SIL2);
      p.r(26, 10, 12, 3, '#f0c040'); p.p(31, 11, G2);
    });
  }
  S.mecha = { idle: mecha('idle'), attack: mecha('attack'), hurt: mecha('hurt'), dead: mecha('dead') };
  S.mechaWhite = G.tint(S.mecha.hurt, '#ffffff');

  /* ---------------- gente del nivel 3 ---------------- */
  Object.assign(G.LOOKS, {
    mecanico1: { skin: C.skinM, skinS: C.skinMS, hair: 'cap', hairC: '#c9a227', shirt: '#2a4a8a', pants: '#2a4a8a', mustache: C.ink, extra: ['badge'] },
    mecanico2: { skin: C.skin, hair: 'short', hairC: '#3a2a20', shirt: '#6a6a72', pants: '#3a3a42', beard: '#3a2a20' }
  });

  /* Icono de Instagram en 8 bits (14x14) */
  S.igIcon = G.mk(14, 14, (p) => {
    const grad = ['#feda75', '#fa7e1e', '#d62976', '#962fbf', '#4f5bd5'];
    for (let y = 0; y < 14; y++) for (let x = 0; x < 14; x++) {
      if ((x < 2 || x > 11) && (y < 2 || y > 11) && !((x === 1 || x === 12) && (y === 1 || y === 12))) continue;
      if ((x === 0 || x === 13) && (y === 0 || y === 13)) continue;
      const u = (x + (13 - y)) / 26; p.p(x, y, grad[Math.min(4, Math.floor((1 - u) * 5))]);
    }
    const W = '#ffffff';
    for (let i = 3; i <= 10; i++) { p.p(i, 2, W); p.p(i, 11, W); p.p(2, i, W); p.p(11, i, W); }
    for (let y = 0; y < 14; y++) for (let x = 0; x < 14; x++) { const d = Math.hypot(x - 6.5, y - 6.5); if (d >= 1.6 && d < 2.7) p.p(x, y, W); }
    p.p(9, 4, W);
  });

  /* Alas emplumadas para el camión volador (2 cuadros de aleteo). Raíz del ala en (96,56). */
  S.busWings = [0, 1].map(f => G.mk(120, 64, (p, ctx) => {
    const W = 120, H = 64, id = new Int16Array(W * H).fill(-1);
    const root = [96, 56], wrist = f ? [46, 34] : [54, 10];
    const segD = (x, y, a, b) => { const dx = b[0] - a[0], dy = b[1] - a[1], l = dx * dx + dy * dy; let t = l ? ((x - a[0]) * dx + (y - a[1]) * dy) / l : 0; t = Math.max(0, Math.min(1, t)); const ex = a[0] + dx * t - x, ey = a[1] + dy * t - y; return Math.sqrt(ex * ex + ey * ey); };
    const feathers = [];
    for (let k = 0; k < 9; k++) {
      const t = k / 8, b = [root[0] + (wrist[0] - root[0]) * t, root[1] + (wrist[1] - root[1]) * t];
      const ang = ((f ? 120 : 145) + t * (f ? 55 : 65)) * Math.PI / 180, L = 14 + t * 30;
      feathers.push([b, [b[0] + Math.cos(ang) * L, b[1] + Math.sin(ang) * L]]);
    }
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      if (segD(x, y, root, wrist) <= 6) { id[y * W + x] = 99; continue; }
      for (let k = feathers.length - 1; k >= 0; k--) if (segD(x, y, feathers[k][0], feathers[k][1]) <= 3.6 - k * 0.12) { id[y * W + x] = k; break; }
    }
    const inside = (x, y) => x >= 0 && y >= 0 && x < W && y < H && id[y * W + x] >= 0;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const v = id[y * W + x]; if (v < 0) continue;
      const edge = !inside(x - 1, y) || !inside(x + 1, y) || !inside(x, y - 1) || !inside(x, y + 1);
      const sep = v !== 99 && ((inside(x + 1, y) && id[y * W + x + 1] !== v && id[y * W + x + 1] !== 99) || (inside(x, y + 1) && id[(y + 1) * W + x] !== v && id[(y + 1) * W + x] !== 99));
      p.p(x, y, edge ? '#3a4a6a' : sep ? '#9ab0cc' : v === 99 ? (y < wrist[1] + 4 ? '#ffffff' : '#eef4fa') : v % 2 ? '#ffffff' : '#dce8f4');
    }
  }));
  for (const k of ['mecanico1', 'mecanico2']) G.PEOPLE[k] = G.makePerson(G.LOOKS[k]);
})();
