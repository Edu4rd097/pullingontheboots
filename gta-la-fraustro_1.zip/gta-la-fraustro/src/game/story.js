/* =========================================================
   Historia: elenco, diálogos y eventos guionizados por progreso
   ========================================================= */
(function () {
  const G = window.G;

  /* Elenco (todos ficticios). zone = índice de zona donde pueden aparecer */
  G.CAST = {
    chuy:      { name: 'DON CHUY', desc: 'Vecino curioso', zones: [0], lines: ['¿A dónde vas tan temprano?', 'Yo a tu edad ya iba por la tercera chamba.', '¿Y esa cresta? ¿Te peinó un ventilador?'] },
    cuca:      { name: 'DOÑA CUCA', desc: 'Vecina con escoba', zones: [0], lines: ['¡Cuidado con el perro!', 'No me pises lo que acabo de barrer.', '¡Saludos a tu mamá!'] },
    rigo:      { name: 'EL PROFE RIGO', desc: 'Jubilado filósofo', zones: [0], lines: ['Aquí nunca pasa nada interesante...', 'Mira, muchacho: el camión no espera.'] },
    tencha:    { name: 'ABUELA TENCHA', desc: 'Sabia del barrio', zones: [0], lines: ['Febrero loco y marzo otro poco.', 'Abrígate, mijo, que hace un calor...'] },
    manguera:  { name: 'DON BETO', desc: 'Lava la banqueta a diario', zones: [0], lines: ['¡Ahí te va el agua, joven!', 'La banqueta es mía hasta las 9.'] },
    elotero:   { name: 'EL ELOTERO', desc: 'Vendedor ambulante', zones: [1], lines: ["¡Elotes, esquites! ¿Uno pa'l camino?", 'Con todo y chilito, joven.'] },
    tsuru:     { name: 'EL DEL TSURU', desc: 'Conductor impaciente', zones: [1], lines: ['CHTM SHEIMBAUNDS', '¡Muévete, que traigo prisa!', '¡¿Quién te dio la licencia?!'] },
    brayan:    { name: 'BRAYAN', desc: 'Peatón distraído', zones: [1], lines: ['¡Fíjate por dónde caminas!', 'Espérame, estoy en una llamada...'] },
    motosimio: { name: 'EL MOTOSIMIO', desc: 'Motociclista sin frenos', zones: [1, 2], lines: ['¡Abran paso, voy tarde!', '¡Sin casco no hay diversión! ...ah, sí traigo.'] },
    parada:    { name: 'SEÑORA DE LA PARADA', desc: 'Lleva 40 min esperando', zones: [1], lines: ['El tráfico está imposible hoy.', 'Ese camión pasa cuando quiere.'] },
    candidato: { name: 'EL CANDIDATO', desc: 'Siempre en campaña', zones: [1, 2], lines: ['¡Vota por mí! ...¿No? Bueno, ahí te va un calendario.', '¡Prometo banquetas sin perros!'] },
    obrero:    { name: 'EL MAESTRO DE OBRA', desc: 'Trabajador de construcción', zones: [2], lines: ['Por aquí no es tan fácil.', 'Esto queda listo en dos semanas... de hace 3 años.'] },
    ciclista:  { name: 'LYCRA MAN', desc: 'Ciclista intenso', zones: [2], lines: ['¡No te detengas ahora!', '¡Cardio, compa, cardio!'] },
    misterio:  { name: '???', desc: 'Personaje misterioso', zones: [2, 3], lines: ['Te falta mucho camino.', '¡Cuidado con ese sujeto!', 'Te están esperando.'] },
    tarjetas:  { name: 'EL DE LAS TARJETAS', desc: 'Te quiere distraer', zones: [2], lines: ['¿Ya tiene su tarjeta? Sin anualidad el primer año...', 'Nomás firme aquí, aquí y aquí.'] },
    influ:     { name: 'LA INFLUENCER', desc: 'En vivo todo el día', zones: [2], lines: ['¡Saluda a mi live! Di "hola mis amores".', 'Esto va directo a mis historias.'] },
    maton:     { name: 'EL ACHICHINCLE', desc: 'Matón del jefe', zones: [3], lines: ['Hasta aquí llegaste.', 'El jefe ya sabe que vienes.'] },
    maton2:    { name: 'EL CHAPARRO', desc: 'Matón del jefe', zones: [3], lines: ['Nadie pasa de esta zona.', 'No traes cita, ¿verdad?'] },
    perro:     { name: 'FIRULAIS', desc: 'Perro que persigue', zones: [0], lines: ['¡GUAU GUAU!'] },
    peaton:    { name: 'UN SEÑOR', desc: 'Peatón', zones: [0, 1, 2], lines: [] },
    peaton2:   { name: 'UNA CHAVA', desc: 'Peatona', zones: [0, 1, 2], lines: [] },
    peaton3:   { name: 'UN COMPA', desc: 'Peatón', zones: [0, 1, 2, 5], lines: [] }
  };

  G.GENERIC_LINES = [
    '¡Apúrate, que ya se hace tarde!', '¿Todavía no llegas?', 'Por allá no es.', '¡Cuidado con ese sujeto!',
    'Te están esperando.', 'El camión está más adelante.', 'Ya casi llegas... creo.', '¿Traes cambio para el pasaje?',
    'Dicen que el camión pasó hace 5 minutos.', 'Yo nomás vine a ver.', '¿Esa cresta es de verdad?'
  ];

  /* Eventos guionizados. at = progreso. type:
     bg = personaje de fondo que habla; ob = obstáculo-personaje; narr = narrador; traffic = auto que toca el claxon */
  G.EVENTS = [
    { at: 0.045, type: 'bg', who: 'chuy', line: 0 },
    { at: 0.068, type: 'bg', who: 'cuca', line: 0, then: { ob: 'dog', who: 'perro' } },
    { at: 0.095, type: 'bg', who: 'rigo', line: 0 },
    { at: 0.118, type: 'bg', who: 'tencha', line: 0 },
    { at: 0.138, type: 'ob', ob: 'manguera', who: 'manguera', line: 0 },
    { at: 0.172, type: 'bg', who: 'elotero', line: 0 },
    { at: 0.200, type: 'traffic', who: 'tsuru', line: 0 },
    { at: 0.228, type: 'ob', ob: 'brayan', who: 'brayan', line: 0 },
    { at: 0.258, type: 'ob', ob: 'moto', who: 'motosimio', line: 0 },
    { at: 0.288, type: 'bg', who: 'parada', line: 0 },
    { at: 0.318, type: 'bg', who: 'candidato', line: 0 },
    { at: 0.335, type: 'traffic', who: 'tsuru', line: 2 },
    { at: 0.375, type: 'bg', who: 'obrero', line: 0 },
    { at: 0.410, type: 'ob', ob: 'bike', who: 'ciclista', line: 0 },
    { at: 0.445, type: 'bg', who: 'misterio', line: 0 },
    { at: 0.478, type: 'ob', ob: 'tarjetas', who: 'tarjetas', line: 0 },
    { at: 0.512, type: 'bg', who: 'influ', line: 0 },
    { at: 0.535, type: 'bg', who: 'obrero', line: 1 },
    { at: 0.585, type: 'ob', ob: 'maton', who: 'maton', line: 0 },
    { at: 0.640, type: 'ob', ob: 'maton2', who: 'maton2', line: 0 },
    { at: 0.700, type: 'bg', who: 'misterio', line: 1 },
    { at: 0.745, type: 'ob', ob: 'maton', who: 'maton', line: 1 },
    { at: 0.782, type: 'narr', text: 'Algo enorme se acerca... huele a papeleo.' }
  ];

  G.NARR = {
    intro: 'Es hora de ir a trabajar...',
    go: '¡A CAMINAR!',
    boss: ['¿Creíste que llegarías tan fácilmente?', 'Este camino termina aquí.', 'Arremángate, compadre.', 'Ya casi terminamos el metro, compadre.', 'La FGR mlp.', 'La DEA mlp.', 'Todo NL mlp.'],
    bossHurt: ['Arremángate, compadre.', 'Ya casi terminamos el metro, compadre.', 'La FGR mlp.', 'La DEA mlp.', 'Todo NL mlp.'],
    bossDefeat: '¡Ayúdame, mi Chavacana!',
    stompHint: '¡Pisa a los achichincles para quitarle las firmas!',
    final: '¡Ahí está el camión!'
  };
})();
