/* =========================================================
   Audio chiptune 8-bit sintetizado con WebAudio (sin archivos)
   ========================================================= */
(function () {
  const G = window.G, CFG = G.CFG;
  const A = G.Audio = { musicOn: true, sfxOn: true, ctx: null, current: null };
  let master, musicGain, sfxGain, noiseBuf, timer = null, step = 0, nextTime = 0, track = null;

  const NOTE = {};
  ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'].forEach((n, i) => {
    for (let o = 0; o < 8; o++) NOTE[n + o] = 440 * Math.pow(2, (i - 9 + (o - 4) * 12) / 12);
  });
  const T = (s) => s.trim().split(/\s+/);

  const TRACKS = {
    menu: { bpm: 112, lead: T('E5 . G5 . C6 . G5 . A5 . G5 E5 . . D5 . E5 . C5 . . . F5 . A5 . G5 . E5 . D5 . . .'), bass: T('C3 . . . G2 . . . A2 . . . E2 . . . F2 . . . C3 . . . G2 . . . G2 . . .'), drums: '....h.......h...' },
    barrio: { bpm: 136, lead: T('E5 . G5 . C6 . G5 . A5 . G5 E5 . . D5 . E5 . C5 . . . F5 . A5 . G5 . E5 . D5 . E5 . D5 . . .'), bass: T('C3 . C3 . G2 . G2 . A2 . A2 . E2 . E2 . F2 . F2 . C3 . C3 . G2 . G2 . G2 . B2 .'), drums: 'k.h.s.h.k.h.s.h.' },
    ciudad: { bpm: 150, lead: T('F5 . F5 A5 . C6 . A5 G5 . F5 . D5 . . . F5 . F5 A5 . C6 . D6 C6 . A5 . G5 . . .'), bass: T('F2 . F3 . F2 . F3 . D2 . D3 . D2 . D3 . A#1 . A#2 . A#1 . A#2 . C2 . C3 . C2 . C3 .'), drums: 'k.hsk.hsk.h.s.hh' },
    camino: { bpm: 140, lead: T('D5 . F5 . A5 . G5 . F5 . E5 . D5 . . . C5 . D5 . F5 . E5 . C5 . A4 . D5 . . .'), bass: T('D2 . . D2 A2 . D2 . C2 . . C2 G2 . C2 . A#1 . . A#1 F2 . A#1 . A1 . . A1 E2 . A1 .'), drums: 'k..hs.h.k.khs.h.' },
    peligro: { bpm: 120, lead: T('A4 . . C5 . . B4 . A4 . . E4 . . . . A4 . . C5 . . D5 . E5 . . D#5 . . . .'), bass: T('A1 A1 . A1 A1 . A1 . A1 A1 . A1 A1 . G1 . F1 F1 . F1 F1 . F1 . E1 E1 . E1 E1 . G#1 .'), drums: 'k...s..kk...s...' },
    jefe: { bpm: 168, lead: T('E5 G5 B5 G5 E5 G5 B5 G5 D5 F#5 A5 F#5 D5 F#5 A5 F#5 C5 E5 G5 E5 C5 E5 G5 E5 B4 D#5 F#5 D#5 B4 D#5 F#5 B5'), bass: T('E2 . E2 E3 E2 . E2 E3 D2 . D2 D3 D2 . D2 D3 C2 . C2 C3 C2 . C2 C3 B1 . B1 B2 B1 . B1 B2'), drums: 'k.hsk.hsk.hsk.hs' },
    meta: { bpm: 128, lead: T('G5 . B5 . D6 . . B5 C6 . B5 . A5 . . . G5 . A5 . B5 . G5 . E5 . F#5 . G5 . . .'), bass: T('G2 . G2 . D3 . G2 . C3 . C3 . A2 . D3 . G2 . G2 . E2 . E2 . C3 . D3 . G2 . . .'), drums: 'k.h.s.h.k.h.s.hh' },
    victoria: { bpm: 120, lead: T('C5 E5 G5 C6 . G5 C6 . E6 . D6 . C6 . . . A5 . C6 . D6 . E6 . D6 . C6 . . . . .'), bass: T('C3 . C3 . E3 . E3 . F3 . F3 . G3 . G3 . A2 . A2 . F2 . F2 . G2 . G2 . C3 . . .'), drums: 'k.h.s.h.k.h.s.h.' }
  };

  A.init = function () {
    if (A.ctx) { if (A.ctx.state === 'suspended' && !paused) A.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    A.ctx = new AC();
    master = A.ctx.createGain(); master.gain.value = 1; master.connect(A.ctx.destination);
    musicGain = A.ctx.createGain(); musicGain.gain.value = A.musicOn ? CFG.audio.music : 0; musicGain.connect(master);
    sfxGain = A.ctx.createGain(); sfxGain.gain.value = A.sfxOn ? CFG.audio.sfx : 0; sfxGain.connect(master);
    noiseBuf = A.ctx.createBuffer(1, A.ctx.sampleRate * 0.5, A.ctx.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    // iOS/Android: desbloquear cada pista MP3 dentro del primer toque
    for (const k of ['menu', 'general', 'dificult', 'gameover', 'breaking', 'sandoman', 'victory']) {
      const a = el(k); a.muted = true;
      const p = a.play();
      if (p && p.then) p.then(() => { if (curFile !== k || paused) a.pause(); a.muted = !A.musicOn; }).catch(() => { a.muted = !A.musicOn; });
    }
    if (A.pending) { const p = A.pending; A.pending = null; A.play(p); }
  };

  function tone(type, freq, t, dur, vol, dest, slideTo) {
    const o = A.ctx.createOscillator(), g = A.ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(dest); o.start(t); o.stop(t + dur + 0.02);
  }
  function noise(t, dur, vol, dest, hp) {
    const s = A.ctx.createBufferSource(), g = A.ctx.createGain(), f = A.ctx.createBiquadFilter();
    s.buffer = noiseBuf; f.type = hp ? 'highpass' : 'lowpass'; f.frequency.value = hp || 1200;
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f); f.connect(g); g.connect(dest); s.start(t); s.stop(t + dur + 0.02);
  }

  function schedule() {
    if (!track || !A.ctx) return;
    const sd = 60 / track.bpm / 2;
    while (nextTime < A.ctx.currentTime + 0.15) {
      const L = track.lead[step % track.lead.length], B = track.bass[step % track.bass.length];
      const D = track.drums[step % track.drums.length];
      if (L && L !== '.' && NOTE[L]) { tone('square', NOTE[L], nextTime, sd * 0.9, 0.35, musicGain); tone('square', NOTE[L] * 1.005, nextTime, sd * 0.6, 0.08, musicGain); }
      if (B && B !== '.' && NOTE[B]) tone('triangle', NOTE[B], nextTime, sd * 0.95, 0.7, musicGain);
      if (D === 'k') tone('sine', 140, nextTime, 0.12, 0.8, musicGain, 45);
      if (D === 's') noise(nextTime, 0.1, 0.35, musicGain, 1500);
      if (D === 'h') noise(nextTime, 0.03, 0.15, musicGain, 6000);
      nextTime += sd; step++;
      if (track.once && step >= track.lead.length) { track = null; A.current = null; break; }
    }
  }

  /* ---------- Música en MP3 (archivos del usuario) ----------
     zona -> pista. Si no hay MP3 disponible se usa la música chiptune sintetizada. */
  const FILE_FOR = { menu: 'menu', barrio: 'general', ciudad: 'general', camino: 'general', meta: 'general', peligro: 'dificult', jefe: 'dificult', gameover: 'gameover', breaking: 'breaking', sandoman: 'sandoman', victory: 'victory' };
  const MP3_VOL = 0.7;
  const els = {};
  let curFile = null, paused = false;
  function srcFor(key) {
    const d = G.AUDIO_DATA && G.AUDIO_DATA[key];
    if (d) {
      if (!d.url) {
        const bin = atob(d.b64), arr = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        d.url = URL.createObjectURL(new Blob([arr], { type: 'audio/mpeg' })); d.b64 = null;
      }
      return d.url;
    }
    return 'assets/audio/' + key + '.mp3';
  }
  function el(key) {
    if (!els[key]) {
      const a = new Audio(); a.src = srcFor(key); a.loop = true; a.preload = 'auto';
      a.addEventListener('error', () => { a._bad = true; if (curFile === key) { curFile = null; startSynth(A.current); } });
      els[key] = a;
    }
    return els[key];
  }
  function fade(a, to, ms, done) {
    clearInterval(a._fade);
    const from = a.volume, t0 = performance.now();
    a._fade = setInterval(() => {
      const k = Math.min(1, (performance.now() - t0) / ms);
      a.volume = Math.max(0, Math.min(1, from + (to - from) * k));
      if (k >= 1) { clearInterval(a._fade); done && done(); }
    }, 30);
  }
  function stopFile() {
    if (!curFile) return;
    const a = els[curFile]; curFile = null;
    if (a) fade(a, 0, 400, () => a.pause());
  }
  function startSynth(name, once) {
    track = name && TRACKS[name] ? Object.assign({}, TRACKS[name], { once: !!once }) : null;
    step = 0; nextTime = A.ctx ? A.ctx.currentTime + 0.05 : 0;
    if (!timer && A.ctx) timer = setInterval(schedule, 25);
  }
  A.play = function (name, once) {
    if (!A.ctx) { A.pending = name; return; }
    if (A.current === name) return;
    A.current = name;
    const key = name && FILE_FOR[name];
    if (key && !(els[key] && els[key]._bad)) {
      track = null;
      if (curFile === key) return;           // misma pista (p. ej. de vecindario a ciudad): sigue sonando
      stopFile();
      const a = el(key); curFile = key;
      if (name === 'gameover' || name === 'menu' || name === 'victory' || name === 'sandoman') a.currentTime = 0;
      a.volume = 0; a.muted = !A.musicOn;
      if (!paused) { const p = a.play(); if (p && p.catch) p.catch(() => {}); }
      fade(a, MP3_VOL, 600);
      return;
    }
    stopFile();
    startSynth(name, once);
  };
  /* Pausa la música real (al pausar el juego o al salir de la app) */
  A.setPaused = function (v) {
    if (paused === v) return; paused = v;
    const a = curFile && els[curFile];
    if (a) { if (v) a.pause(); else { const p = a.play(); if (p && p.catch) p.catch(() => {}); } }
    if (A.ctx) { if (v) A.ctx.suspend(); else A.ctx.resume(); }
  };
  A._debug = () => ({ curFile, els: Object.keys(els).map(k => [k, !els[k].paused, +els[k].currentTime.toFixed(1), !!els[k]._bad]) });
  A.stop = function () { track = null; A.current = null; stopFile(); };

  A.setMusic = function (on) {
    A.musicOn = on;
    for (const k in els) els[k].muted = !on;
    if (musicGain) musicGain.gain.setTargetAtTime(on ? CFG.audio.music : 0, A.ctx.currentTime, 0.05);
  };
  A.setSfx = function (on) {
    A.sfxOn = on;
    if (sfxGain) sfxGain.gain.setTargetAtTime(on ? CFG.audio.sfx : 0, A.ctx.currentTime, 0.05);
  };

  A.sfx = function (name) {
    if (!A.ctx || !A.sfxOn) return;
    const t = A.ctx.currentTime, d = sfxGain;
    switch (name) {
      case 'jump': tone('square', 260, t, 0.16, 0.5, d, 720); break;
      case 'land': noise(t, 0.05, 0.25, d, 400); break;
      case 'step': noise(t, 0.025, 0.12, d, 2500); break;
      case 'duck': tone('square', 300, t, 0.06, 0.25, d, 180); break;
      case 'hit': noise(t, 0.25, 0.9, d, 300); tone('square', 220, t, 0.3, 0.5, d, 60); break;
      case 'stomp': tone('square', 600, t, 0.12, 0.5, d, 150); noise(t, 0.08, 0.4, d, 800); break;
      case 'coin': tone('square', 988, t, 0.06, 0.35, d); tone('square', 1319, t + 0.06, 0.14, 0.35, d); break;
      case 'blip': tone('square', 880, t, 0.03, 0.08, d); break;
      case 'npc': tone('triangle', 660, t, 0.07, 0.4, d); tone('triangle', 990, t + 0.07, 0.1, 0.4, d); break;
      case 'honk': tone('square', 330, t, 0.18, 0.35, d); tone('square', 392, t, 0.18, 0.25, d); tone('square', 330, t + 0.25, 0.25, 0.35, d); tone('square', 392, t + 0.25, 0.25, 0.25, d); break;
      case 'bark': tone('sawtooth', 500, t, 0.08, 0.4, d, 250); tone('sawtooth', 520, t + 0.14, 0.08, 0.4, d, 260); break;
      case 'whistle': tone('sine', 1600, t, 0.5, 0.25, d, 400); break;
      case 'splash': noise(t, 0.3, 0.5, d, 1200); break;
      case 'zone': [523, 659, 784, 1046].forEach((f, i) => tone('square', f, t + i * 0.08, 0.12, 0.3, d)); break;
      case 'bossroar': tone('sawtooth', 120, t, 0.8, 0.6, d, 50); noise(t, 0.6, 0.4, d, 200); break;
      case 'bosshit': noise(t, 0.2, 0.8, d, 500); tone('square', 200, t, 0.25, 0.5, d, 80); tone('square', 900, t + 0.02, 0.1, 0.3, d, 1400); break;
      case 'throw': tone('triangle', 400, t, 0.15, 0.4, d, 900); break;
      case 'explode': noise(t, 0.9, 1, d, 150); tone('sawtooth', 90, t, 1, 0.5, d, 30); break;
      case 'door': tone('square', 200, t, 0.1, 0.3, d, 300); noise(t + 0.1, 0.2, 0.2, d, 3000); break;
      case 'busdoor': noise(t, 0.4, 0.4, d, 2500); tone('sine', 300, t, 0.3, 0.2, d, 200); break;
      case 'horn': tone('sawtooth', 220, t, 0.5, 0.35, d); tone('sawtooth', 277, t, 0.5, 0.25, d); break;
      case 'gameover': [392, 370, 349, 330].forEach((f, i) => tone('square', f, t + i * 0.25, 0.3, 0.4, d)); tone('triangle', 165, t + 1, 0.8, 0.5, d, 80); break;
      case 'confetti': for (let i = 0; i < 6; i++) tone('square', 800 + Math.random() * 800, t + i * 0.05, 0.05, 0.15, d); break;
      case 'select': tone('square', 660, t, 0.05, 0.3, d); tone('square', 990, t + 0.05, 0.08, 0.3, d); break;
    }
  };
})();
