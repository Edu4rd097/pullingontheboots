/* =========================================================
   EL CAMINO AL OBJETIVO - Configuración centralizada
   Todos los parámetros ajustables del juego viven aquí.
   ========================================================= */
window.G = window.G || {};

G.CFG = {
  W: 320,              // resolución interna (pixel-perfect)
  H: 180,
  GROUND: 150,         // y del suelo (pies del personaje)
  PLAYER_X: 112,       // posición horizontal del personaje en pantalla

  // Física
  gravity: 1150,
  jumpVel: 345,
  jumpCut: 0.45,       // al soltar el salto antes de tiempo
  fastFall: 2200,      // agacharse en el aire acelera la caída
  coyoteTime: 0.08,
  jumpBuffer: 0.12,

  // Velocidad (px/s) - aumenta con el progreso
  speedStart: 92,
  speedMax: 158,
  bossSpeed: 118,

  // Recorrido
  courseLength: 26000,           // px totales de casa a camión
  pxPerMeter: 10,
  zones: [
    { id: 'vecindario', name: 'EL BARRIO',             start: 0.00, end: 0.15, color: '#5fcde4', music: 'barrio' },
    { id: 'ciudad',     name: 'LAS CALLES',           start: 0.15, end: 0.35, color: '#fbf236', music: 'ciudad' },
    { id: 'camino',     name: 'JUÁREZ',               start: 0.35, end: 0.55, color: '#df7126', music: 'camino' },
    { id: 'peligro',    name: 'TERRITORIO PELIGROSO', start: 0.55, end: 0.80, color: '#76428a', music: 'peligro' },
    { id: 'jefe',       name: 'PARTE FINAL',          start: 0.80, end: 0.95, color: '#ac3232', music: 'jefe' },
    { id: 'meta',       name: 'CADEREYTA',            start: 0.95, end: 1.00, color: '#99e550', music: 'meta' }
  ],
  zoneBlend: 0.025,              // fracción del recorrido para el fundido entre zonas

  // Obstáculos
  obstacles: {
    warmup: 0.035,               // sin obstáculos al inicio
    calmBeforeBoss: 0.025,       // calma antes del jefe
    gapMin: [1.05, 0.45],        // segundos extra entre obstáculos (inicio -> final)
    gapMax: [2.10, 1.05],
    comboChance: [0.08, 0.38],   // probabilidad de patrones combinados
    reaction: 0.30
  },

  // Vida
  hearts: 3,
  invuln: 1.5,

  // Jefe
  boss: { hp: 6, name: 'LIC. MIJESEX3', title: 'SEÑOR DEL "VUELVA MAÑANA"' },

  // Diálogos
  dialog: { minInterval: 4.5, randomEvery: [7, 12], charsPerSec: 38, holdBase: 2.2, holdPerChar: 0.045 },

  // Puntuación
  score: { perMeter: 1, obstacle: 15, stomp: 150, bossHit: 300, noHitBonus: 2000, npc: 25 },

  // Audio
  audio: { music: 0.11, sfx: 0.22 }
};

/* Parámetros de depuración por URL: ?auto=1 (autopiloto) &ts=3 (velocidad) &start=0.78 (progreso) */
G.DEBUG = (function () {
  const q = new URLSearchParams(location.search);
  return {
    auto: q.get('auto') === '1',
    timeScale: parseFloat(q.get('ts') || '1') || 1,
    start: parseFloat(q.get('start') || '0') || 0,
    god: q.get('god') === '1'
  };
})();
if (G.DEBUG && new URLSearchParams(location.search).get('level') === '2') G.START_LEVEL = 2;
