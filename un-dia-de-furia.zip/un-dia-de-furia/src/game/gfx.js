/* =========================================================
   Utilidades gráficas: lienzos, RNG con semilla, fuente pixel
   ========================================================= */
(function () {
  const G = window.G;

  G.rng = function (seed) {
    let a = (seed >>> 0) || 1;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };
  G.rand = (a, b) => a + Math.random() * (b - a);
  G.randi = (a, b) => Math.floor(G.rand(a, b + 1));
  G.pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  G.lerp = (a, b, t) => a + (b - a) * t;
  G.clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  /* Crea un lienzo y lo pinta con un "pintor" de píxeles */
  G.mk = function (w, h, fn) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const ctx = c.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    if (fn) fn(G.painter(ctx), ctx);
    return c;
  };

  G.painter = function (ctx) {
    return {
      ctx,
      r(x, y, w, h, c) { if (!c) return; ctx.fillStyle = c; ctx.fillRect(x | 0, y | 0, w | 0, h | 0); },
      p(x, y, c) { if (!c) return; ctx.fillStyle = c; ctx.fillRect(x | 0, y | 0, 1, 1); },
      line(x0, y0, x1, y1, c, t = 1) {
        ctx.fillStyle = c;
        const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) || 1;
        for (let i = 0; i <= n; i++) {
          const x = Math.round(x0 + (x1 - x0) * i / n), y = Math.round(y0 + (y1 - y0) * i / n);
          ctx.fillRect(x, y, t, t);
        }
      },
      /* rows: array de strings; map: {char: color} */
      grid(rows, map, ox = 0, oy = 0) {
        for (let y = 0; y < rows.length; y++) {
          const row = rows[y];
          for (let x = 0; x < row.length; x++) {
            const col = map[row[x]];
            if (col) { ctx.fillStyle = col; ctx.fillRect(ox + x, oy + y, 1, 1); }
          }
        }
      },
      circle(cx, cy, rad, c) {
        ctx.fillStyle = c;
        for (let y = -rad; y <= rad; y++) {
          const w = Math.round(Math.sqrt(rad * rad - y * y));
          ctx.fillRect(cx - w, cy + y, w * 2 + 1, 1);
        }
      }
    };
  };

  /* Versión con color sólido (para destellos de daño) */
  G.tint = function (src, color) {
    return G.mk(src.width, src.height, (p, ctx) => {
      ctx.drawImage(src, 0, 0);
      ctx.globalCompositeOperation = 'source-in';
      ctx.fillStyle = color; ctx.fillRect(0, 0, src.width, src.height);
    });
  };
  G.flip = function (src) {
    return G.mk(src.width, src.height, (p, ctx) => {
      ctx.translate(src.width, 0); ctx.scale(-1, 1); ctx.drawImage(src, 0, 0);
    });
  };

  /* -------------------- Fuente pixel 5px de alto -------------------- */
  const F = {
    A: ['.#.', '#.#', '###', '#.#', '#.#'], B: ['##.', '#.#', '##.', '#.#', '##.'],
    C: ['.##', '#..', '#..', '#..', '.##'], D: ['##.', '#.#', '#.#', '#.#', '##.'],
    E: ['###', '#..', '##.', '#..', '###'], F: ['###', '#..', '##.', '#..', '#..'],
    G: ['.##', '#..', '#.#', '#.#', '.##'], H: ['#.#', '#.#', '###', '#.#', '#.#'],
    I: ['###', '.#.', '.#.', '.#.', '###'], J: ['..#', '..#', '..#', '#.#', '.#.'],
    K: ['#.#', '#.#', '##.', '#.#', '#.#'], L: ['#..', '#..', '#..', '#..', '###'],
    M: ['#...#', '##.##', '#.#.#', '#...#', '#...#'], N: ['#..#', '##.#', '#.##', '#..#', '#..#'],
    O: ['.#.', '#.#', '#.#', '#.#', '.#.'], P: ['##.', '#.#', '##.', '#..', '#..'],
    Q: ['.#.', '#.#', '#.#', '##.', '.##'], R: ['##.', '#.#', '##.', '#.#', '#.#'],
    S: ['.##', '#..', '.#.', '..#', '##.'], T: ['###', '.#.', '.#.', '.#.', '.#.'],
    U: ['#.#', '#.#', '#.#', '#.#', '###'], V: ['#.#', '#.#', '#.#', '#.#', '.#.'],
    W: ['#...#', '#...#', '#.#.#', '##.##', '#...#'], X: ['#.#', '#.#', '.#.', '#.#', '#.#'],
    Y: ['#.#', '#.#', '.#.', '.#.', '.#.'], Z: ['###', '..#', '.#.', '#..', '###'],
    0: ['###', '#.#', '#.#', '#.#', '###'], 1: ['.#.', '##.', '.#.', '.#.', '###'],
    2: ['##.', '..#', '.#.', '#..', '###'], 3: ['##.', '..#', '.#.', '..#', '##.'],
    4: ['#.#', '#.#', '###', '..#', '..#'], 5: ['###', '#..', '##.', '..#', '##.'],
    6: ['.##', '#..', '###', '#.#', '###'], 7: ['###', '..#', '.#.', '.#.', '.#.'],
    8: ['###', '#.#', '###', '#.#', '###'], 9: ['###', '#.#', '###', '..#', '##.'],
    ' ': ['..', '..', '..', '..', '..'], '.': ['.', '.', '.', '.', '#'], ',': ['.', '.', '.', '#', '#'],
    '!': ['#', '#', '#', '.', '#'], '¡': ['#', '.', '#', '#', '#'],
    '?': ['##.', '..#', '.#.', '...', '.#.'], '¿': ['.#.', '...', '.#.', '#..', '.##'],
    ':': ['.', '#', '.', '#', '.'], ';': ['.', '#', '.', '#', '#'], '-': ['...', '...', '###', '...', '...'],
    '/': ['..#', '..#', '.#.', '#..', '#..'], '%': ['#.#', '..#', '.#.', '#..', '#.#'],
    '"': ['#.#', '#.#', '...', '...', '...'], "'": ['#', '#', '.', '.', '.'],
    '(': ['.#', '#.', '#.', '#.', '.#'], ')': ['#.', '.#', '.#', '.#', '#.'],
    '+': ['...', '.#.', '###', '.#.', '...'], '=': ['...', '###', '...', '###', '...'],
    '>': ['#..', '.#.', '..#', '.#.', '#..'], '<': ['..#', '.#.', '#..', '.#.', '..#'],
    '*': ['...', '#.#', '.#.', '#.#', '...'], '_': ['...', '...', '...', '...', '###'],
    '#': ['#.#', '###', '#.#', '###', '#.#'], '$': ['.##', '##.', '.#.', '.##', '##.'],
    '&': ['.#.', '#.#', '.#.', '#.#', '.##'], '…': ['.....', '.....', '.....', '.....', '#.#.#'],
    '♥': ['#.#', '###', '###', '.#.', '...'], '♪': ['.##', '.#.', '.#.', '##.', '##.'],
    '▶': ['#..', '##.', '###', '##.', '#..'], '▲': ['.....', '..#..', '.###.', '#####', '.....'], '▼': ['.....', '#####', '.###.', '..#..', '.....']
  };
  const glyphCache = new Map();

  function decompose(ch) {
    const d = ch.normalize('NFD');
    let base = d[0], mark = null;
    if (d.length > 1) { if (d[1] === '́') mark = 'acute'; else if (d[1] === '̃') mark = 'tilde'; else if (d[1] === '̈') mark = 'diaer'; }
    base = base.toUpperCase();
    return { base, mark };
  }
  function glyph(ch, color) {
    const key = ch + '|' + color;
    let g = glyphCache.get(key);
    if (g) return g;
    const { base, mark } = decompose(ch);
    const rows = F[base] || F['?'];
    const w = rows[0].length;
    g = G.mk(w, 7, (p) => {
      p.grid(rows, { '#': color }, 0, 2);
      if (mark === 'acute') p.p(Math.min(w - 1, (w >> 1) + 1), 0, color);
      if (mark === 'tilde') { p.r(0, 1, w - 1, 1, color); p.p(1, 0, color); p.p(w - 1, 0, color); }
      if (mark === 'diaer') { p.p(0, 0, color); p.p(w - 1, 0, color); }
    });
    g.adv = w + 1;
    glyphCache.set(key, g);
    return g;
  }
  G.textWidth = function (s, scale = 1) {
    let w = 0;
    for (const ch of s) { const { base } = decompose(ch); w += ((F[base] || F['?'])[0].length + 1); }
    return Math.max(0, w - 1) * scale;
  };
  /* y = parte superior del texto (letras ocupan y..y+4, acentos y-2) */
  G.text = function (ctx, s, x, y, color = '#fff', opts = {}) {
    const scale = opts.scale || 1;
    s = String(s);
    const w = G.textWidth(s, scale);
    if (opts.align === 'center') x -= w / 2;
    else if (opts.align === 'right') x -= w;
    x = Math.round(x); y = Math.round(y);
    if (opts.shadow) G.text(ctx, s, x + scale, y + scale, opts.shadow, { scale });
    if (opts.outline) {
      for (const [dx, dy] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) G.text(ctx, s, x + dx * scale, y + dy * scale, opts.outline, { scale });
    }
    let cx = x;
    for (const ch of s) {
      const g = glyph(ch, color);
      ctx.drawImage(g, cx, y - 2 * scale, g.width * scale, g.height * scale);
      cx += g.adv * scale;
    }
    return w;
  };
  G.wrap = function (s, maxW) {
    const words = s.split(' ');
    const lines = []; let cur = '';
    for (const w of words) {
      const t = cur ? cur + ' ' + w : w;
      if (G.textWidth(t) > maxW && cur) { lines.push(cur); cur = w; } else cur = t;
    }
    if (cur) lines.push(cur);
    return lines;
  };

  /* Caja estilo retro con borde */
  G.box = function (ctx, x, y, w, h, fill = '#1a1c2c', border = '#f4f4f4', shade = '#000') {
    x |= 0; y |= 0; w |= 0; h |= 0;
    if (shade) { ctx.fillStyle = shade; ctx.fillRect(x + 1, y + h, w, 1); ctx.fillRect(x + w, y + 1, 1, h); }
    ctx.fillStyle = border; ctx.fillRect(x + 1, y, w - 2, h); ctx.fillRect(x, y + 1, w, h - 2);
    ctx.fillStyle = fill; ctx.fillRect(x + 1, y + 1, w - 2, h - 2);
  };
})();
