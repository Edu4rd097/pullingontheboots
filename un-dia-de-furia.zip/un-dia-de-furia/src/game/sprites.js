/* =========================================================
   Sprites Pixel Art generados por código (sin imágenes realistas)
   Referencias: carpeta nivel1/ (personaje punk, perros, motosimio,
   camión verde/naranja de la carpeta objetivo).
   ========================================================= */
(function () {
  const G = window.G;
  const C = G.PAL = {
    ink: '#14101e', black: '#1a1c2c', dark: '#222034', vestHi: '#45405e',
    skin: '#f2c39b', skinS: '#d08b62', skinD: '#8a5a3c', skinM: '#c68642', skinMS: '#9a6233',
    red: '#d8283a', redD: '#9e1630', white: '#f4f4f4', grey: '#9badb7', greyD: '#596b7a', greyL: '#cbdbfc',
    blue: '#4b7bd1', blueD: '#34539a', navy: '#1d2b53', sky: '#5fcde4',
    green: '#2fae4a', greenD: '#1f7d36', greenL: '#7ee06b', olive: '#5b6e1f',
    orange: '#f08a24', orangeD: '#b35a12', yellow: '#fbe043', yellowD: '#c9a227',
    brown: '#8f563b', brownD: '#5e3826', tan: '#d9a066', purple: '#76428a', purpleD: '#45283c', pink: '#d77bba',
    cream: '#f3e2bd', peach: '#f2a65e', water: '#3f8fd1', waterL: '#8fd3ff', mud: '#6b4a2f'
  };
  const S = G.SPR = {};

  /* ---------------------------------------------------------------
     PROTAGONISTA: punk de cresta roja, chaleco negro con estoperoles,
     brazos tatuados, jeans rotos y botas (ver personajeprincipal.jfif)
     Lienzo 24x28, ancla en (9, 27) = pies.
     --------------------------------------------------------------- */
  function punk(pose, f) {
    return G.mk(24, 28, (p) => {
      if (pose === 'dead') return punkDead(p);
      if (pose === 'duck') return punkDuck(p, f);
      const bob = (pose === 'walk' && f % 2 === 1) ? -1 : 0;
      const hx = 6, hy = 5 + bob;
      const tx = 5, ty = hy + 8;
      // Piernas
      const hipY = ty + 8;
      let front, back, liftF = 0, liftB = 0;
      if (pose === 'walk') { front = [3, 1, -2, 0][f]; back = [-2, 0, 3, 1][f]; liftB = f === 1 ? 2 : 0; liftF = f === 3 ? 2 : 0; }
      else if (pose === 'jump' || pose === 'win1') { front = 4; back = -1; liftF = 4; liftB = 1; }
      else if (pose === 'fall') { front = 2; back = -2; }
      else { front = 1; back = -1; }
      const leg = (hipX, off, lift, col, colS) => {
        const footY = 24 - lift;
        for (let y = hipY; y <= footY; y++) {
          const x = Math.round(hipX + off * (y - hipY) / (footY - hipY));
          p.r(x, y, 3, 1, col); p.p(x, y, colS);
        }
        const fx = hipX + off;
        p.r(fx, footY + 1, 4, 2, C.ink); p.p(fx + 3, footY + 1, C.dark);
        p.p(Math.round(hipX + off / 2) + 1, Math.round((hipY + footY) / 2), C.white); // jeans rotos
      };
      leg(tx + 1, back, liftB, C.blueD, '#2a3f73');
      leg(tx + 3, front, liftF, C.blue, C.blueD);
      // Torso / chaleco
      p.r(tx, ty, 8, 8, C.dark);
      p.r(tx + 6, ty + 1, 1, 5, C.skin);
      p.r(tx + 7, ty + 1, 1, 6, C.vestHi);
      p.p(tx, ty, C.greyL); p.p(tx + 2, ty, C.greyL); p.p(tx + 5, ty, C.greyL); p.p(tx + 7, ty, C.greyL);
      p.r(tx, ty + 7, 8, 1, C.ink); // cinturón
      p.p(tx + 1, ty + 8, C.grey); p.p(tx + 2, ty + 9, C.grey); p.p(tx + 3, ty + 9, C.grey); p.p(tx + 4, ty + 8, C.grey); // cadena
      // Brazo
      const armUp = pose === 'jump' || pose === 'hit' || pose === 'win0' || pose === 'win1';
      if (armUp) {
        p.r(tx + 3, ty - 4, 2, 5, C.skin); p.p(tx + 3, ty - 2, C.red); p.r(tx + 3, ty - 5, 2, 1, C.skinS);
        p.r(tx + 3, ty - 1, 2, 1, C.ink);
        if (pose !== 'jump') { p.r(tx - 1, ty - 4, 2, 5, C.skinS); p.p(tx - 1, ty - 2, C.redD); }
      } else if (pose === 'fall') {
        p.r(tx + 4, ty + 1, 5, 2, C.skin); p.p(tx + 6, ty + 1, C.red); p.r(tx + 9, ty + 1, 1, 2, C.skinS);
      } else {
        const a = pose === 'walk' ? [-1, 0, 1, 0][f] : 0;
        p.r(tx + 3 + a, ty + 1, 2, 5, C.skin);
        p.p(tx + 3 + a, ty + 2, C.red); p.p(tx + 4 + a, ty + 4, C.red);
        p.r(tx + 3 + a, ty + 5, 2, 1, C.ink); p.p(tx + 4 + a, ty + 5, C.greyL);
        p.r(tx + 3 + a * 2, ty + 6, 2, 2, C.skin);
      }
      // Cabeza
      p.r(hx, hy, 7, 7, C.skin);
      p.r(hx, hy + 1, 1, 5, C.skinS);
      p.p(hx + 2, hy + 3, C.skinS); p.p(hx + 2, hy + 4, C.skinS); // oreja
      p.p(hx + 7, hy + 3, C.skinS); // nariz
      if (pose === 'hit') {
        p.p(hx + 4, hy + 2, C.ink); p.p(hx + 6, hy + 2, C.ink); p.p(hx + 5, hy + 3, C.ink); p.p(hx + 4, hy + 4, C.ink); p.p(hx + 6, hy + 4, C.ink);
        p.r(hx + 5, hy + 5, 2, 2, C.redD);
      } else if (pose === 'win0' || pose === 'win1') {
        p.p(hx + 5, hy + 3, C.ink); p.r(hx + 4, hy + 5, 3, 1, C.ink); p.p(hx + 6, hy + 4, C.ink);
      } else {
        p.r(hx + 4, hy + 2, 3, 1, C.ink); p.p(hx + 4, hy + 1, C.ink); // ceja enojada
        p.p(hx + 5, hy + 3, C.ink); p.r(hx + 5, hy + 5, 2, 1, C.skinS);
      }
      // Cresta roja
      const hs = [2, 4, 5, 4, 3];
      p.r(hx + 1, hy, 5, 1, C.red);
      for (let i = 0; i < 5; i++) {
        p.r(hx + 1 + i, hy - hs[i], 1, hs[i], i < 2 ? C.redD : C.red);
      }
      p.p(hx, hy - 1, C.redD);
    });
  }
  function punkDuck(p, f) {
    // agachado y "aerodinámico"
    const hx = 13, hy = 15;
    p.r(4, 17, 10, 6, C.dark); p.p(5, 17, C.greyL); p.p(8, 17, C.greyL); p.p(11, 17, C.greyL);
    p.r(4, 22, 10, 1, C.ink);
    const k = f ? 1 : 0;
    p.r(5, 23, 4, 2, C.blueD); p.r(4 + k, 25, 4, 2, C.ink);
    p.r(10, 23, 4, 2, C.blue); p.r(11 - k, 25, 4, 2, C.ink);
    p.r(12, 20, 4, 2, C.skin); p.p(13, 20, C.red); p.r(16, 20, 1, 2, C.skinS);
    p.r(hx, hy, 7, 7, C.skin); p.r(hx, hy + 1, 1, 5, C.skinS);
    p.p(hx + 2, hy + 3, C.skinS); p.p(hx + 7, hy + 3, C.skinS);
    p.r(hx + 4, hy + 2, 3, 1, C.ink); p.p(hx + 5, hy + 3, C.ink); p.r(hx + 5, hy + 5, 2, 1, C.skinS);
    // cresta hacia atrás por el viento
    p.r(hx - 5, hy, 7, 1, C.redD); p.r(hx - 3, hy - 1, 7, 1, C.red); p.r(hx - 1, hy + 1, 2, 1, C.red);
    p.p(hx - 6 - f, hy - 1, C.redD); p.p(hx - 4, hy - 2, C.red);
  }
  function punkDead(p) {
    p.r(2, 23, 9, 3, C.blue); p.r(0, 23, 2, 3, C.ink);
    p.r(10, 21, 8, 5, C.dark); p.p(11, 21, C.greyL); p.p(14, 21, C.greyL);
    p.r(12, 19, 2, 2, C.skin);
    p.r(17, 20, 6, 6, C.skin);
    p.p(19, 21, C.ink); p.p(21, 21, C.ink); p.p(20, 22, C.ink); p.p(19, 23, C.ink); p.p(21, 23, C.ink);
    p.r(18, 26, 6, 1, C.red); p.r(22, 22, 2, 4, C.redD);
    p.r(0, 27, 24, 1, 'rgba(0,0,0,0.25)');
  }
  S.player = {
    walk: [0, 1, 2, 3].map(f => punk('walk', f)),
    stand: punk('stand', 0),
    jump: punk('jump', 0),
    fall: punk('fall', 0),
    duck: [punk('duck', 0), punk('duck', 1)],
    hit: punk('hit', 0),
    win: [punk('win0', 0), punk('win1', 0)],
    dead: punk('dead', 0),
    ax: 9, ay: 27
  };
  S.playerHead = G.mk(9, 10, (p) => {
    p.r(1, 3, 7, 7, C.skin); p.p(5, 6, C.ink); p.r(4, 5, 3, 1, C.ink);
    const hs = [2, 3, 3, 3, 2]; for (let i = 0; i < 5; i++) p.r(2 + i, 3 - hs[i], 1, hs[i], C.red);
  });

  /* ---------------------------------------------------------------
     PERSONAS GENÉRICAS (vecinos, peatones, enemigos)
     Lienzo 16x27, ancla (7, 26). Mira a la derecha (se voltea).
     --------------------------------------------------------------- */
  function human(o, f, pose) {
    return G.mk(16, 27, (p) => {
      const ex = o.extra || [];
      const bob = (pose === 'walk' && f % 2 === 1) ? -1 : 0;
      const hx = 5, hy = 3 + bob + (o.short ? 2 : 0);
      const tx = 5, ty = hy + 6;
      const skin = o.skin || C.skin, skinS = o.skinS || C.skinS;
      // pelo largo detrás
      if (o.hair === 'long' || o.hair === 'pony') p.r(hx - 1, hy + 1, 3, o.hair === 'long' ? 9 : 5, o.hairC);
      if (ex.includes('chair')) { p.r(2, 17, 10, 2, C.brown); p.r(2, 19, 1, 7, C.brownD); p.r(11, 19, 1, 7, C.brownD); p.r(2, 10, 1, 8, C.brownD); }
      // piernas
      const hipY = ty + 8;
      const legs = (pose === 'walk') ? [[2, -1][0], 0] : null;
      let fo = 1, bo = -1;
      if (pose === 'walk') { fo = [2, 0, -2, 0][f]; bo = [-2, 0, 2, 0][f]; }
      if (ex.includes('chair')) {
        p.r(tx + 1, hipY - 1, 6, 2, o.pants); p.r(tx + 6, hipY + 1, 2, 6, o.pants); p.r(tx + 6, 24, 3, 2, o.shoes || C.ink);
      } else if (o.skirt) {
        p.r(tx - 1, ty + 7, 8, 5, o.pants);
        p.r(tx + 1 + bo, ty + 12, 2, 24 - ty - 12, skinS); p.r(tx + 3 + fo, ty + 12, 2, 24 - ty - 12, skin);
        p.r(tx + bo, 24, 3, 2, o.shoes || C.ink); p.r(tx + 3 + fo, 24, 3, 2, o.shoes || C.ink);
      } else {
        const leg = (hx0, off, col) => {
          for (let y = hipY; y <= 23; y++) p.r(Math.round(hx0 + off * (y - hipY) / (23 - hipY)), y, 2, 1, col);
          p.r(hx0 + off, 24, 3, 2, o.shoes || C.ink);
        };
        p.r(tx, ty + 7, 6, 2, o.pants);
        leg(tx + 1, bo, o.pantsS || o.pants);
        leg(tx + 3, fo, o.pants);
      }
      // torso
      p.r(tx, ty, 6, 8, o.shirt);
      if (o.shirt2) p.r(tx + 4, ty, 2, 8, o.shirt2);
      if (ex.includes('vest')) { p.r(tx, ty + 1, 6, 6, C.orange); p.r(tx, ty + 3, 6, 1, C.yellow); }
      if (ex.includes('apron')) p.r(tx + 1, ty + 2, 5, 7, C.white);
      if (ex.includes('suit')) { p.r(tx + 4, ty, 1, 5, C.white); p.p(tx + 4, ty + 1, C.red); }
      if (ex.includes('badge')) { p.p(tx + 4, ty + 2, C.yellow); p.r(tx, ty + 6, 6, 1, C.ink); }
      if (ex.includes('bag')) { p.r(tx - 3, ty + 1, 4, 7, '#8a7a5a'); p.r(tx - 3, ty + 1, 4, 1, '#6a5a3a'); }
      if (ex.includes('chain')) { p.p(tx + 3, ty + 1, C.yellow); p.p(tx + 4, ty + 2, C.yellow); p.p(tx + 5, ty + 1, C.yellow); }
      if (ex.includes('logo')) { p.r(tx + 1, ty + 2, 2, 2, C.white); }
      if (ex.includes('belly')) { p.r(tx + 5, ty + 3, 2, 4, o.shirt); }
      // brazo
      const a = pose === 'walk' ? [-1, 0, 1, 0][f] : 0;
      if (ex.includes('phone')) {
        p.r(tx + 2, ty + 1, 2, 3, o.sleeve || o.shirt); p.r(tx + 4, ty + 1, 2, 2, skin); p.r(tx + 6, hy + 2, 1, 3, C.ink); p.p(tx + 6, hy + 2, C.sky);
      } else if (ex.includes('thumb')) {
        p.r(tx + 3, ty + 1, 3, 2, o.sleeve || o.shirt); p.r(tx + 6, ty - 1, 2, 3, skin); p.p(tx + 7, ty - 2, skin);
      } else if (ex.includes('selfie')) {
        p.r(tx + 3, ty + 1, 2, 3, o.sleeve || o.shirt); p.r(tx + 5, ty, 2, 2, skin); p.line(tx + 6, ty, tx + 10, hy - 3, C.grey); p.r(tx + 9, hy - 5, 3, 2, C.ink);
      } else if (ex.includes('cards')) {
        p.r(tx + 3, ty + 1, 3, 2, o.sleeve || o.shirt); p.r(tx + 6, ty + 1, 2, 2, skin);
        p.r(tx + 7, ty - 2, 2, 3, C.yellow); p.r(tx + 8, ty - 1, 2, 3, C.blue); p.r(tx + 9, ty, 2, 3, C.red);
      } else if (ex.includes('hose')) {
        p.r(tx + 3, ty + 1, 3, 2, o.sleeve || o.shirt); p.r(tx + 6, ty + 1, 2, 2, skin); p.r(tx + 8, ty + 1, 2, 1, C.green);
        p.line(tx + 3, ty + 3, 1, 25, C.green);
      } else {
        p.r(tx + 2 + a, ty + 1, 2, 5, o.sleeve || o.shirt);
        p.r(tx + 2 + a * 2, ty + 6, 2, 2, skin);
      }
      if (ex.includes('broom')) { p.line(tx + 4, ty - 3, tx + 2, 24, C.brown); p.r(tx - 1, 23, 6, 3, C.yellowD); }
      if (ex.includes('cane')) { p.line(tx + 6, ty + 5, tx + 8, 25, C.brownD); }
      if (ex.includes('briefcase')) { p.r(tx + 2 + a * 2, ty + 7, 5, 4, C.brownD); }
      if (ex.includes('clipboard')) { p.r(tx + 5, ty + 2, 4, 5, C.tan); p.r(tx + 6, ty + 3, 2, 1, C.white); }
      // cabeza
      p.r(hx, hy, 6, 6, skin);
      p.r(hx, hy + 1, 1, 4, skinS);
      p.p(hx + 1, hy + 3, skinS);
      p.p(hx + 6, hy + 3, skinS);
      // cara
      if (o.hair === 'hood') {
        p.r(hx - 1, hy - 1, 8, 9, o.hairC); p.r(hx + 2, hy + 1, 4, 5, C.ink);
        p.p(hx + 4, hy + 3, C.yellow); p.p(hx + 2, hy + 3, C.yellow);
      } else {
        p.p(hx + 4, hy + 2, C.ink);
        if (o.glasses) { p.r(hx + 2, hy + 2, 4, 1, C.ink); p.p(hx + 3, hy + 1, C.ink); }
        if (o.mustache) p.r(hx + 3, hy + 4, 3, 1, o.mustache);
        else p.r(hx + 4, hy + 4, 2, 1, o.smile ? C.white : skinS);
        if (o.beard) { p.r(hx + 1, hy + 4, 5, 2, o.beard); p.p(hx + 4, hy + 4, skinS); }
        if (o.lips) p.r(hx + 4, hy + 4, 2, 1, C.red);
      }
      // pelo / sombreros
      const hc = o.hairC;
      switch (o.hair) {
        case 'short': p.r(hx, hy - 1, 6, 2, hc); p.r(hx, hy + 1, 2, 2, hc); break;
        case 'long': p.r(hx, hy - 1, 6, 2, hc); p.r(hx, hy, 2, 4, hc); p.r(hx + 4, hy, 2, 1, hc); break;
        case 'pony': p.r(hx, hy - 1, 6, 2, hc); p.r(hx - 2, hy, 2, 2, hc); break;
        case 'bun': p.r(hx, hy - 1, 6, 2, hc); p.r(hx - 1, hy - 2, 3, 3, hc); p.r(hx, hy + 1, 1, 2, hc); break;
        case 'bald': p.r(hx, hy + 1, 1, 3, hc); p.p(hx + 1, hy - 0, skinS); break;
        case 'pompa': p.r(hx, hy - 2, 7, 3, hc); p.r(hx, hy + 1, 2, 2, hc); p.p(hx + 6, hy - 3, hc); break;
        case 'cap': p.r(hx, hy - 1, 6, 2, hc); p.r(hx + 6, hy, 3, 1, hc); p.r(hx, hy + 1, 1, 2, C.ink); break;
        case 'hat': p.r(hx - 2, hy, 10, 1, hc); p.r(hx, hy - 3, 6, 3, hc); p.r(hx, hy - 1, 6, 1, C.redD); break;
        case 'helmet': p.r(hx - 1, hy - 2, 8, 3, C.yellow); p.r(hx - 1, hy + 1, 9, 1, C.yellowD); p.r(hx, hy - 3, 6, 1, C.yellow); break;
        case 'moto': p.r(hx - 1, hy - 2, 8, 5, C.orange); p.r(hx + 3, hy, 4, 2, C.ink); p.p(hx, hy - 1, C.white); break;
      }
    });
  }
  G.makePerson = function (o) {
    const r = { walk: [0, 1, 2, 3].map(f => human(o, f, 'walk')), stand: human(o, 0, 'stand'), ax: 7, ay: 26 };
    r.walkL = r.walk.map(G.flip); r.standL = G.flip(r.stand);
    return r;
  };

  /* ---------------------------------------------------------------
     ANIMALES Y VEHÍCULOS
     --------------------------------------------------------------- */
  function dog(f, col, patch) {
    // mirando a la izquierda, 18x11
    return G.mk(18, 11, (p) => {
      p.r(4, 3, 10, 4, col); p.r(6, 3, 6, 2, patch);
      p.r(0, 1, 5, 4, col); p.r(0, 3, 2, 2, C.tan); p.p(0, 3, C.ink);
      p.p(3, 0, patch); p.p(4, 0, patch); p.p(2, 2, C.ink);
      p.r(1, 5, 1, 2, C.pink);
      p.r(14, 1 + (f ? 1 : 0), 1, 2, col); p.p(15, 1 + (f ? 0 : 1), col);
      const L = f ? [[4, -1], [6, 1], [11, -1], [13, 1]] : [[5, 1], [7, -1], [10, 1], [12, -1]];
      for (const [x, d] of L) { p.r(x, 7, 1, 2, col); p.p(x + d, 9, col); p.p(x + d, 10, C.ink); }
    });
  }
  S.dog = [dog(0, C.brown, C.ink), dog(1, C.brown, C.ink)];
  S.dog2 = [dog(0, C.tan, C.brown), dog(1, C.tan, C.brown)];
  S.dog3 = [dog(0, C.dark, C.greyD), dog(1, C.dark, C.greyD)];

  function moto(f) {
    // El Motosimio: casco naranja, camiseta sin mangas, moto roja. 30x24 mirando a la izquierda
    return G.mk(30, 24, (p) => {
      const wheel = (cx) => { p.circle(cx, 19, 4, C.ink); p.circle(cx, 19, 2, C.greyD); p.p(cx + (f ? 1 : -1), 19, C.greyL); };
      wheel(5); wheel(23);
      p.r(6, 13, 16, 4, C.red); p.r(9, 11, 9, 3, C.redD); p.r(4, 10, 3, 6, C.greyD); p.r(2, 9, 4, 2, C.grey);
      p.r(18, 12, 8, 2, C.dark); p.r(22, 15, 6, 2, C.grey);
      p.r(12, 16, 6, 3, C.greyD);
      // piloto
      p.r(13, 4, 6, 8, C.white); p.r(12, 11, 7, 3, C.blue); p.r(10, 13, 3, 5, C.blue); p.r(9, 18, 3, 2, C.grey);
      p.r(9, 6, 5, 2, C.skinM); p.r(6, 7, 3, 2, C.skinM);
      p.r(12, -1, 7, 6, C.orange); p.r(11, 2, 3, 3, C.skinM); p.r(11, 0, 4, 1, C.orangeD); p.p(12, 3, C.ink);
    });
  }
  S.moto = [moto(0), moto(1)];

  function bike(f) {
    return G.mk(26, 26, (p) => {
      const wheel = (cx) => { p.circle(cx, 21, 4, C.ink); p.circle(cx, 21, 2, C.greyD); p.p(cx, 21 + (f ? 1 : -1), C.greyL); };
      wheel(5); wheel(20);
      p.line(5, 21, 11, 14, C.green); p.line(11, 14, 20, 21, C.green); p.line(11, 14, 17, 14, C.green); p.line(17, 14, 20, 21, C.green);
      p.r(3, 11, 4, 1, C.ink);
      // ciclista con lycra
      p.r(12, 5, 6, 6, C.yellow); p.r(10, 6, 3, 2, C.yellow); p.r(7, 8, 3, 2, C.skin);
      p.r(14, 11, 4, 3, C.ink); p.line(15, 14, 11 + (f ? 2 : 0), 20, C.ink); p.line(17, 14, 14 - (f ? 2 : 0), 20, '#2a2a3a');
      p.r(8, 1, 6, 5, C.skin); p.r(8, 0, 7, 2, C.red); p.p(9, 3, C.ink); p.r(7, 2, 2, 1, C.ink);
    });
  }
  S.bike = [bike(0), bike(1)];

  function bird(f, body, wing, eye) {
    return G.mk(12, 9, (p) => {
      p.r(3, 4, 7, 3, body); p.r(1, 3, 3, 3, body); p.p(0, 4, C.orange); p.p(2, 3, eye); p.r(10, 4, 2, 2, wing);
      if (f) { p.r(4, 0, 4, 4, wing); p.r(5, 0, 2, 1, body); } else { p.r(4, 6, 4, 3, wing); }
    });
  }
  S.pigeon = [bird(0, C.grey, C.greyD, C.red), bird(1, C.grey, C.greyD, C.red)];
  S.crow = [bird(0, C.ink, C.dark, C.red), bird(1, C.ink, C.dark, C.red)];

  /* Vehículos reutilizados del juego de nivel1/juego (sprites2.js, ref. carpeta autos/):
     vocho, chevy, taxi, pickups y camiones de ruta 318 / 88 / 98 */
  const R = (g, x, y, w, h, c) => { g.fillStyle = c; g.fillRect(x, y, w, h); };
  const disc = (g, cx, cy, r, c) => { g.fillStyle = c; for (let y = -r; y <= r; y++) { const w = Math.floor(Math.sqrt(r * r - y * y) + 0.4); g.fillRect(cx - w, cy + y, w * 2 + 1, 1); } };
  function shade(hex, f) {
    const n = parseInt(hex.slice(1), 16);
    const c = (v) => Math.max(0, Math.min(255, Math.round(v * f)));
    return '#' + ((1 << 24) + (c(n >> 16) << 16) + (c(n >> 8 & 255) << 8) + c(n & 255)).toString(16).slice(1);
  }
  function vehicle(w, h, fn) { return G.mk(w, h, (p, g) => fn(g)); }
  function car(g, o) {
    const w = o.w, h = o.h, pr = o.prof, bot = h - 4;
    const top = (x) => { for (let i = 1; i < pr.length; i++) if (x <= pr[i][0]) { const a = pr[i - 1], b = pr[i]; return Math.round(a[1] + (b[1] - a[1]) * (x - a[0]) / Math.max(1, b[0] - a[0])); } return pr[pr.length - 1][1]; };
    for (let x = 0; x < w; x++) {
      const t = top(x);
      R(g, x, t, 1, bot - t, o.body);
      if (o.roof) { const rh = Math.max(0, o.roofY - t); if (rh) R(g, x, t, 1, rh, o.roof); }
      R(g, x, t, 1, 1, shade(o.roof && t < o.roofY ? o.roof : o.body, 1.25));
      if (o.low) R(g, x, bot - o.lowH, 1, o.lowH, o.low);
      R(g, x, bot - 1, 1, 1, shade(o.low || o.body, 0.6));
    }
    (o.win || []).forEach((q) => {
      for (let x = q[0]; x < q[1]; x++) { const t = Math.max(q[2], top(x) + 2); if (q[3] > t) R(g, x, t, 1, q[3] - t, '#22303f'); }
      R(g, q[0] + 1, q[2] + 1, Math.max(1, (q[1] - q[0]) >> 1), 1, '#6f9fc0');
    });
    if (o.extra) o.extra(g);
    (o.wheels || []).forEach((wx) => { disc(g, wx, h - o.wr - 1, o.wr + 1, shade(o.body, 0.45)); disc(g, wx, h - o.wr - 1, o.wr, '#15151c'); disc(g, wx, h - o.wr - 1, o.wr - 3, o.hub || '#b9b9c4'); });
    R(g, w - 2, bot - 8, 2, 3, '#f6e68a'); R(g, 0, bot - 8, 2, 3, '#d43a3a');
  }
  const vocho = vehicle(60, 28, (g) => car(g, { w: 60, h: 28, body: '#e8e0c8', prof: [[0, 18], [4, 15], [12, 13], [18, 6], [24, 3], [36, 3], [44, 7], [50, 13], [58, 15], [60, 19]], win: [[20, 30, 6, 13], [32, 43, 6, 13]], wheels: [12, 47], wr: 6, hub: '#f1f1f1' }));
  const chevy = vehicle(56, 28, (g) => car(g, { w: 56, h: 28, body: '#1fa39a', low: '#23232b', lowH: 4, prof: [[0, 14], [3, 11], [8, 6], [14, 3], [34, 3], [43, 11], [52, 13], [56, 17]], win: [[10, 22, 5, 11], [24, 40, 5, 11]], wheels: [11, 44], wr: 5 }));
  const taxi = vehicle(66, 26, (g) => car(g, { w: 66, h: 26, body: '#f1f1f1', roof: '#f29a2a', roofY: 10, low: '#22222a', lowH: 3, prof: [[0, 12], [6, 11], [14, 10], [20, 4], [40, 4], [48, 10], [60, 12], [66, 15]], win: [[21, 31, 6, 10], [33, 44, 6, 10]], wheels: [13, 52], wr: 5,
    extra: (g) => { for (let x = 2; x < 62; x += 4) { R(g, x, 13, 2, 2, '#f2c21c'); R(g, x + 2, 13, 2, 2, '#22222a'); } R(g, 27, 1, 8, 3, '#f2e23a'); disc(g, 30, 17, 2, '#2a3a9a'); } }));
  const pickup = (body, low) => vehicle(78, 30, (g) => car(g, { w: 78, h: 30, body, low, lowH: 5, prof: [[0, 13], [30, 13], [31, 5], [34, 3], [50, 3], [57, 12], [74, 13], [78, 17]], win: [[36, 54, 6, 12]], wheels: [14, 61], wr: 7, extra: (g) => { R(g, 0, 13, 31, 1, shade(body, 0.7)); R(g, 72, 16, 5, 4, '#c4c4cc'); } }));
  const ruta = (c1, c2, num, c3) => vehicle(112, 50, (g) => {
    R(g, 2, 4, 108, 38, c1); R(g, 4, 2, 104, 3, c1); R(g, 2, 28, 108, 14, c2); R(g, 2, 41, 108, 2, shade(c2, 0.6));
    R(g, 6, 9, 84, 14, '#22303f'); for (let x = 22; x < 88; x += 17) R(g, x, 9, 2, 14, c1);
    R(g, 7, 10, 6, 1, '#6f9fc0'); R(g, 92, 8, 16, 18, '#22303f'); R(g, 93, 9, 6, 1, '#6f9fc0');
    R(g, 74, 9, 12, 32, shade(c1, 0.8)); R(g, 76, 11, 3, 20, '#22303f'); R(g, 81, 11, 3, 20, '#22303f');
    R(g, 90, 3, 20, 5, '#15151c'); G.text(g, num, 100, 4, c3 || '#f2a21c', { align: 'center' });
    R(g, 108, 34, 3, 3, '#f6e68a'); R(g, 1, 34, 2, 3, '#d43a3a');
    [22, 88].forEach((wx) => { disc(g, wx, 42, 8, shade(c2, 0.5)); disc(g, wx, 42, 7, '#15151c'); disc(g, wx, 42, 3, '#b9b9c4'); });
  });
  S.patrol = vehicle(66, 26, (g) => car(g, { w: 66, h: 26, body: '#f4f4f4', low: '#1d3a8a', lowH: 5, prof: [[0, 12], [6, 11], [14, 10], [20, 4], [40, 4], [48, 10], [60, 12], [66, 15]], win: [[21, 31, 6, 10], [33, 44, 6, 10]], wheels: [13, 52], wr: 5,
    extra: (g) => { R(g, 25, 1, 7, 3, '#d8283a'); R(g, 32, 1, 7, 3, '#2a5ab0'); R(g, 2, 13, 62, 2, '#1d3a8a'); G.text(g, 'POLICIA', 33, 15, '#1d3a8a', { align: 'center' }); } }));
  S.patrolL = G.flip(S.patrol);
  S.cars = [vocho, chevy, taxi, pickup('#f1f1f1', '#7f9ccf'), pickup('#6e1f2a', '#4a1219')];
  S.CAR_IDX = { vocho: 0, chevy: 1, taxi: 2, pickup1: 3, pickup2: 4 };
  S.buses = [ruta('#f1f1f1', '#c42a2a', '318'), ruta('#2a7fd4', '#7a8494', '88', '#f2e23a'), ruta('#f1f1f1', '#6fc93a', '98', '#fff')];
  S.busesL = S.buses.map(G.flip);
  S.carsL = S.cars.map(G.flip);

  /* ---------------------------------------------------------------
     OBSTÁCULOS
     --------------------------------------------------------------- */
  S.rock = G.mk(13, 9, (p) => { p.r(2, 2, 9, 7, C.greyD); p.r(1, 4, 11, 5, C.greyD); p.r(3, 2, 5, 2, C.grey); p.r(4, 1, 4, 1, C.grey); p.p(9, 6, C.dark); p.r(1, 8, 11, 1, C.dark); });
  S.box = G.mk(13, 13, (p) => { p.r(0, 1, 13, 12, C.tan); p.r(0, 0, 13, 2, '#e8b87a'); p.r(6, 0, 1, 13, C.brown); p.r(0, 12, 13, 1, C.brown); p.r(2, 5, 3, 2, C.brownD); });
  S.trash = G.mk(11, 15, (p) => { p.r(1, 3, 9, 12, '#3e7a4a'); p.r(0, 1, 11, 3, '#2b5a35'); p.r(4, 0, 3, 1, C.dark); for (let i = 2; i < 10; i += 3) p.r(i, 5, 1, 9, '#2b5a35'); p.p(9, 0, C.tan); p.p(10, 2, C.white); });
  S.cone = G.mk(9, 13, (p) => { p.r(3, 0, 3, 3, C.orange); p.r(2, 3, 5, 2, C.white); p.r(2, 5, 5, 3, C.orange); p.r(1, 8, 7, 2, C.white); p.r(1, 10, 7, 1, C.orange); p.r(0, 11, 9, 2, C.orangeD); });
  S.barrier = G.mk(24, 15, (p) => { for (let x = 0; x < 22; x++) p.r(x + 1, 2, 1, 5, (((x >> 2) & 1) ? C.white : C.orange)); p.r(1, 1, 22, 1, C.orangeD); p.r(3, 7, 2, 8, C.greyD); p.r(19, 7, 2, 8, C.greyD); p.r(1, 13, 6, 2, C.dark); p.r(17, 13, 6, 2, C.dark); p.r(11, 0, 2, 2, C.yellow); });
  S.puddle = [0, 1].map(f => G.mk(26, 5, (p) => { p.r(2, 1, 22, 3, C.water); p.r(0, 2, 26, 2, C.water); p.r(5 + f * 6, 1, 5, 1, C.waterL); p.r(16 - f * 4, 2, 3, 1, C.waterL); p.r(1, 4, 24, 1, '#2a5f8f'); }));
  S.sack = G.mk(13, 9, (p) => { p.r(1, 2, 11, 7, '#cfc6b0'); p.r(0, 4, 13, 5, '#cfc6b0'); p.r(2, 1, 3, 2, '#b7ad95'); p.r(3, 4, 6, 2, C.greyD); p.r(0, 8, 13, 1, '#9a917b'); });
  S.bricks = G.mk(12, 8, (p) => { p.r(0, 0, 12, 8, '#b4502e'); p.r(0, 3, 12, 1, '#d8b08c'); p.r(0, 7, 12, 1, '#d8b08c'); p.r(5, 0, 1, 3, '#d8b08c'); p.r(2, 4, 1, 3, '#d8b08c'); p.r(9, 4, 1, 3, '#d8b08c'); });
  S.barrel = G.mk(11, 15, (p) => { p.r(1, 0, 9, 15, '#2c5d8a'); p.r(0, 2, 11, 2, '#1e4366'); p.r(0, 10, 11, 2, '#1e4366'); p.r(3, 5, 4, 3, C.yellow); p.p(5, 6, C.ink); p.r(2, 0, 2, 15, '#3e78ad'); });
  S.tire = [0, 1, 2].map(f => G.mk(13, 20, (p) => {
    p.circle(6, 14, 5, C.ink); p.circle(6, 14, 2, C.dark); p.p(6, 14, C.greyD);
    const fl = [[3, 6, 2, 4], [5, 3 + f, 3, 6], [8, 5 - f % 2, 2, 5], [6, 1 + f, 1, 2]];
    for (const [x, y, w, h] of fl) { p.r(x, y, w, h, C.orange); p.r(x, y + h - 2, w, 2, C.yellow); }
    p.p(4 + f, 2, C.red);
  }));
  S.cart = G.mk(22, 19, (p) => {
    p.r(1, 6, 20, 8, C.white); p.r(1, 6, 20, 2, C.yellow); p.r(3, 9, 16, 3, C.greyL);
    G.text(p.ctx, 'ELOTES', 3, 9, C.greyD);
    p.r(0, 0, 22, 2, C.red); p.r(2, 2, 1, 4, C.greyD); p.r(19, 2, 1, 4, C.greyD);
    p.circle(5, 16, 2, C.ink); p.circle(16, 16, 2, C.ink); p.r(0, 14, 22, 1, C.greyD);
    p.r(8, 3, 2, 3, C.yellow); p.r(12, 3, 2, 3, C.yellowD);
  });
  S.beam = G.mk(30, 6, (p) => { p.r(0, 0, 30, 6, '#c9a227'); p.r(0, 0, 30, 1, C.yellow); p.r(0, 5, 30, 1, C.orangeD); for (let x = 3; x < 30; x += 6) p.r(x, 2, 2, 2, C.orangeD); });
  S.stamp = G.mk(14, 14, (p) => { p.r(5, 0, 4, 6, C.brownD); p.r(4, 0, 6, 2, C.brown); p.r(1, 6, 12, 3, C.greyD); p.r(0, 9, 14, 5, C.red); G.text(p.ctx, 'NO', 3, 9, C.white); });
  S.paper = [0, 1].map(f => G.mk(12, 8, (p) => { p.r(0, f, 12, 7 - f, C.white); p.r(2, 2, 8, 1, C.greyD); p.r(2, 4, 6, 1, C.greyD); p.r(0, 7 - f, 12, 1, C.grey); p.r(8, 5, 3, 2, C.red); }));
  S.filebox = G.mk(14, 12, (p) => { p.r(0, 0, 14, 12, '#d9c79a'); p.r(0, 0, 14, 2, '#b8a676'); p.r(4, 4, 6, 3, C.white); G.text(p.ctx, 'A', 6, 4, C.ink); p.r(0, 11, 14, 1, C.brown); });

  /* ---------------------------------------------------------------
     CASA DEL PROTAGONISTA (estilo regio: azotea plana y tinaco)
     --------------------------------------------------------------- */
  function house(open) {
    return G.mk(92, 64, (p) => {
      p.r(70, 2, 12, 10, C.ink); p.r(69, 1, 14, 2, '#2a2a3a'); p.r(72, 4, 1, 7, '#333'); // tinaco
      p.r(0, 12, 90, 3, '#c96d3a'); p.r(2, 15, 86, 49, C.peach); p.r(2, 15, 86, 2, '#e08a4a');
      p.r(2, 60, 86, 4, '#c96d3a');
      // ventana con protección
      p.r(10, 26, 26, 18, '#2b3e5c'); p.r(12, 28, 10, 6, '#3d5a85');
      for (let x = 10; x < 37; x += 4) p.r(x, 26, 1, 18, C.ink); p.r(10, 34, 27, 1, C.ink); p.r(8, 44, 30, 2, '#e8e0d0');
      // puerta
      p.r(50, 30, 16, 30, '#7a3a1e');
      if (open) { p.r(51, 31, 14, 29, C.ink); p.r(51, 31, 3, 29, '#a0522d'); }
      else { p.r(52, 32, 12, 12, '#8f4a26'); p.r(52, 46, 12, 12, '#8f4a26'); p.p(62, 45, C.yellow); }
      p.r(48, 28, 20, 2, '#e8e0d0');
      // foco y número
      p.r(70, 30, 3, 3, C.yellow); G.text(p.ctx, '13', 72, 40, C.ink);
      // barda de celosía
      p.r(0, 52, 46, 12, '#efe0c8');
      for (let x = 2; x < 44; x += 5) for (let y = 54; y < 62; y += 4) { p.r(x, y, 3, 2, '#c96d3a'); }
      p.r(0, 51, 46, 1, '#c9b89a');
      // planta
      p.r(78, 50, 8, 10, C.greenD); p.r(80, 46, 4, 6, C.green); p.r(77, 58, 10, 6, C.brown);
    });
  }
  S.house = house(false); S.houseOpen = house(true);

  /* ---------------------------------------------------------------
     CAMIÓN OBJETIVO (basado en objetivo/objetivo.jfif):
     verde, panel trasero naranja, paneles solares en el techo
     --------------------------------------------------------------- */
  function bus(doorOpen, passenger) {
    return G.mk(140, 50, (p) => {
      p.r(30, 2, 34, 5, '#2a3f7a'); for (let x = 30; x < 64; x += 6) p.r(x, 2, 1, 5, C.greyL); p.r(30, 4, 34, 1, C.greyL);
      p.r(66, 3, 16, 4, C.orange); p.r(67, 4, 14, 1, C.orangeD);
      p.r(4, 7, 132, 3, '#d9dee6');
      p.r(3, 10, 134, 31, C.green); p.r(2, 12, 136, 27, C.green);
      p.r(2, 36, 136, 4, C.greenD);
      p.r(2, 25, 34, 11, C.orange); p.r(2, 34, 34, 2, C.orangeD);
      p.r(8, 27, 6, 6, C.white); p.r(9, 28, 2, 2, C.orange); p.r(12, 30, 1, 3, C.orange); // emblema
      // ventanas
      p.r(6, 12, 120, 12, '#1d2b4a');
      for (let x = 6; x < 126; x += 15) { p.r(x + 1, 13, 5, 2, '#3d5a85'); p.r(x + 14, 12, 1, 12, C.green); }
      // puertas
      const door = (x) => {
        if (doorOpen) { p.r(x, 12, 12, 26, C.ink); p.r(x, 12, 2, 26, '#2b3e5c'); p.r(x + 10, 12, 2, 26, '#2b3e5c'); p.r(x + 2, 36, 8, 2, C.greyD); }
        else { p.r(x, 12, 12, 26, '#2b3e5c'); p.r(x + 5, 12, 2, 26, C.dark); p.r(x + 1, 14, 3, 4, '#3d5a85'); p.r(x + 7, 14, 3, 4, '#3d5a85'); }
      };
      door(52); door(118);
      if (passenger) { const hx = 100, hy = 15; p.r(hx, hy, 6, 6, C.skin); p.p(hx + 4, hy + 2, C.ink); p.r(hx + 1, hy - 3, 4, 3, C.red); p.r(hx + 2, hy - 4, 1, 1, C.red); p.r(hx + 4, hy + 4, 2, 1, C.ink); }
      // parabrisas y frente
      p.r(131, 10, 7, 22, '#1d2b4a'); p.r(132, 11, 2, 8, '#3d5a85');
      p.r(136, 33, 3, 3, C.yellow); p.r(1, 32, 2, 3, C.red);
      G.text(p.ctx, 'MUEVO LEON', 70, 28, C.white);
      p.r(104, 8, 20, 2, C.ink); p.r(106, 8, 10, 2, C.orange);
      // llantas
      const wheel = (cx) => { p.circle(cx, 42, 6, C.ink); p.circle(cx, 42, 3, C.greyD); p.r(cx - 1, 41, 3, 3, C.grey); };
      p.r(14, 36, 24, 4, C.ink); p.r(94, 36, 24, 4, C.ink);
      wheel(26); wheel(106);
    });
  }
  S.bus = bus(false, false); S.busOpen = bus(true, false); S.busFull = bus(false, true);
  S.busIcon = G.mk(14, 8, (p) => { p.r(0, 1, 14, 5, C.green); p.r(0, 4, 4, 2, C.orange); p.r(1, 2, 11, 2, C.navy); p.r(12, 1, 2, 3, C.navy); p.r(2, 6, 3, 2, C.ink); p.r(9, 6, 3, 2, C.ink); });
  S.houseIcon = G.mk(10, 9, (p) => { p.r(1, 3, 8, 6, C.peach); p.r(0, 2, 10, 2, '#c96d3a'); p.r(4, 5, 2, 4, C.brownD); p.r(7, 0, 2, 2, C.ink); });
  S.heart = G.mk(7, 6, (p) => p.grid(['.##.##.', '#######', '#######', '.#####.', '..###..', '...#...'], { '#': C.red }));
  S.heartE = G.mk(7, 6, (p) => p.grid(['.##.##.', '#..#..#', '#.....#', '.#...#.', '..#.#..', '...#...'], { '#': C.greyD }));
  S.stop = G.mk(12, 34, (p) => { p.r(5, 8, 2, 26, C.greyD); p.r(0, 0, 12, 10, C.blue); p.r(1, 1, 10, 8, C.white); p.r(3, 3, 6, 3, C.green); p.r(3, 6, 2, 1, C.ink); p.r(7, 6, 2, 1, C.ink); });

  /* ---------------------------------------------------------------
     JEFE FINAL (personaje original): LIC. MIJESEX3
     burócrata gigante sobre una pila de trámites, con sello de "NO"
     --------------------------------------------------------------- */
  function boss(mode) {
    return G.mk(64, 80, (p) => {
      const suit = '#AF272F', suitD = '#7d1a20', suitL = '#c9454d'; // saco Pantone 1805 C
      // pila de papeles (plataforma)
      for (let i = 0; i < 6; i++) { const y = 58 + i * 3; p.r(4 + (i % 2) * 2, y, 54, 3, i % 2 ? C.white : '#e4e0d4'); p.r(4 + (i % 2) * 2, y + 2, 54, 1, C.grey); }
      p.r(10, 61, 10, 2, C.red); p.r(40, 67, 8, 2, C.yellow);
      // cuerpo
      p.r(12, 30, 40, 28, suit); p.r(12, 30, 4, 28, suitD); p.r(48, 30, 4, 28, suitD);
      p.r(26, 30, 12, 12, C.white); p.r(24, 30, 3, 14, suitL); p.r(37, 30, 3, 14, suitL);
      p.r(30, 31, 4, 3, '#AF272F'); p.r(29, 34, 6, 16, '#AF272F'); p.r(30, 50, 4, 2, '#7d1a20'); p.r(29, 34, 1, 16, '#7d1a20'); p.r(34, 34, 1, 16, '#7d1a20'); p.r(31, 36, 1, 12, '#c9454d'); // corbata Pantone 1805 C
      p.r(16, 46, 6, 2, suitL); // bolsillo
      p.p(18, 45, C.red);
      // brazo izquierdo
      p.r(6, 32, 7, 20, suit); p.r(6, 52, 7, 5, '#a8714a');
      // brazo derecho / sello
      if (mode === 'attack') {
        p.r(51, 10, 7, 22, suit); p.r(51, 6, 7, 5, '#a8714a');
        p.r(50, -2 + 4, 10, 4, C.brownD); p.r(46, 0, 18, 3, C.red);
      } else {
        p.r(51, 32, 7, 18, suit); p.r(51, 50, 7, 5, '#a8714a');
        p.r(54, 54, 4, 4, C.brownD); p.r(50, 58, 12, 4, C.red);
      }
      // cabeza
      p.r(18, 6, 28, 24, '#a8714a'); p.r(16, 10, 32, 16, '#a8714a'); p.r(18, 26, 28, 4, '#7a4a2c');
      p.r(14, 14, 3, 6, '#7a4a2c'); p.r(47, 14, 3, 6, '#7a4a2c');
      // copete enorme
      p.r(16, 0, 32, 8, '#8a8a92'); p.r(18, 0, 26, 3, '#a8a8b0'); p.r(36, 0, 14, 4, '#8a8a92'); p.r(22, 1, 10, 2, '#d0d0d8'); // pelo gris
      p.r(16, 8, 3, 8, '#8a8a92'); p.r(45, 8, 3, 8, '#8a8a92');
      // lentes redondos dorados
      const eye = (x) => { p.r(x, 12, 9, 7, C.yellowD); p.r(x + 1, 13, 7, 5, mode === 'hurt' ? C.white : '#cbe8ff'); };
      eye(20); eye(35); p.r(29, 14, 6, 1, C.yellowD);
      if (mode === 'hurt' || mode === 'dead') {
        for (const x of [22, 37]) { p.p(x + 1, 14, C.ink); p.p(x + 3, 14, C.ink); p.p(x + 2, 15, C.ink); p.p(x + 1, 16, C.ink); p.p(x + 3, 16, C.ink); }
      } else {
        p.r(23, 15, 3, 2, C.ink); p.r(38, 15, 3, 2, C.ink);
        p.line(19, 10, 28, 12, C.ink, 2); p.line(36, 12, 45, 10, C.ink, 2);
      }
      if (mode === 'hurt' || mode === 'dead') { p.r(28, 24, 8, 4, C.ink); p.r(29, 25, 6, 2, C.redD); }
      else { p.r(25, 24, 14, 3, C.white); p.r(25, 27, 14, 1, C.ink); for (let x = 27; x < 39; x += 3) p.p(x, 25, C.grey); }
      p.r(31, 18, 3, 3, '#7a4a2c');
      // bigote gris
      p.r(23, 21, 18, 3, '#9a9aa2'); p.r(20, 22, 4, 2, '#9a9aa2'); p.r(40, 22, 4, 2, '#9a9aa2'); p.p(19, 21, '#9a9aa2'); p.p(44, 21, '#9a9aa2'); p.r(25, 21, 14, 1, '#c0c0c8');
    });
  }
  S.boss = { idle: boss('idle'), attack: boss('attack'), hurt: boss('hurt'), dead: boss('dead') };
  S.bossWhite = G.tint(S.boss.hurt, '#ffffff');

  /* Elenco de personajes con apariencia */
  const P = G.PAL;
  G.LOOKS = {
    chuy:     { skin: P.skin, hair: 'bald', hairC: P.grey, shirt: P.white, sleeve: P.white, pants: '#6b6b4a', mustache: P.grey, belly: 1, extra: ['belly'] },
    cuca:     { skin: P.skinM, skinS: P.skinMS, hair: 'bun', hairC: '#3a2a20', shirt: P.pink, pants: '#6a3b7a', skirt: 1, extra: ['broom', 'apron'] },
    rigo:     { skin: P.skin, hair: 'short', hairC: '#c9c9c9', shirt: '#4a7a8c', pants: P.greyD, glasses: 1, extra: ['chair'] },
    tencha:   { skin: P.skinM, skinS: P.skinMS, hair: 'bun', hairC: P.white, shirt: '#8a5ab0', pants: '#4a3a6a', skirt: 1, short: 1, extra: ['cane'] },
    manguera: { skin: P.skinM, skinS: P.skinMS, hair: 'cap', hairC: P.blue, shirt: P.white, pants: P.blue, mustache: P.ink, extra: ['hose'] },
    elotero:  { skin: P.skinM, skinS: P.skinMS, hair: 'hat', hairC: P.tan, shirt: P.white, pants: P.blueD, mustache: P.ink, extra: ['apron'] },
    tsuru:    { skin: P.skin, hair: 'short', hairC: P.ink, shirt: P.red, pants: P.blueD },
    brayan:   { skin: P.skinM, skinS: P.skinMS, hair: 'cap', hairC: P.red, shirt: P.ink, pants: P.greyD, extra: ['phone'] },
    parada:   { skin: P.skin, hair: 'long', hairC: '#6a3b20', shirt: P.green, pants: P.navy, extra: ['briefcase'] },
    candidato:{ skin: P.skin, hair: 'pompa', hairC: P.ink, shirt: P.red, pants: P.navy, smile: 1, extra: ['thumb', 'logo'] },
    obrero:   { skin: P.skinM, skinS: P.skinMS, hair: 'helmet', hairC: P.yellow, shirt: P.blueD, pants: P.blue, mustache: P.ink, extra: ['vest'] },
    misterio: { skin: P.skinM, hair: 'hood', hairC: '#3a3a4a', shirt: '#3a3a4a', pants: P.ink },
    influ:    { skin: P.skin, hair: 'long', hairC: P.yellow, shirt: P.orange, pants: P.white, lips: 1, extra: ['selfie'] },
    tarjetas: { skin: P.skin, hair: 'pompa', hairC: '#3a2a20', shirt: P.white, shirt2: P.blue, pants: P.ink, smile: 1, extra: ['cards', 'suit'] },
    maton:    { skin: P.skinM, skinS: P.skinMS, hair: 'hat', hairC: P.ink, shirt: '#AF272F', pants: '#7d1a20', glasses: 1, extra: ['chain'] },
    maton2:   { skin: P.skin, hair: 'bald', hairC: P.ink, shirt: '#AF272F', pants: '#7d1a20', glasses: 1, beard: P.ink, extra: ['chain'] },
    achi:     { skin: P.skin, hair: 'short', hairC: P.ink, shirt: '#AF272F', pants: '#7d1a20', glasses: 1, extra: ['clipboard', 'suit'] },
    peaton:   { skin: P.skinM, skinS: P.skinMS, hair: 'short', hairC: P.ink, shirt: P.yellow, pants: P.blue },
    peaton2:  { skin: P.skin, hair: 'pony', hairC: '#a0522d', shirt: P.purple, pants: P.ink },
    peaton3:  { skin: P.skinD, skinS: '#6a4028', hair: 'short', hairC: P.ink, shirt: P.green, pants: P.tan }
  };
  /* ---------- Nivel 2: gente de la carretera ---------- */
  Object.assign(G.LOOKS, {
    poli:       { skin: P.skinM, skinS: P.skinMS, hair: 'cap', hairC: '#1d2b53', shirt: '#1d2b53', pants: '#1d2b53', glasses: 1, extra: ['badge'] },
    poliMin:    { skin: P.skin, hair: 'cap', hairC: '#1d2b53', shirt: '#2a3f7a', pants: '#1d2b53', glasses: 1, mustache: P.ink, extra: ['badge'] },
    transito:   { skin: P.skinM, skinS: P.skinMS, hair: 'cap', hairC: P.white, shirt: P.white, pants: '#1d2b53', mustache: P.ink, extra: ['vest', 'badge'] },
    vagabundo:  { skin: P.skinD, skinS: '#6a4028', hair: 'long', hairC: P.grey, beard: P.grey, shirt: '#6a5a3a', pants: '#4a4030', shoes: '#3a3020', extra: ['bag'] },
    vagabundo2: { skin: P.skinM, skinS: P.skinMS, hair: 'hat', hairC: '#6a4a2a', beard: P.ink, shirt: '#5a6a4a', pants: '#3a3a3a', extra: ['bag'] },
    mujer1:     { skin: P.skin, hair: 'long', hairC: '#6a3b20', shirt: P.pink, pants: '#2a2a4a', skirt: 1, lips: 1 },
    mujer2:     { skin: P.skinM, skinS: P.skinMS, hair: 'pony', hairC: P.ink, shirt: '#3fa54a', pants: P.blue, lips: 1 },
    mujer3:     { skin: P.skin, hair: 'long', hairC: P.yellow, shirt: P.purple, pants: '#1a1a2a', skirt: 1, lips: 1 },
    mujer4:     { skin: P.skinD, skinS: '#6a4028', hair: 'bun', hairC: P.ink, shirt: P.red, pants: P.ink, lips: 1, extra: ['briefcase'] },
    aficionado: { skin: P.skinM, skinS: P.skinMS, hair: 'short', hairC: P.ink, shirt: P.yellow, shirt2: P.blue, pants: P.blue, smile: 1 },
    estudiante: { skin: P.skin, hair: 'short', hairC: '#3a2a20', shirt: P.white, pants: '#1d2b53', extra: ['briefcase'] }
  });
  G.PEOPLE = {};
  for (const k in G.LOOKS) G.PEOPLE[k] = G.makePerson(G.LOOKS[k]);

  /* ---------- Nivel 2: el camioncito que maneja nuestro punk ---------- */
  S.busDuck = G.mk(140, 30, (p, ctx) => { ctx.drawImage(S.busFull, 0, 0, 140, 50, 0, 0, 140, 30); });
  S.flagIcon = G.mk(10, 9, (p) => { p.r(0, 0, 1, 9, C.greyL); for (let y = 0; y < 5; y++) for (let x = 1; x < 9; x++) p.p(x, y, (x + y) % 2 ? C.ink : C.white); });

  /* Proyectiles verde fosforescente del jefe del nivel 2 */
  const NEON = '#39ff14', NEON_D = '#1fbf0a', NEON_L = '#c8ffb0';
  G.PAL.neon = NEON;
  S.goo = [0, 1].map(f => G.mk(14, 10, (p) => { p.r(1, 3 + f, 12, 7 - f, NEON_D); p.r(0, 5, 14, 5, NEON_D); p.r(2, 2 + f, 9, 3, NEON); p.r(3, 3 + f, 3, 1, NEON_L); p.p(11, 8, NEON); p.p(2, 9, NEON); }));
  S.gooAir = [0, 1].map(f => G.mk(14, 9, (p) => { p.circle(9, 4, 4, NEON_D); p.circle(9, 4, 3, NEON); p.r(8, 2, 2, 1, NEON_L); p.r(1 + f, 3, 3, 1, NEON); p.r(0, 5 - f, 3, 1, NEON_D); }));
  S.gooDrop = G.mk(12, 12, (p) => { p.circle(6, 7, 5, NEON_D); p.circle(6, 6, 4, NEON); p.r(5, 0, 2, 3, NEON); p.r(4, 4, 2, 1, NEON_L); });

  /* ---------------------------------------------------------------
     JEFE DEL NIVEL 2 (personaje original): CHAVACARAT
     dos cabezas de rata en un solo traje, sobre un charco fosforescente
     --------------------------------------------------------------- */
  function rat(mode) {
    return G.mk(64, 80, (p) => {
      const suit = '#2a3f7a', suitD = '#1b2a55', suitL = '#3d5a9e';
      // charco verde
      p.r(4, 64, 56, 14, NEON_D); p.r(8, 61, 48, 4, NEON_D); p.r(2, 70, 60, 8, NEON_D);
      p.r(10, 62, 20, 2, NEON); p.r(36, 66, 14, 2, NEON); p.r(6, 74, 8, 2, NEON_L); p.r(48, 72, 6, 2, NEON);
      // cuerpo
      p.r(12, 34, 40, 28, suit); p.r(12, 34, 4, 28, suitD); p.r(48, 34, 4, 28, suitD);
      p.r(26, 34, 12, 10, C.white); p.r(24, 34, 3, 12, suitL); p.r(37, 34, 3, 12, suitL);
      p.r(30, 35, 4, 3, C.orange); p.r(29, 38, 6, 16, C.orange); p.r(30, 54, 4, 2, C.orangeD);
      p.r(42, 46, 6, 2, C.white);
      // cola de rata
      p.line(12, 58, 4, 52, '#d89aa8', 2); p.line(4, 52, 2, 44, '#d89aa8', 1);
      // brazos
      p.r(6, 36, 7, 20, suit); p.r(6, 56, 7, 4, C.skin);
      if (mode === 'attack') { p.r(51, 14, 7, 22, suit); p.r(51, 10, 7, 5, C.skin); p.circle(55, 6, 5, NEON_D); p.circle(55, 6, 4, NEON); p.r(53, 3, 2, 2, NEON_L); }
      else { p.r(51, 36, 7, 18, suit); p.r(51, 54, 7, 4, C.skin); }
      // cabezas
      const head = (cx, blonde) => {
        const x = cx - 8, y = 14;
        // oreja de rata (lado exterior)
        const ex = blonde ? cx + 9 : cx - 9;
        p.circle(ex, 12, 4, '#9a9aa8'); p.circle(ex, 12, 2, '#e89ab0');
        if (blonde) { p.r(x - 1, y - 3, 18, 6, '#e8c050'); p.r(x + 13, y, 5, 26, '#e8c050'); p.r(x + 14, y + 2, 2, 22, '#f8e080'); p.r(x - 1, y, 3, 10, '#e8c050'); }
        p.r(x, y, 16, 18, C.skin); p.r(x + 1, y + 18, 14, 2, C.skinS);
        if (!blonde) { p.r(x - 1, y - 4, 18, 6, '#1b1b24'); p.r(x + 2, y - 5, 12, 2, '#2b2b3a'); p.r(x + 4, y - 4, 6, 1, '#4a4a5e'); p.r(x - 1, y, 2, 6, '#1b1b24'); }
        else { p.r(x + 1, y - 1, 14, 3, '#e8c050'); p.r(x + 3, y - 2, 8, 1, '#f8e080'); }
        // ojos
        if (mode === 'hurt' || mode === 'dead') { for (const ox of [4, 10]) { p.p(x + ox, y + 6, C.ink); p.p(x + ox + 2, y + 6, C.ink); p.p(x + ox + 1, y + 7, C.ink); p.p(x + ox, y + 8, C.ink); p.p(x + ox + 2, y + 8, C.ink); } }
        else { p.r(x + 4, y + 6, 2, 3, C.ink); p.r(x + 10, y + 6, 2, 3, C.ink); p.p(x + 4, y + 6, C.white); p.p(x + 10, y + 6, C.white); p.line(x + 3, y + 4, x + 6, y + 5, C.ink); p.line(x + 9, y + 5, x + 12, y + 4, C.ink); }
        if (blonde) { p.r(x + 3, y + 5, 3, 1, '#c09030'); p.r(x + 10, y + 5, 3, 1, '#c09030'); }
        // nariz, dientes y bigotes de rata
        p.r(x + 7, y + 10, 2, 2, '#e8708a');
        p.line(x + 6, y + 11, x - 1, y + 10, C.grey); p.line(x + 6, y + 12, x - 1, y + 13, C.grey);
        p.line(x + 9, y + 11, x + 16, y + 10, C.grey); p.line(x + 9, y + 12, x + 16, y + 13, C.grey);
        if (mode === 'hurt' || mode === 'dead') { p.r(x + 6, y + 13, 4, 3, C.ink); }
        else { p.r(x + 5, y + 13, 6, 1, C.ink); p.r(x + 7, y + 14, 2, 3, C.white); p.p(x + 7, y + 16, C.grey); }
        if (blonde) p.r(x + 6, y + 13, 4, 1, C.red);
      };
      head(22, false); head(42, true);
    });
  }
  S.rat = { idle: rat('idle'), attack: rat('attack'), hurt: rat('hurt'), dead: rat('dead') };
  S.ratWhite = G.tint(S.rat.hurt, '#ffffff');
})();
