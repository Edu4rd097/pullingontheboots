/* =========================================================
   Escenarios con parallax: cielo, lejano, intermedio, calle, suelo.
   Cada capa se genera por "chunks" con semilla y se cachea.
   ========================================================= */
(function () {
  const G = window.G, C = G.PAL, CFG = G.CFG;
  const CW = 128;
  const MID_BASE = 132, ROAD_TOP = 132, GROUND_TOP = 148;
  G.WORLD_Y = { MID_BASE, ROAD_TOP, GROUND_TOP };

  const ZV = [
    { sky: ['#5ab4ec', '#bfe6ff'], far: ['#7f9cc4', '#9fb8d8'], farType: 'cerro', mid: 'barrio', road: 'calle', ground: 'banqueta', sun: '#fff6c0', clouds: '#ffffff' },
    { sky: ['#6fb8e8', '#efe2c0'], far: ['#8b98b8', '#a9b3cc'], farType: 'skyline', mid: 'ciudad', road: 'avenida', ground: 'banqueta2', sun: '#fff2a0', clouds: '#f4f4f4' },
    { sky: ['#e98b4a', '#fde3b0'], far: ['#a8714a', '#c58e5f'], farType: 'lomas', mid: 'obra', road: 'rio', ground: 'tierra', sun: '#ffe08a', clouds: '#ffd9b0' },
    { stars: true, fog: true, sky: ['#2a1d3f', '#7a4a6e'], far: ['#1e1530', '#33244a'], farType: 'picos', mid: 'ruinas', road: 'baldio', ground: 'grietas', sun: null, moon: '#e8d8b0', clouds: '#4a3a5e' },
    { stars: true, fog: true, sky: ['#12091c', '#5a1a2a'], far: ['#0e0814', '#2a0f1a'], farType: 'picos', mid: 'oficina', road: 'baldio2', ground: 'piedra', sun: null, moon: '#ff6040', clouds: '#2a1a2a' },
    { sky: ['#4fa6e0', '#fff0c0'], far: ['#c9a27a', '#e0bf94'], farType: 'lomas', mid: 'desierto', road: 'terraceria', ground: 'grava', sun: '#fffbe0', clouds: '#ffffff', rays: true },
    // ---- Nivel 2: la carretera ----
    { sky: ['#5ab4ec', '#cfe8ff'], far: ['#7f9cc4', '#9fb8d8'], farType: 'cerro', mid: 'l2_escomiedo', road: 'carretera', ground: 'asfalto', sun: '#fff6c0', clouds: '#ffffff' },
    { sky: ['#6fb8e8', '#f0e6c0'], far: ['#8a9ab8', '#a8b4cc'], farType: 'lomas', mid: 'l2_sanico', road: 'carretera', ground: 'asfalto', sun: '#fff2a0', clouds: '#f4f4f4' },
    { sky: ['#5aa8e0', '#e8e0c8'], far: ['#7a88a8', '#98a4c0'], farType: 'skyline', mid: 'l2_mty', road: 'carretera', ground: 'asfalto', sun: '#fff2a0', clouds: '#f4f4f4' },
    { stars: true, sky: ['#140c2a', '#4a2a5a'], far: ['#1a1430', '#2a2040'], farType: 'skyline', mid: 'l2_mtyn', road: 'carreteraN', ground: 'asfaltoN', sun: null, moon: '#e8d8b0', clouds: '#3a2a4e' },
    { stars: true, fog: true, sky: ['#0c0814', '#3a1c10'], far: ['#08060a', '#1c1010'], farType: 'picos', mid: 'l2_chavaca', road: 'carreteraN', ground: 'asfaltoN', sun: null, moon: '#f08a24', clouds: '#2a1810' },
    { sky: ['#4fa6e0', '#fff0c0'], far: ['#c9a27a', '#e0bf94'], farType: 'lomas', mid: 'desierto', road: 'carretera', ground: 'asfalto', sun: '#fffbe0', clouds: '#ffffff', rays: true }
  ];
  G.ZV = ZV;

  const cache = new Map();
  function getChunk(z, layer, i, drawFn, h) {
    const key = z + ':' + layer + ':' + i;
    let c = cache.get(key);
    if (!c) {
      c = G.mk(CW, h || CFG.H, (p, ctx) => drawFn(p, ctx, G.rng(z * 100003 + layer.length * 7919 + i * 131 + 17), i));
      cache.set(key, c);
      if (cache.size > 140) cache.delete(cache.keys().next().value);
    } else { cache.delete(key); cache.set(key, c); }
    return c;
  }
  function drawLayer(ctx, z, layer, off, fn) {
    const start = Math.floor(off / CW);
    for (let i = start; i * CW - off < CFG.W; i++) {
      ctx.drawImage(getChunk(z, layer, i, fn), Math.round(i * CW - off), 0);
    }
  }

  /* ---------------- CIELO ---------------- */
  const skyCache = {};
  G.clearSkyCache = () => { for (const k in skyCache) delete skyCache[k]; };
  function sky(z) {
    if (skyCache[z]) return skyCache[z];
    const v = ZV[z];
    return (skyCache[z] = G.mk(CFG.W, MID_BASE, (p) => {
      const n = 12;
      for (let i = 0; i < n; i++) {
        const t = i / (n - 1);
        p.r(0, Math.floor(i * MID_BASE / n), CFG.W, Math.ceil(MID_BASE / n) + 1, mixHex(v.sky[0], v.sky[1], t));
      }
      if (v.rays) {
        p.ctx.globalAlpha = 0.18;
        for (let a = -1.3; a < 1.4; a += 0.32) p.line(CFG.W - 90, 60, CFG.W - 90 + Math.sin(a) * 160, 60 - Math.cos(a) * 160, '#ffffff', 3);
        p.ctx.globalAlpha = 1;
      }
      if (v.sun) { p.circle(CFG.W - 90, 60, 16, v.sun); p.circle(CFG.W - 90, 60, 12, '#ffffff'); }
      if (v.moon) { p.circle(250, 36, 9, v.moon); p.circle(254, 33, 8, v.sky[0]); }
      if (v.stars) { const r = G.rng(z * 77); for (let i = 0; i < 40; i++) p.p(r() * CFG.W, r() * 80, r() > 0.5 ? '#ffffff' : '#c0b0ff'); }
    }));
  }
  function mixHex(a, b, t) {
    const pa = parseInt(a.slice(1), 16), pb = parseInt(b.slice(1), 16);
    const r = Math.round(((pa >> 16) & 255) * (1 - t) + ((pb >> 16) & 255) * t);
    const g = Math.round(((pa >> 8) & 255) * (1 - t) + ((pb >> 8) & 255) * t);
    const bl = Math.round((pa & 255) * (1 - t) + (pb & 255) * t);
    return '#' + ((1 << 24) | (r << 16) | (g << 8) | bl).toString(16).slice(1);
  }
  G.mixHex = mixHex;

  function clouds(p, ctx, r, i, z) {
    const v = ZV[z];
    const n = 1 + Math.floor(r() * 2);
    for (let k = 0; k < n; k++) {
      const x = 10 + r() * 90, y = 10 + r() * 50, w = 18 + r() * 24;
      p.r(x, y, w, 5, v.clouds); p.r(x + 4, y - 3, w - 10, 4, v.clouds); p.r(x + 8, y - 6, w * 0.4, 3, v.clouds);
      p.r(x + 2, y + 5, w - 4, 1, v.stars ? '#1a1024' : '#d6e6f2');
    }
  }

  /* ---------------- LEJANO ---------------- */
  function farH(type, x, seed) {
    switch (type) {
      case 'cerro': { // montaña con silla
        const u = ((x % 900) + 900) % 900;
        const base = 18 + Math.sin(x * 0.011 + seed) * 6 + Math.sin(x * 0.031) * 3;
        const peak = Math.max(0, 52 - Math.abs(u - 420) * 0.35) + Math.max(0, 46 - Math.abs(u - 520) * 0.4) - Math.max(0, 12 - Math.abs(u - 470) * 0.3);
        return base + Math.max(0, peak);
      }
      case 'lomas': return 22 + Math.sin(x * 0.012 + seed) * 10 + Math.sin(x * 0.05) * 3;
      case 'picos': return 40 + Math.abs(Math.sin(x * 0.02 + seed)) * 30 + ((Math.floor(x / 3) * 7919) % 5);
      default: return 20;
    }
  }
  function farLayer(z) {
    const v = ZV[z];
    return (p, ctx, r, i) => {
      if (v.farType === 'skyline') {
        for (let x = 0; x < CW;) {
          const w = 8 + Math.floor(r() * 14), h = 20 + Math.floor(r() * 45);
          p.r(x, MID_BASE - h, w, h, v.far[r() > 0.5 ? 0 : 1]);
          for (let y = MID_BASE - h + 3; y < MID_BASE - 4; y += 4) for (let xx = x + 2; xx < x + w - 2; xx += 3) if (r() > 0.4) p.p(xx, y, '#c8d0e0');
          if (r() > 0.7) p.r(x + w / 2, MID_BASE - h - 6, 1, 6, v.far[0]);
          x += w + (r() > 0.6 ? 2 : 0);
        }
        return;
      }
      for (let x = 0; x < CW; x++) {
        const wx = i * CW + x;
        const h = farH(v.farType, wx, z);
        p.r(x, MID_BASE - h, 1, h, v.far[0]);
        const h2 = h * 0.55 + Math.sin(wx * 0.04 + z) * 4;
        p.r(x, MID_BASE - h2, 1, h2, v.far[1]);
        if (v.farType === 'picos' && z === 4) p.p(x, MID_BASE - h, '#7a1a1a');
        if (v.farType === 'picos' && z === 10) p.p(x, MID_BASE - h, '#f08a24');
      }
      if (v.farType === 'lomas' && (z === 5 || z === 11)) {
        // yucas lejanas
        for (let k = 0; k < 2; k++) { const x = r() * CW, y = MID_BASE - 14 - r() * 10; p.r(x, y, 1, 8, '#7a6a4a'); p.r(x - 2, y - 2, 5, 3, '#6a8a4a'); }
      }
    };
  }

  /* ---------------- INTERMEDIO ---------------- */
  const HOUSE_COLS = ['#f2a65e', '#f3e2bd', '#e98b8b', '#9fd3a8', '#f0d070', '#d9a066', '#b8c8e8', '#f4b8a0'];
  function poles(p, i, color = '#5a4a3a', top = 60, sag = 10, base = MID_BASE) {
    p.r(4, top, 2, base - top, color); p.r(0, top + 3, 10, 1, color); p.r(1, top + 1, 2, 2, '#444');
    for (let x = 0; x < CW; x++) {
      const u = (x - 5) / CW;
      const uu = u < 0 ? u + 1 : u;
      const y = top + 3 + sag * (1 - Math.pow(2 * uu - 1, 2));
      p.p(x, y, '#2a2a2a'); p.p(x, y + 3, '#2a2a2a');
    }
  }
  function tree(p, x, base, r, dead) {
    const h = 14 + Math.floor(r() * 10);
    p.r(x, base - h, 3, h, dead ? '#3a2a2a' : C.brownD);
    if (dead) { p.line(x + 1, base - h, x - 5, base - h - 7, '#3a2a2a'); p.line(x + 2, base - h + 4, x + 8, base - h - 4, '#3a2a2a'); p.line(x + 1, base - h - 2, x + 2, base - h - 10, '#3a2a2a'); return; }
    p.circle(x + 1, base - h - 3, 7, '#2f8a3a'); p.circle(x - 3, base - h + 1, 5, '#2f8a3a'); p.circle(x + 5, base - h, 5, '#3fa54a');
    p.p(x + 3, base - h - 6, '#7ee06b'); p.p(x - 2, base - h - 2, '#7ee06b');
  }
  function midLayer(z) {
    const v = ZV[z];
    return (p, ctx, r, i) => {
      const B = MID_BASE;
      if (v.mid === 'barrio') {
        p.r(0, B - 4, CW, 4, '#bdb6a8');
        let x = 0;
        if (z === 0 && i === 9) { // taquería del barrio
          const w = 70, h = 38, y0 = B - 4 - h;
          p.r(0, y0, w, h, '#f3e2bd'); p.r(0, y0 - 2, w, 2, '#e8e0d0'); p.r(0, y0, w, 2, '#a06040');
          p.r(3, y0 + 3, w - 6, 10, C.red); p.r(3, y0 + 12, w - 6, 1, C.redD);
          G.text(ctx, 'TAKOS EL FLAKO', w / 2, y0 + 6, C.yellow, { align: 'center' });
          for (let k = 3; k < w - 3; k += 4) p.r(k, y0 + 14, 2, 3, k % 8 ? C.white : C.green);
          p.r(6, y0 + 18, 26, h - 18, '#2b3e5c'); p.r(7, y0 + 19, 8, 6, '#5a7aa5');
          p.r(40, B - 16, 24, 2, C.greyD); p.r(42, B - 14, 2, 10, C.greyD); p.r(60, B - 14, 2, 10, C.greyD); // trompo / mesa
          p.r(48, B - 24, 6, 8, C.orange); p.r(49, B - 26, 4, 2, C.yellow); p.r(50, B - 16, 2, 1, C.ink);
          x = w + 2;
        }
        if (z === 0 && i === 5) { // la vulcanizadora del barrio
          const w = 74, h = 40, y0 = B - 4 - h;
          p.r(0, y0, w, h, '#e8d8a8'); p.r(0, y0 - 2, w, 2, '#e8e0d0'); p.r(0, y0, w, 2, '#a06040');
          p.r(3, y0 + 3, w - 6, 10, C.yellow); p.r(3, y0 + 12, w - 6, 1, C.yellowD);
          G.text(ctx, 'VULKA LOS CUATES', w / 2, y0 + 6, C.ink, { align: 'center' });
          p.r(8, y0 + 17, 32, h - 17, '#2a2a30'); p.r(9, y0 + 18, 30, 2, '#55555c');
          for (let k = 0; k < 3; k++) { p.circle(50, B - 8 - k * 7, 4, C.ink); p.circle(50, B - 8 - k * 7, 1, C.greyD); }
          p.circle(62, B - 8, 4, C.ink); p.circle(62, B - 8, 1, C.greyD);
          G.text(ctx, '24 H', 46, y0 + 16, C.redD);
          x = w + 2;
        }
        while (x < CW - 6) {
          const w = Math.min(CW - x, 26 + Math.floor(r() * 22));
          if (w < 18 || r() < 0.18) { tree(p, x + 6, B - 4, r); x += 14; continue; }
          const h = 28 + Math.floor(r() * 22);
          const col = HOUSE_COLS[Math.floor(r() * HOUSE_COLS.length)];
          p.r(x, B - 4 - h, w, h, col); p.r(x, B - 4 - h, w, 2, '#a06040');
          p.r(x, B - 4 - h - 2, w, 2, '#e8e0d0');
          if (r() > 0.4) { p.r(x + w - 9, B - 4 - h - 9, 7, 7, C.ink); }
          const wy = B - 4 - h + 8;
          p.r(x + 3, wy, 9, 8, '#2b3e5c'); for (let k = x + 3; k < x + 12; k += 3) p.r(k, wy, 1, 8, C.ink);
          if (w > 30) p.r(x + 16, wy, 7, 6, '#2b3e5c');
          p.r(x + w - 10, B - 4 - 14, 7, 14, '#7a3a1e');
          if (h > 40) { p.r(x + 3, wy - 12, 9, 7, '#2b3e5c'); p.r(x + 1, wy - 4, w - 2, 1, '#e8e0d0'); }
          if (r() > 0.5) { p.r(x, B - 12, w - 12, 8, '#efe0c8'); for (let k = x + 1; k < x + w - 13; k += 4) p.r(k, B - 10, 2, 2, '#c96d3a'); }
          if (r() > 0.75) { p.r(x + 4, B - 4 - h + 2, 10, 4, '#2a6ab0'); }
          x += w + 1;
        }
        poles(p, i);
      } else if (v.mid === 'ciudad') {
        p.r(0, B - 4, CW, 4, '#a8a8a8');
        const signs = ['TACOS', 'OXXO', 'BENAVIDES', 'TORTILLAS', 'VULKA', 'ABARROTES', '7EVEN', 'CARNES', 'PAPELERIA', 'CELULARES', 'GORDITAS', 'OXXO'];
        let x = 0;
        while (x < CW - 8) {
          const w = Math.min(CW - x, 34 + Math.floor(r() * 24));
          if (w < 24) { x += w; continue; }
          const h = 40 + Math.floor(r() * 40);
          const col = ['#c8b8a0', '#d8d0c0', '#a8b8c8', '#e0c090', '#c09080', '#b0c0a0'][Math.floor(r() * 6)];
          p.r(x, B - 4 - h, w, h, col);
          for (let y = B - 4 - h + 4; y < B - 26; y += 8) for (let xx = x + 3; xx < x + w - 4; xx += 7) p.r(xx, y, 4, 5, r() > 0.3 ? '#3d5a85' : '#f0e080');
          const aw = ['#d8283a', '#2fae4a', '#4b7bd1', '#f08a24', '#fbe043'][Math.floor(r() * 5)];
          p.r(x + 1, B - 24, w - 2, 4, aw); for (let k = x + 1; k < x + w - 1; k += 4) p.r(k, B - 20, 2, 2, aw);
          p.r(x + 3, B - 18, w - 6, 14, '#2b3e5c'); p.r(x + 4, B - 17, 4, 12, '#5a7aa5');
          const fit = signs.filter(t => G.textWidth(t) + 6 <= w);
          const s = fit[Math.floor(r() * fit.length)] || 'TACOS';
          const sw = G.textWidth(s) + 4;
          p.r(x + (w - sw) / 2, B - 32, sw, 8, C.white); p.r(x + (w - sw) / 2, B - 25, sw, 1, '#888');
          G.text(ctx, s, x + (w - sw) / 2 + 2, B - 30, C.redD);
          x += w + 2;
        }
        if (i % 3 === 0) { p.r(100, B - 40, 2, 36, '#333'); p.r(97, B - 46, 8, 16, C.ink); p.circle(101, B - 43, 1, C.red); p.circle(101, B - 38, 1, '#553300'); p.circle(101, B - 33, 1, '#004400'); }
        if (i % 4 === 2) { p.r(0, B - 26, 0, 0); p.r(20, B - 26, 40, 2, C.greenD); p.r(22, B - 24, 1, 20, C.grey); p.r(57, B - 24, 1, 20, C.grey); p.r(28, B - 12, 24, 2, C.brown); p.r(24, B - 30, 32, 5, C.white); G.text(ctx, 'PARADA', 28, B - 30, C.greenD); }
        poles(p, i, '#4a4a4a', 46, 8);
      } else if (v.mid === 'obra') {
        let x = 0;
        while (x < CW - 6) {
          const k = r();
          if (k < 0.35) { // obra negra
            const w = 30 + Math.floor(r() * 20), h = 30 + Math.floor(r() * 30);
            p.r(x, B - h, w, h, '#a89c8c'); p.r(x, B - h, w, 3, '#8a7e70');
            for (let y = B - h + 6; y < B - 4; y += 10) for (let xx = x + 3; xx < x + w - 5; xx += 9) p.r(xx, y, 6, 6, '#3a3430');
            for (let xx = x + 2; xx < x + w; xx += 6) p.r(xx, B - h - 6, 1, 6, '#6a4a3a');
            x += w + 4;
          } else if (k < 0.55) { // grúa
            p.r(x + 6, B - 90, 3, 90, C.yellowD); for (let y = B - 90; y < B; y += 6) p.line(x + 6, y, x + 8, y + 5, C.yellow);
            p.r(x - 10, B - 92, 50, 3, C.yellowD); p.r(x + 34, B - 89, 1, 20 + Math.floor(r() * 20), '#333');
            x += 30;
          } else if (k < 0.8) { // barda de lámina
            const w = 36;
            for (let xx = x; xx < x + w; xx += 3) p.r(xx, B - 18, 3, 18, (xx / 3) % 2 ? '#8a8f96' : '#a9aeb5');
            p.r(x, B - 18, w, 1, '#6a6f76'); if (r() > 0.5) G.text(ctx, 'NO TIRAR', x + 2, B - 12, C.redD);
            x += w + 2;
          } else { tree(p, x + 5, B, r); x += 14; }
        }
      } else if (v.mid === 'ruinas' || v.mid === 'oficina') {
        let x = 0;
        while (x < CW - 6) {
          const k = r();
          if (v.mid === 'oficina' && k < 0.35) {
            p.r(x, B - 70, 10, 70, '#3a2a3a'); p.r(x - 2, B - 72, 14, 4, '#4a3a4a'); p.r(x - 2, B - 4, 14, 4, '#4a3a4a');
            p.r(x + 2, B - 66, 2, 60, '#2a1a2a'); x += 26;
          } else if (k < 0.5) {
            const w = 34 + Math.floor(r() * 20), h = 40 + Math.floor(r() * 36);
            p.r(x, B - h, w, h, '#2e2438');
            for (let xx = x; xx < x + w; xx += 4) p.r(xx, B - h - Math.floor(r() * 5), 4, 5, '#2e2438');
            for (let y = B - h + 8; y < B - 8; y += 10) for (let xx = x + 4; xx < x + w - 6; xx += 9) p.r(xx, y, 5, 6, r() > 0.85 ? '#c89040' : '#120c18');
            x += w + 3;
          } else if (k < 0.8) { tree(p, x + 6, B, r, true); x += 18; }
          else { p.r(x + 3, B - 50, 2, 50, '#3a2a2a'); p.line(x, B - 46, x + 10, B - 44, '#3a2a2a'); x += 20; }
        }
        if (v.mid === 'oficina' && i % 5 === 1) { p.r(30, B - 60, 70, 12, '#2a1a1a'); p.r(31, B - 59, 68, 10, '#4a1a1a'); G.text(ctx, 'VENTANILLA 7', 41, B - 57, '#ffb040'); }
      } else if (v.mid === 'desierto') {
        let x = 4;
        while (x < CW - 6) {
          const k = r();
          if (k < 0.45) { // yuca / palma del desierto
            const h = 20 + Math.floor(r() * 16);
            p.r(x + 2, B - h, 3, h, '#7a6040');
            const cx = x + 3, cy = B - h;
            for (let a = 0; a < 7; a++) { const ang = -Math.PI + a * Math.PI / 6; p.line(cx, cy, cx + Math.cos(ang) * 8, cy + Math.sin(ang) * 6, '#4a8a3a'); }
            p.circle(cx, cy, 2, '#3a7a2a');
            x += 20;
          } else if (k < 0.7) { p.r(x, B - 6, 16, 6, '#8a9a5a'); p.r(x + 3, B - 9, 8, 3, '#9aaa6a'); x += 22; }
          else x += 16;
        }
        poles(p, i, '#6a5a4a', 64, 8);
      }
    };
  }

  /* ---------------- CALLE (capa 0.7) ---------------- */
  function roadLayer(z) {
    const v = ZV[z];
    return (p, ctx, r, i) => {
      const T = ROAD_TOP, Hh = GROUND_TOP - ROAD_TOP + 2;
      switch (v.road) {
        case 'calle':
        case 'avenida': {
          p.r(0, T, CW, Hh, v.road === 'avenida' ? '#4a4d54' : '#5a5d63');
          p.r(0, T, CW, 1, '#8a8a8a');
          for (let x = 0; x < CW; x += 32) p.r(x + 4, T + 9, 14, 1, v.road === 'avenida' ? C.yellow : '#d8d8d8');
          if (v.road === 'calle' && r() > 0.45) { const c = G.SPR.cars[Math.floor(r() * G.SPR.cars.length)]; ctx.drawImage(c, 2 + Math.floor(r() * (CW - c.width - 4)), T + 5 - c.height); } // estacionados junto a la banqueta de enfrente
          for (let k = 0; k < 8; k++) p.p(r() * CW, T + 2 + r() * 14, '#3a3d43');
          break;
        }
        case 'rio': {
          p.r(0, T, CW, Hh, '#2f5a3a');
          for (let k = 0; k < 18; k++) p.r(r() * CW, T + 2 + r() * 14, 2 + r() * 4, 1, '#4a7a4a');
          for (let k = 0; k < 6; k++) p.r(r() * CW, T + 3 + r() * 12, 2, 2, ['#c0c0c0', '#d8283a', '#f4f4f4', '#4b7bd1', '#fbe043'][Math.floor(r() * 5)]);
          p.r(0, T, CW, 2, '#6b5a3a');
          if (i % 4 === 0) { // montón de basura
            p.r(40, T - 4, 30, 6, '#5a4a3a'); for (let k = 0; k < 20; k++) p.p(40 + r() * 30, T - 6 + r() * 7, ['#c0c0c0', '#d8283a', '#f4f4f4', '#4b7bd1'][Math.floor(r() * 4)]);
          }
          if (i % 6 === 3) { // puente
            p.r(0, T - 6, CW, 4, '#9a5a3a'); for (let x = 2; x < CW; x += 16) { p.r(x, T - 2, 4, Hh, '#7a4a2a'); }
            for (let x = 0; x < CW; x += 4) p.r(x, T - 10, 1, 4, '#9a5a3a'); p.r(0, T - 10, CW, 1, '#9a5a3a');
          }
          break;
        }
        case 'baldio': case 'baldio2': {
          p.r(0, T, CW, Hh, z === 4 ? '#24141c' : '#2a2230');
          for (let k = 0; k < 14; k++) p.r(r() * CW, T + r() * 16, 3, 1, z === 4 ? '#3a1a22' : '#3a3044');
          if (r() > 0.6) { p.r(30 + r() * 60, T - 2, 10, 5, '#3a3a3a'); }
          break;
        }
        case 'terraceria': {
          p.r(0, T, CW, Hh, '#c9a77a');
          for (let k = 0; k < 20; k++) p.p(r() * CW, T + r() * 16, '#a8865a');
          p.r(0, T + 6, CW, 1, '#b8966a'); p.r(0, T + 12, CW, 1, '#b8966a');
          break;
        }
      }
    };
  }

  /* ---------------- SUELO (capa 1.0) ---------------- */
  function groundLayer(z) {
    const v = ZV[z];
    return (p, ctx, r, i) => {
      const T = GROUND_TOP;
      switch (v.ground) {
        case 'banqueta': case 'banqueta2': {
          p.r(0, T, CW, 3, '#8a8a8a');
          p.r(0, T + 2, CW, 10, v.ground === 'banqueta' ? '#c9c2b5' : '#bdb8b0');
          for (let x = 0; x < CW; x += 16) p.r(x, T + 2, 1, 10, '#a8a296');
          p.r(0, T + 12, CW, 2, '#8a8478');
          p.r(0, T + 14, CW, 18, v.ground === 'banqueta' ? '#5a8a3a' : '#7a7a7a');
          if (v.ground === 'banqueta') { for (let k = 0; k < 30; k++) p.p(r() * CW, T + 15 + r() * 16, r() > 0.5 ? '#4a7a2a' : '#7aaa4a'); }
          else { for (let x = 0; x < CW; x += 8) p.r(x, T + 14, 1, 18, '#6a6a6a'); p.r(0, T + 22, CW, 1, '#6a6a6a'); }
          break;
        }
        case 'tierra': {
          p.r(0, T, CW, 32, '#9a6a40'); p.r(0, T, CW, 3, '#b8865a');
          for (let k = 0; k < 40; k++) p.p(r() * CW, T + 3 + r() * 28, r() > 0.5 ? '#7a5030' : '#c0905a');
          for (let k = 0; k < 4; k++) p.r(r() * CW, T + 6 + r() * 20, 3, 2, '#a0a0a0');
          if (r() > 0.6) { p.r(r() * 100, T + 3, 22, 3, '#5a5d63'); }
          break;
        }
        case 'grietas': case 'piedra': {
          const base = z === 4 ? '#3a1c24' : '#3a3046', hi = z === 4 ? '#5a2a30' : '#54486a';
          p.r(0, T, CW, 32, base); p.r(0, T, CW, 3, hi);
          if (v.ground === 'piedra') { for (let x = 0; x < CW; x += 16) for (let y = T + 4; y < T + 32; y += 8) p.r(x + ((y / 8) % 2) * 8, y, 15, 1, '#2a1018'); }
          for (let k = 0; k < 5; k++) { let x = r() * CW, y = T + 4 + r() * 10; for (let s = 0; s < 6; s++) { p.p(x, y, '#1a1020'); x += r() > 0.5 ? 1 : -1; y += 1; } }
          break;
        }
        case 'grava': {
          p.r(0, T, CW, 32, '#d9b98a'); p.r(0, T, CW, 3, '#ecd0a0');
          for (let k = 0; k < 50; k++) p.p(r() * CW, T + 3 + r() * 28, ['#b8966a', '#a0a0a0', '#f0dcb0'][Math.floor(r() * 3)]);
          break;
        }
      }
    };
  }


  /* =================== NIVEL 2: edificios de la carretera =================== */
  let rusty = null;
  function rustCars() {
    if (!rusty) rusty = G.SPR.cars.map(c => G.mk(c.width, c.height, (p, ctx) => {
      ctx.drawImage(c, 0, 0); ctx.globalCompositeOperation = 'source-atop';
      ctx.fillStyle = 'rgba(110,60,25,0.6)'; ctx.fillRect(0, 0, c.width, c.height);
      ctx.fillStyle = 'rgba(40,20,10,0.5)'; for (let k = 0; k < 12; k++) ctx.fillRect((k * 37) % c.width, (k * 13) % c.height, 3, 2);
    }));
    return rusty;
  }
  function facade(p, x, w, h, col, win, opts = {}) {
    const B = MID_BASE, y0 = B - h;
    p.r(x, y0, w, h, col); p.r(x, y0, w, 2, opts.trim || 'rgba(0,0,0,0.25)');
    if (opts.roof) p.r(x - 1, y0 - 2, w + 2, 2, opts.roof);
    const top = y0 + (opts.signH || 12) + 2;
    for (let y = top; y < B - 16; y += 9) for (let xx = x + 4; xx < x + w - 6; xx += 8) p.r(xx, y, 5, 6, win);
    if (opts.door !== false) { p.r(x + w / 2 - 5, B - 14, 10, 14, opts.doorC || '#2b3e5c'); p.r(x + w / 2 - 1, B - 14, 1, 14, '#1a2238'); }
    return y0;
  }
  function sign(p, ctx, x, y, w, text, bg, fg, scale = 1) {
    const h = scale === 2 ? 14 : 9;
    p.r(x, y, w, h, bg); p.r(x, y + h, w, 1, 'rgba(0,0,0,0.35)');
    G.text(ctx, text, x + w / 2, y + (scale === 2 ? 2 : 2), fg, { align: 'center', scale });
  }
  function neon(p, ctx, x, y, text, col) {
    const w = G.textWidth(text) + 8;
    p.r(x - 1, y - 1, w + 2, 11, col); p.r(x, y, w, 9, '#0a0612');
    G.text(ctx, text, x + w / 2, y + 2, col, { align: 'center' });
    return w;
  }
  function stadium(p, ctx, x, w, h, col, colD, txt, night) {
    const B = MID_BASE, y0 = B - h;
    for (let k = 0; k < h; k++) { const inset = Math.round(Math.max(0, 10 - k) * 1.2); p.r(x + inset, y0 + k, w - inset * 2, 1, col); }
    for (let y = y0 + 16; y < B - 4; y += 10) for (let xx = x + 6; xx < x + w - 8; xx += 9) { p.r(xx, y, 6, 7, colD); p.r(xx + 1, y, 4, 2, colD); }
    p.r(x, y0 + 10, w, 2, colD);
    for (const lx of [x + 2, x + w - 5]) { p.r(lx + 1, y0 - 20, 1, 22, '#555'); p.r(lx - 2, y0 - 24, 7, 4, night ? '#fff6a0' : '#ddd'); }
    G.text(ctx, txt, x + w / 2, y0 + 20, night ? '#ffffff' : '#1d2b53', { align: 'center', scale: 2, outline: night ? '#000' : '#ffffff' });
  }
  /* Metro verde en obra negra que recorre toda la pelea final (zona "MIGUEL ALEMÁN") */
  function metro(p, ctx, i) {
    const B = MID_BASE, deck = 66;
    const obra = i % 4 === 2; // tramo sin terminar
    // pilares
    for (const px of [18, 82]) {
      p.r(px, deck + 10, 10, B - deck - 10, '#8a8a90'); p.r(px, deck + 10, 2, B - deck - 10, '#a8a8b0'); p.r(px - 3, deck + 8, 16, 4, '#9a9aa2');
      if (obra && px === 82) { for (let y = deck + 12; y < B; y += 6) { p.r(px - 4, y, 18, 1, '#c9a227'); } p.r(px - 4, deck + 12, 1, B - deck - 12, '#c9a227'); p.r(px + 13, deck + 12, 1, B - deck - 12, '#c9a227'); }
    }
    // trabe del viaducto
    if (obra) {
      p.r(0, deck + 4, 70, 6, '#a8a8b0'); p.r(0, deck + 9, 70, 1, '#6a6a70');
      for (let x = 70; x < CW; x += 4) p.r(x, deck + 6, 1, 3, '#7a4a2a'); p.r(70, deck + 6, 58, 1, '#7a4a2a');
      p.r(96, 20, 3, deck - 14, '#c9a227'); p.r(60, 18, 60, 3, '#c9a227'); p.r(66, 21, 1, 24, '#333'); p.r(63, 45, 7, 4, '#c9a227'); // grúa
      p.r(4, deck - 10, 40, 6, '#e8e8e8'); p.r(4, deck - 10, 40, 1, '#c8c8c8');
      G.text(ctx, 'OBRA', 24, deck - 9, '#d8283a', { align: 'center' });
    } else {
      p.r(0, deck + 4, CW, 6, '#a8a8b0'); p.r(0, deck + 9, CW, 1, '#6a6a70'); p.r(0, deck + 3, CW, 1, '#c8c8d0');
      // vagón verde y blanco
      const x0 = 4, w = 120, top = deck - 24;
      p.r(x0, top + 2, w, 10, '#5fd35f'); p.r(x0 + 2, top, w - 4, 2, '#5fd35f'); p.r(x0, top + 12, w, 10, '#f0f0ea'); p.r(x0, top + 21, w, 2, '#b8b8b0');
      p.r(x0 + 4, top + 4, w - 8, 7, '#1d2b4a'); for (let x = x0 + 18; x < x0 + w - 4; x += 16) p.r(x, top + 4, 2, 7, '#5fd35f');
      p.r(x0 + 50, top + 4, 12, 17, '#3fa54a'); p.r(x0 + 55, top + 4, 2, 17, '#1f7d36');
      p.r(x0 + 6, top + 14, 10, 2, '#5fd35f');
      if (i % 4 === 0) { p.r(x0 + w - 6, top + 1, 6, 20, '#5fd35f'); p.r(x0 + w - 4, top + 4, 3, 8, '#1d2b4a'); }
    }
    // malla de obra y conos al pie
    for (let x = 0; x < CW; x += 3) p.r(x, B - 10, 2, 6, (x / 3) % 2 ? '#f08a24' : '#f4f4f4');
    p.r(0, B - 10, CW, 1, '#b35a12');
    if (i % 3 === 1) { p.r(40, B - 26, 38, 10, '#1f7d36'); G.text(ctx, 'ESTACIÓN', 59, B - 24, '#ffffff', { align: 'center' }); p.r(46, B - 16, 2, 6, '#8a8a90'); p.r(70, B - 16, 2, 6, '#8a8a90'); }
  }
  const FILL_SHOPS = { l2_escomiedo: ['ABARROTES', 'TALLER', 'TACOS'], l2_sanico: ['LONCHES', 'REFACCIONES', 'ESTETICA', 'TALLER'], l2_mty: ['PORKYS', 'LA BOLITA', 'NANDAS', 'EL TARRO', 'DESEX3', 'HOTEL'], l2_mtyn: ['PORKYS', 'LA BOLITA', 'NANDAS', 'EL TARRO', 'DESEX3', 'MARISCOS BAR'] };
  function midLayer2(z) {
    const v = ZV[z];
    return (p, ctx, r, i) => {
      const B = MID_BASE, night = v.mid === 'l2_mtyn' || v.mid === 'l2_chavaca';
      p.r(0, B - 4, CW, 4, night ? '#2a2438' : '#a8a8a8');
      const even = i % 2 === 0, k = Math.floor(i / 2);
      if (v.mid === 'l2_escomiedo' && even) {
        const sp = ['pgr', 'fc', 'gn', 'prepa', 'yonke'][k % 5];
        if (sp === 'pgr') { const y0 = facade(p, 10, 104, 64, '#ececec', '#7a9ab8', { roof: '#c8c8c8', signH: 14 }); sign(p, ctx, 40, y0 + 3, 44, 'PGR', '#2a2a30', '#ffffff', 2); p.r(118, B - 52, 1, 48, '#888'); p.r(119, B - 52, 8, 5, '#2fae4a'); p.r(119, B - 47, 8, 1, '#fff'); p.r(119, B - 46, 8, 2, '#d8283a'); }
        if (sp === 'fc') { const y0 = facade(p, 8, 108, 56, '#2a5ab0', '#a8c8f0', { roof: '#1d3a7a' }); sign(p, ctx, 14, y0 + 3, 96, 'FUERZA CIVIL', '#0e1e44', '#ffffff'); p.r(20, B - 10, 30, 6, '#e8e8e8'); p.r(26, B - 14, 16, 4, '#e8e8e8'); p.r(30, B - 16, 4, 2, '#d8283a'); p.r(34, B - 16, 4, 2, '#4b7bd1'); p.circle(25, B - 4, 2, '#111'); p.circle(45, B - 4, 2, '#111'); }
        if (sp === 'gn') { const y0 = facade(p, 14, 96, 52, '#f0f0ea', '#8a9a7a', { roof: '#5b6e3a', signH: 14 }); sign(p, ctx, 46, y0 + 3, 32, 'GN', '#4a5a2a', '#ffffff', 2); p.r(14, B - 6, 96, 2, '#5b6e3a'); }
        if (sp === 'prepa') { const y0 = facade(p, 6, 112, 46, '#f0d050', '#4a6a9a', { roof: '#c9a227', door: true }); sign(p, ctx, 30, y0 + 3, 64, 'PREPA 25', '#1d2b53', '#fbe043'); for (let xx = 0; xx < CW; xx += 4) p.r(xx, B - 12, 1, 8, '#6a6a6a'); p.r(0, B - 12, CW, 1, '#6a6a6a'); }
        if (sp === 'yonke') {
          const rc = rustCars();
          const c1 = rc[Math.floor(r() * rc.length)], c2 = rc[Math.floor(r() * rc.length)], c3 = rc[Math.floor(r() * rc.length)];
          ctx.drawImage(c1, 4, B - 22 - c1.height + 6); ctx.drawImage(c2, 60, B - 22 - c2.height + 4);
          ctx.save(); ctx.translate(40, B - 52); ctx.rotate(-0.25); ctx.drawImage(c3, -c3.width / 2, -c3.height / 2); ctx.restore();
          for (let xx = 0; xx < CW; xx += 3) p.r(xx, B - 22, 3, 18, (xx / 3) % 2 ? '#7a7f86' : '#949aa2');
          p.r(0, B - 22, CW, 1, '#5a5f66');
          sign(p, ctx, 22, B - 34, 84, 'MOLL DEL YONKE', '#c9a227', '#2a1a0a');
          p.r(30, B - 25, 2, 4, '#5a4a3a'); p.r(96, B - 25, 2, 4, '#5a4a3a');
        }
        return;
      }
      if (v.mid === 'l2_sanico' && even) {
        const sp = ['estadio', 'uni', 'angel', 'kyk'][k % 4];
        if (sp === 'estadio') stadium(p, ctx, 2, 124, 70, '#f0c020', '#b88a10', 'UANL', false);
        if (sp === 'uni') { const y0 = facade(p, 4, 120, 54, '#d8c8a0', '#4a6a9a', { roof: '#b8a880' }); sign(p, ctx, 14, y0 + 3, 100, 'UNIVERSIDAD UANL', '#1d3a8a', '#fbe043'); for (let xx = 12; xx < 120; xx += 14) p.r(xx, B - 18, 3, 14, '#efe6cc'); p.r(4, B - 4, 120, 2, '#c8b890'); }
        if (sp === 'angel') { const y0 = facade(p, 14, 84, 40, '#f4f4f4', '#5a7aa5', { roof: '#c8c8c8' }); const cols = ['#d8283a', '#f08a24', '#fbe043', '#2fae4a', '#4b7bd1', '#76428a']; cols.forEach((c, j) => p.r(16 + j * 14, y0 + 2, 14, 11, c)); G.text(ctx, 'ANGEL COLOR', 56, y0 + 5, '#ffffff', { align: 'center', outline: '#14101e' }); }
        if (sp === 'kyk') { const y0 = facade(p, 24, 76, 38, '#f2d020', '#7a5a10', { roof: '#c9a227', signH: 14 }); sign(p, ctx, 40, y0 + 3, 44, 'KYK', '#f8e060', '#d8283a', 2); }
        return;
      }
      if ((v.mid === 'l2_mty' || v.mid === 'l2_mtyn') && even) {
        const sp = ['estadio', 'matehuala', 'porkys', 'betos', 'bolita', 'mariscos', 'desex3', 'nandas', 'tarro'][k % 9];
        if (sp === 'estadio') { stadium(p, ctx, 2, 124, 72, night ? '#1a3a8a' : '#2a6ad0', night ? '#0e1e4a' : '#1a4a9a', 'ESTADIO', night); return; }
        const names = { matehuala: 'MATEHUALA', porkys: 'PORKYS', betos: 'BETOS BAR', bolita: 'LA BOLITA', mariscos: 'MARISCOS BAR', desex3: 'DESEX3', nandas: 'NANDAS', tarro: 'EL TARRO' };
        const cols = { matehuala: '#7a1a2a', porkys: '#c84a7a', betos: '#000000', bolita: '#2a5a8a', mariscos: '#1a7a8a', desex3: '#5a2a6a', nandas: '#a85a1a', tarro: '#6a4a1a' };
        const betos = sp === 'betos'; // Betos Bar: totalmente negro
        const y0 = facade(p, 10, 108, 44, betos ? '#000000' : night ? '#1a1424' : cols[sp], betos ? '#000000' : night ? (r() > 0.5 ? '#f0d070' : '#2a2034') : '#e8d8a0', { roof: betos ? '#000000' : '#00000066', trim: betos ? '#000000' : undefined, doorC: betos ? '#000000' : undefined });
        if (night) neon(p, ctx, 64 - (G.textWidth(names[sp]) + 8) / 2, y0 + 3, names[sp], '#ff4fd8');
        else if (betos) sign(p, ctx, 20, y0 + 3, 88, names[sp], '#000000', '#ffffff');
        else sign(p, ctx, 20, y0 + 3, 88, names[sp], '#f4f4f4', cols[sp]);
        if (betos) { p.r(58, B - 16, 12, 12, '#000000'); return; }
        p.r(58, B - 16, 12, 12, '#2a1a0a'); p.r(59, B - 12, 4, 6, '#a0702a'); p.r(65, B - 12, 4, 6, '#a0702a'); // puertas de cantina
        return;
      }
      if (v.mid === 'l2_chavaca') {
        let x = 0;
        while (x < CW - 8) { const w = 24 + Math.floor(r() * 26), h = 40 + Math.floor(r() * 50); p.r(x, B - h, w, h, '#141018'); for (let y = B - h + 6; y < B - 6; y += 8) for (let xx = x + 3; xx < x + w - 4; xx += 6) if (r() > 0.6) p.r(xx, y, 3, 4, '#f08a24'); x += w + 2; }
        metro(p, ctx, i);
        return;
      }
      // relleno: casitas, negocios y árboles
      const shops = FILL_SHOPS[v.mid] || ['TACOS'];
      let x = 0;
      while (x < CW - 10) {
        const t = r();
        if (t < 0.25 && !night) { tree(p, x + 6, B - 4, r); x += 16; continue; }
        const w = Math.min(CW - x, 34 + Math.floor(r() * 22)), h = (v.mid === 'l2_mty' || night) ? 50 + Math.floor(r() * 40) : 30 + Math.floor(r() * 20);
        const col = night ? '#1e1830' : ['#e8d8b8', '#c8b8a0', '#a8b8c8', '#f2a65e', '#d8c8e0'][Math.floor(r() * 5)];
        const y0 = facade(p, x, w, h, col, night ? (r() > 0.4 ? '#f0d070' : '#2a2034') : '#3d5a85', { door: true });
        if (w > 36 && r() > 0.3) { const s2 = shops[Math.floor(r() * shops.length)]; if (G.textWidth(s2) + 6 <= w) { if (night) neon(p, ctx, x + 2, y0 + 3, s2, '#ff4fd8'); else sign(p, ctx, x + 2, y0 + 3, w - 4, s2, '#f4f4f4', '#9e1630'); } }
        x += w + 2;
      }
      if (v.mid === 'l2_sanico') { // patrulla estacionada
        p.r(80, B - 10, 34, 6, '#f4f4f4'); p.r(86, B - 14, 18, 4, '#f4f4f4'); p.r(90, B - 16, 4, 2, '#d8283a'); p.r(94, B - 16, 4, 2, '#4b7bd1'); p.r(80, B - 8, 34, 1, '#1d2b53'); p.circle(85, B - 4, 2, '#111'); p.circle(108, B - 4, 2, '#111');
      }
    };
  }
  function roadLayer2(z) {
    const v = ZV[z];
    return (p, ctx, r, i) => {
      const T = ROAD_TOP, Hh = GROUND_TOP - ROAD_TOP + 2, night = v.road === 'carreteraN';
      p.r(0, T, CW, Hh, night ? '#24222c' : '#3e4148');
      p.r(0, T - 3, CW, 2, '#b8b8c0'); for (let x = 2; x < CW; x += 16) p.r(x, T - 3, 2, 5, '#8a8a90');
      p.r(0, T + 8, CW, 1, '#e8c020'); p.r(0, T + 10, CW, 1, '#e8c020');
      if (v.mid === 'l2_sanico' && r() > 0.25) { const c = r() > 0.5 ? G.SPR.patrol : G.SPR.patrolL; ctx.drawImage(c, 4 + Math.floor(r() * (CW - c.width - 8)), T + 5 - c.height); }
      for (let k = 0; k < 10; k++) p.p(r() * CW, T + 2 + r() * 14, night ? '#18161e' : '#34373e');
    };
  }
  function groundLayer2(z) {
    const v = ZV[z];
    return (p, ctx, r, i) => {
      const T = GROUND_TOP, night = v.ground === 'asfaltoN';
      p.r(0, T, CW, 32, night ? '#2a2830' : '#4a4d54');
      p.r(0, T, CW, 3, '#b0b0b0'); for (let x = 0; x < CW; x += 8) p.r(x, T, 1, 3, '#888');
      for (let x = 4; x < CW; x += 32) p.r(x, T + 16, 16, 2, '#f4f4f4');
      p.r(0, T + 28, CW, 1, '#e8c020');
      for (let k = 0; k < 16; k++) p.p(r() * CW, T + 4 + r() * 24, night ? '#201e26' : '#3e4148');
    };
  }

  const fns = {};
  function F(z, layer) {
    const k = z + layer;
    if (!fns[k]) {
      const v = ZV[z];
      fns[k] = layer === 'far' ? farLayer(z) : layer === 'mid' ? (v.mid.startsWith('l2_') ? midLayer2(z) : midLayer(z)) : layer === 'road' ? (v.road.startsWith('carretera') ? roadLayer2(z) : roadLayer(z)) : layer === 'ground' ? (v.ground.startsWith('asfalto') ? groundLayer2(z) : groundLayer(z)) : (p, ctx, r, i) => clouds(p, ctx, r, i, z);
    }
    return fns[k];
  }

  /* Dibuja la escena de fondo de una zona (todo lo que va detrás de los personajes del primer plano) */
  G.drawBackdrop = function (ctx, z, camX, alpha) {
    ctx.globalAlpha = alpha;
    ctx.drawImage(sky(z), 0, 0);
    drawLayer(ctx, z, 'cloud', camX * 0.05, F(z, 'cloud'));
    drawLayer(ctx, z, 'far', camX * 0.12, F(z, 'far'));
    drawLayer(ctx, z, 'mid', camX * 0.4, F(z, 'mid'));
    ctx.globalAlpha = 1;
  };
  G.drawRoad = function (ctx, z, camX, alpha) {
    ctx.globalAlpha = alpha;
    drawLayer(ctx, z, 'road', camX * 0.7, F(z, 'road'));
    ctx.globalAlpha = 1;
  };
  G.drawGround = function (ctx, z, camX, alpha) {
    ctx.globalAlpha = alpha;
    drawLayer(ctx, z, 'ground', camX, F(z, 'ground'));
    ctx.globalAlpha = 1;
  };
  G.groundColor = function (z) { return ['#c9c2b5', '#bdb8b0', '#9a6a40', '#3a3046', '#3a1c24', '#d9b98a'][z]; };
})();
